import path from 'path';
import { fileURLToPath } from 'url';
import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export default defineConfig(({ mode }) => {
    const env = loadEnv(mode, '.', '');
    return {
      // 设置为相对路径，适配腾讯云 COS 等静态托管环境
      base: './',
      plugins: [react()],
      define: {
        'process.env.API_KEY': JSON.stringify(env.GEMINI_API_KEY),
      },
      resolve: {
        alias: {
          '@': path.resolve(__dirname, '.'),
        }
      },
      build: {
        outDir: 'dist',
        assetsDir: 'assets',
        // 移除 minify: 'terser'，默认使用 esbuild 提高兼容性
        minify: 'esbuild',
        rollupOptions: {
          output: {
            manualChunks: {
              'vendor': ['react', 'react-dom', 'framer-motion', 'gsap'],
              'ui': ['lucide-react']
            }
          }
        }
      }
    };
});