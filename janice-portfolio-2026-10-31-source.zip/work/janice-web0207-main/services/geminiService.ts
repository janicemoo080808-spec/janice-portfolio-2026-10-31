
import { GoogleGenAI } from "@google/genai";

// Use process.env.API_KEY directly as per guidelines.
export const chatWithResume = async (userMessage: string, context: string): Promise<string> => {
  try {
    // Always use the named parameter for apiKey and initialize strictly as requested.
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

    // Use gemini-3-pro-preview for complex reasoning tasks related to strategy and AIGC.
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: userMessage,
      config: {
        systemInstruction: `
          You are the Strategic AI Concierge for Janice Mo, a world-class Brand Creative Director and AIGC Workflow Architect.
          
          JANICE'S PHILOSOPHY:
          - Aesthetics without strategy is noise.
          - Design is a commercial system that converts "attention" into "asset value".
          - Leveraging AI to reduce creative costs while increasing narrative sovereignty.
          
          YOUR PERSONA:
          - Professional, authoritative, yet visionary and engaging.
          - Focus on ROI, business growth, and technological edge.
          - Use industry terms like "CMF", "LoRA", "SOP", "Brand Sovereignty", "ROI".
          
          CONTEXT:
          ${context}
          
          GUIDELINES:
          - If asked about Janice's experience, cite her work at Crydit, Zotye, or LVMH ecosystems.
          - If asked about AIGC, mention her "Silicon Strategy" hybrid agent architecture.
          - Keep answers concise and high-impact.
          - If information is missing, invite the user to sync up with Janice directly via phone (18621568644) or email (maoyujun08@163.com).
        `,
        thinkingConfig: { thinkingBudget: 4000 }
      }
    });

    // Directly access the .text property from the response.
    return response.text || "I'm processing the strategic implications. Could you rephrase your inquiry?";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "I'm having trouble connecting to my strategic knowledge base. Please try again later.";
  }
};
