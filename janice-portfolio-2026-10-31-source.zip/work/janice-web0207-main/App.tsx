import React, { useState, useEffect } from 'react';
import { Language } from './types';
import DesktopApp from './renderers/DesktopApp';
import MobileApp from './renderers/MobileApp';
import { CONTENT_CN, STRATEGIC_EXPERTISE_CN } from './data/cn/index';
import { CONTENT_EN, STRATEGIC_EXPERTISE_EN } from './data/en/index';

const App: React.FC = () => {
  const [language, setLanguage] = useState<Language>('EN');
  const [isMobile, setIsMobile] = useState<boolean>(false);

  useEffect(() => {
    // 实时检测宽度，逻辑隔离
    const checkSize = () => setIsMobile(window.innerWidth < 1024);
    checkSize();
    window.addEventListener('resize', checkSize);
    
    // 禁用全局右键与拖拽，保护资产
    const preventAction = (e: any) => e.preventDefault();
    document.addEventListener('contextmenu', preventAction);
    document.addEventListener('dragstart', preventAction);

    return () => {
      window.removeEventListener('resize', checkSize);
      document.removeEventListener('contextmenu', preventAction);
      document.removeEventListener('dragstart', preventAction);
    };
  }, []);

  // 核心数据路由：根据语言选择物理数据块
  const content = language === 'CN' ? CONTENT_CN : CONTENT_EN;
  const expertise = language === 'CN' ? STRATEGIC_EXPERTISE_CN : STRATEGIC_EXPERTISE_EN;

  return (
    <>
      {isMobile ? (
        <MobileApp 
          language={language} 
          setLanguage={setLanguage} 
          content={content} 
          expertise={expertise} 
        />
      ) : (
        <DesktopApp 
          language={language} 
          setLanguage={setLanguage} 
          content={content} 
          expertise={expertise} 
        />
      )}
    </>
  );
};

export default App;
