
import React, { useState, useRef } from 'react';
import { motion as m, useScroll, useSpring, useTransform, AnimatePresence } from 'framer-motion';
import { Language, CategoryType, Project, BlogPost } from '../types';
import ProjectDetails from '../components/ProjectDetails';
import ResumeSection from '../components/ResumeSection';
import EndorsementArchive from '../components/EndorsementArchive';
import AwardsSection from '../components/AwardsSection';
import LightRays from '../components/LightRays';
import MagicBento from '../components/MagicBento';
import BlurText from '../components/BlurText';
import BlogEditorialLayout from '../components/BlogEditorialLayout';
import PortfolioAccordionCard from '../components/PortfolioAccordionCard';
import SkillsMarquee from '../components/SkillsMarquee';
import DownloadButton from '../components/DownloadButton';
import { Download, ChevronDown, ChevronRight, Mail, Phone } from 'lucide-react';
import { CV_URL } from '../data/cn/index';

const motion = m as any;

interface DesktopAppProps {
  language: Language;
  setLanguage: (l: Language) => void;
  content: any;
  expertise: any[];
}

const DesktopApp: React.FC<DesktopAppProps> = ({ language, setLanguage, content, expertise }) => {
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [selectedPost, setSelectedPost] = useState<BlogPost | null>(null);
  const [hoveredProjectIdx, setHoveredProjectIdx] = useState<number | null>(null);
  const [isWorksHovered, setIsWorksHovered] = useState(false);

  const { scrollY } = useScroll();
  const smoothScrollY = useSpring(scrollY, { stiffness: 80, damping: 25 });
  const foregroundY = useTransform(smoothScrollY, [0, 1000], [0, -200]);

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, targetId: string) => {
    e.preventDefault();
    setSelectedProject(null);
    setSelectedPost(null);
    const element = document.getElementById(targetId);
    if (element) {
      window.scrollTo({ top: element.getBoundingClientRect().top + window.scrollY - 80, behavior: 'smooth' });
    }
  };

  const dropdownItems = [
    { label: language === 'EN' ? 'Web3 Ecosystem' : 'Web3 金融生态', cat: 'BRAND_ECOSYSTEM' },
    { label: language === 'EN' ? 'Luxury Aesthetics & Tone' : '奢侈品美学与调性', cat: 'LUXURY_DESIGN' },
    { label: language === 'EN' ? 'Smart Mobility' : '智能出行', cat: 'AUTOMOTIVE_DESIGN' },
    { label: language === 'EN' ? 'AIGC Strategy & Production' : 'AIGC 战略与全域制作', cat: 'AI_CREATIVE' },
    { label: language === 'EN' ? 'Brand Activity & Space' : '品牌活动与空间', cat: 'ACTIVITY_VISUALS' }
  ];

  return (
    <div className="hidden lg:block min-h-screen bg-background text-white selection:bg-primary/20">
      <motion.nav 
        initial={{ y: -100 }} 
        animate={{ y: 0 }} 
        className="fixed top-0 left-0 right-0 z-[5000] h-[80px] flex items-center border-b border-black/20 border-t border-white/[0.08]"
        style={{
          backgroundColor: 'rgba(0, 0, 0, 0.45)',
          backdropFilter: 'blur(30px) saturate(190%) contrast(100%)',
          WebkitBackdropFilter: 'blur(30px) saturate(190%) contrast(100%)',
        }}
      >
        <div className="w-full max-w-[1440px] mx-auto px-8 flex items-center justify-between relative h-full">
          {/* 1. Logo: Semibold, tracking -0.02em */}
          <a href="/" onClick={(e) => {e.preventDefault(); setSelectedProject(null); setSelectedPost(null); window.scrollTo({top:0, behavior:'smooth'})}} className="text-lg font-semibold uppercase tracking-[-0.02em] text-white hover:text-primary transition-all whitespace-nowrap">Janice Mo</a>

          {/* 2. Menu: Semibold weight, text-[11px], tracking 0.1em */}
          <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 hidden xl:flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.1em] text-zinc-400">
              <div className="relative" onMouseEnter={() => setIsWorksHovered(true)} onMouseLeave={() => setIsWorksHovered(false)}>
                <a href="#projects" onClick={(e) => handleNavClick(e, 'projects')} className="flex items-center gap-2 px-4 py-2 hover:bg-white/5 hover:text-white rounded-full transition-all duration-300 hover:-translate-y-px">{content.nav.portfolios}<ChevronDown className="w-3 h-3" /></a>
                <AnimatePresence>
                  {isWorksHovered && (
                    <motion.div 
                      initial={{ opacity: 0, y: 10, scale: 0.98 }} 
                      animate={{ opacity: 1, y: 0, scale: 1 }} 
                      exit={{ opacity: 0, y: 5, scale: 0.98 }} 
                      transition={{ type: "spring", stiffness: 300, damping: 30 }}
                      className="absolute top-full left-1/2 -translate-x-1/2 mt-4 w-80 rounded-2xl border border-white/[0.12] shadow-[0_40px_100px_rgba(0,0,0,0.9),0_0_20px_rgba(0,0,0,0.5)] shadow-[inset_0_1px_1px_rgba(255,255,255,0.1)] p-3 overflow-hidden"
                      style={{
                        backgroundColor: 'rgba(5, 5, 5, 0.92)',
                        backdropFilter: 'blur(60px) saturate(220%) brightness(80%)',
                        WebkitBackdropFilter: 'blur(60px) saturate(220%) brightness(80%)',
                      }}
                    >
                      {dropdownItems.map((item, idx) => (
                        <button key={idx} onClick={() => { setSelectedPost(null); const p = content.projects.find((p:any) => p.category === item.cat); if(p) setSelectedProject(p); }} className="w-full text-left px-8 py-5 hover:bg-white/10 hover:text-white transition-all text-zinc-400 font-bold uppercase tracking-[0.2em] text-[10px] border-b border-white/5 last:border-0 rounded-lg group">
                          <span className="group-hover:drop-shadow-[0_0_5px_rgba(255,255,255,0.5)] transition-all">{item.label}</span>
                        </button>
                      ))}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
              <a href="#journey" onClick={(e) => handleNavClick(e, 'journey')} className="px-4 py-2 hover:bg-white/5 hover:text-white rounded-full transition-all duration-300 hover:-translate-y-px">{content.nav.career}</a>
              <a href="#credentials" onClick={(e) => handleNavClick(e, 'credentials')} className="px-4 py-2 hover:bg-white/5 hover:text-white rounded-full transition-all duration-300 hover:-translate-y-px">{content.nav.credentials}</a>
              <a href="#insights" onClick={(e) => handleNavClick(e, 'insights')} className="px-4 py-2 hover:bg-white/5 hover:text-white rounded-full transition-all duration-300 hover:-translate-y-px">{content.nav.blog}</a>
              <a href="#connect" onClick={(e) => handleNavClick(e, 'connect')} className="px-4 py-2 hover:bg-white/5 hover:text-white rounded-full transition-all duration-300 hover:-translate-y-px">{content.nav.connect}</a>
          </div>

          {/* 3. Controls: Right aligned, ghost capsule */}
          <div className="flex items-center gap-4">
            <button onClick={() => setLanguage(language === 'EN' ? 'CN' : 'EN')} className="px-3 py-1 border border-white/10 rounded-full text-[11px] font-medium text-zinc-400 hover:text-white hover:bg-white/5 hover:border-white/40 transition-all">{language === 'EN' ? '中文' : 'ENGLISH'}</button>
            <DownloadButton href={CV_URL} label={content.nav.downloadCv} />
          </div>
        </div>
      </motion.nav>

      <section className="h-screen flex flex-col justify-center relative pt-32 overflow-hidden bg-background">
        <div className="absolute inset-0 z-0">
          <LightRays raysOrigin="top-center" raysColor="#86570B" followMouse={true} />
        </div>
        <motion.div 
          style={{ y: foregroundY }} 
          className="relative z-10 max-w-[1440px] mx-auto px-12"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={{
            hidden: { opacity: 0 },
            visible: {
              opacity: 1,
              transition: {
                staggerChildren: 0.12
              }
            }
          }}
        >
          <motion.div variants={{ hidden: { opacity: 0, y: 80 }, visible: { opacity: 1, y: 0, transition: { duration: 1.2, ease: [0.44, 0, 0.56, 1] } } }}>
            <BlurText text={content.hero.title} className="text-[12vw] font-display font-bold leading-[0.85] tracking-tighter text-white uppercase" />
          </motion.div>
          <motion.h2 
            variants={{ hidden: { opacity: 0, y: 80 }, visible: { opacity: 1, y: 0, transition: { duration: 1.2, ease: [0.44, 0, 0.56, 1] } } }}
            className="text-4xl font-sans font-bold text-primary tracking-[0.1em] mt-10 uppercase drop-shadow-lg"
          >
            BEYOND VISUALS, INTO NARRATIVE.
          </motion.h2>
          <motion.p 
            variants={{ hidden: { opacity: 0, y: 80 }, visible: { opacity: 1, y: 0, transition: { duration: 1.2, ease: [0.44, 0, 0.56, 1] } } }}
            className="text-2xl text-zinc-400 font-light mt-10 max-w-3xl border-l-2 border-white/10 pl-12 leading-relaxed"
          >
            {content.hero.description}
          </motion.p>
        </motion.div>
      </section>

      <motion.section 
        id="expertise" 
        className="py-40 px-12 max-w-[1440px] mx-auto"
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, margin: "-100px" }}
        variants={{
          hidden: { opacity: 0 },
          visible: {
            opacity: 1,
            transition: {
              staggerChildren: 0.12
            }
          }
        }}
      >
        <motion.h2 
          variants={{
            hidden: { opacity: 0, y: 80 },
            visible: { opacity: 1, y: 0, transition: { duration: 1.2, ease: [0.44, 0, 0.56, 1] } }
          }}
          className="text-6xl font-sans font-bold tracking-tighter uppercase mb-24"
        >
          {content.resume.aboutTitle}
        </motion.h2>
        <motion.div
          variants={{
            hidden: { opacity: 0, y: 80 },
            visible: { opacity: 1, y: 0, transition: { duration: 1.2, ease: [0.44, 0, 0.56, 1] } }
          }}
        >
          <MagicBento items={expertise} glowColor="134, 87, 11" spotlightRadius={500} />
        </motion.div>
        <motion.div
          variants={{
            hidden: { opacity: 0, y: 80 },
            visible: { opacity: 1, y: 0, transition: { duration: 1.2, ease: [0.44, 0, 0.56, 1] } }
          }}
        >
          <SkillsMarquee className="mt-24" language={language} />
        </motion.div>
      </motion.section>

      <motion.section 
        id="projects" 
        className="py-40 px-12 max-w-[1550px] mx-auto overflow-visible"
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, margin: "-100px" }}
        variants={{
          hidden: { opacity: 0 },
          visible: {
            opacity: 1,
            transition: {
              staggerChildren: 0.12
            }
          }
        }}
      >
        <motion.h2 
          variants={{
            hidden: { opacity: 0, y: 80 },
            visible: { opacity: 1, y: 0, transition: { duration: 1.2, ease: [0.44, 0, 0.56, 1] } }
          }}
          className="text-[5vw] font-sans font-bold tracking-tighter uppercase mb-20"
        >
          {content.portfolio.title}
        </motion.h2>
        <motion.div 
          className="flex flex-row justify-center items-stretch gap-4 h-[500px]"
          variants={{
            hidden: { opacity: 0, y: 80 },
            visible: { opacity: 1, y: 0, transition: { duration: 1.2, ease: [0.44, 0, 0.56, 1] } }
          }}
        >
          {content.projects.map((project: any, idx: number) => (
            <PortfolioAccordionCard 
              key={project.id} project={project} 
              isHovered={hoveredProjectIdx === idx} isAnyHovered={hoveredProjectIdx !== null}
              onHover={() => setHoveredProjectIdx(idx)} onLeave={() => setHoveredProjectIdx(null)}
              onClick={() => setSelectedProject(project)}
              language={language}
            />
          ))}
        </motion.div>
      </motion.section>

      <motion.section 
        id="journey" 
        className="py-40 bg-zinc-950/50 border-t border-white/5"
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, margin: "-100px" }}
        variants={{
          hidden: { opacity: 0 },
          visible: {
            opacity: 1,
            transition: {
              staggerChildren: 0.12
            }
          }
        }}
      >
        <motion.div
          variants={{
            hidden: { opacity: 0, y: 80 },
            visible: { opacity: 1, y: 0, transition: { duration: 1.2, ease: [0.44, 0, 0.56, 1] } }
          }}
        >
          <ResumeSection content={content} experience={content.experience} language={language} />
        </motion.div>
      </motion.section>

      <motion.section 
        id="credentials" 
        className="py-40"
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, margin: "-100px" }}
        variants={{
          hidden: { opacity: 0 },
          visible: {
            opacity: 1,
            transition: {
              staggerChildren: 0.12
            }
          }
        }}
      >
        <motion.div
          variants={{
            hidden: { opacity: 0, y: 80 },
            visible: { opacity: 1, y: 0, transition: { duration: 1.2, ease: [0.44, 0, 0.56, 1] } }
          }}
        >
          <EndorsementArchive education={content.education} certificates={content.certificates} titleEdu={content.resume.eduTitle} titleCert={content.resume.certTitle} language={language} />
        </motion.div>
      </motion.section>

      <motion.div
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, margin: "-100px" }}
        variants={{
          hidden: { opacity: 0 },
          visible: {
            opacity: 1,
            transition: {
              staggerChildren: 0.12
            }
          }
        }}
      >
        <motion.div
          variants={{
            hidden: { opacity: 0, y: 80 },
            visible: { opacity: 1, y: 0, transition: { duration: 1.2, ease: [0.44, 0, 0.56, 1] } }
          }}
        >
          <AwardsSection items={content.awards} language={language} subtitle={content.common.awardsSubtitle} desc={content.common.awardsDesc} />
        </motion.div>
      </motion.div>

      <motion.section 
        id="insights" 
        className="py-40 px-12 max-w-[1440px] mx-auto border-t border-white/5"
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, margin: "-100px" }}
        variants={{
          hidden: { opacity: 0 },
          visible: {
            opacity: 1,
            transition: {
              staggerChildren: 0.12
            }
          }
        }}
      >
        <motion.h2 
          variants={{
            hidden: { opacity: 0, y: 80 },
            visible: { opacity: 1, y: 0, transition: { duration: 1.2, ease: [0.44, 0, 0.56, 1] } }
          }}
          className="text-[5vw] font-sans font-bold tracking-tighter uppercase mb-24"
        >
          {content.blog.title}
        </motion.h2>
        <motion.div 
          className="grid grid-cols-2 gap-12"
          variants={{
            hidden: { opacity: 0, y: 80 },
            visible: { opacity: 1, y: 0, transition: { duration: 1.2, ease: [0.44, 0, 0.56, 1] } }
          }}
        >
          {content.blogPosts.map((post: any) => (
            <div key={post.id} onClick={() => setSelectedPost(post)} className="group cursor-pointer rounded-[2.5rem] overflow-hidden border border-white/5 bg-zinc-950 aspect-video relative shadow-2xl">
              <img src={post.imageUrl} className="w-full h-full object-cover group-hover:scale-110 transition-all duration-1000" loading="lazy" />
              {/* 1. Static Background Layer: Ensures bottom edge is always covered */}
              <div className="absolute inset-x-0 bottom-0 h-1/2 bg-black/10 backdrop-blur-[25px] pointer-events-none transition-all duration-700 group-hover:h-[55%] group-hover:bg-black/20" style={{ WebkitMaskImage: 'linear-gradient(to top, black 15%, transparent 85%)', maskImage: 'linear-gradient(to top, black 15%, transparent 85%)' }} />
              {/* 2. Floating Content Layer: Handles displacement only */}
              <div className="absolute inset-0 p-10 flex flex-col justify-end transition-transform duration-700 group-hover:-translate-y-4 z-20">
                 <div className="flex items-center gap-3 mb-4 opacity-50"><div className="w-1.5 h-1.5 rounded-full bg-primary" /> <span className="text-[10px] font-black uppercase tracking-widest text-white">{(post as any).readTime}</span></div>
                 <h3 className="text-xl font-bold text-white opacity-100 uppercase leading-tight">{(post as any).title}</h3>
              </div>
            </div>
          ))}
        </motion.div>
      </motion.section>

      <motion.section 
        id="connect" 
        className="py-60 px-12 max-w-[1440px] mx-auto border-t border-white/5"
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, margin: "-100px" }}
        variants={{
          hidden: { opacity: 0 },
          visible: {
            opacity: 1,
            transition: {
              staggerChildren: 0.12
            }
          }
        }}
      >
         <div className="grid grid-cols-1 lg:grid-cols-12 gap-20 items-center">
            <motion.div 
              className="lg:col-span-6"
              variants={{
                hidden: { opacity: 0, y: 80 },
                visible: { opacity: 1, y: 0, transition: { duration: 1.2, ease: [0.44, 0, 0.56, 1] } }
              }}
            >
               <span className="text-[10px] font-black text-primary uppercase tracking-[0.8em] mb-6 block">{content.nav.connect}</span>
               <h2 className="text-6xl md:text-8xl font-sans font-bold tracking-tighter uppercase leading-[0.9] text-white">Let's <br/><span className="text-primary-gradient">Sync Up.</span></h2>
            </motion.div>
            <motion.div 
              className="lg:col-span-6 space-y-12"
              variants={{
                hidden: { opacity: 0, y: 80 },
                visible: { opacity: 1, y: 0, transition: { duration: 1.2, ease: [0.44, 0, 0.56, 1] } }
              }}
            >
               <a href={`tel:${content.common.phoneValue}`} className="group flex items-center gap-10 border-b border-white/5 pb-10 transition-all">
                  <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center group-hover:bg-primary transition-all group-hover:scale-110">
                    <Phone className="w-6 h-6 text-primary group-hover:text-white transition-colors" />
                  </div>
                  <div className="space-y-1 transition-transform duration-500 group-hover:translate-x-4">
                    <span className="text-[10px] font-black text-zinc-500 uppercase tracking-widest">{content.common.phoneWechat}</span>
                    <p className="text-3xl md:text-4xl font-display font-bold text-white group-hover:text-primary transition-all">{content.common.phoneValue}</p>
                  </div>
               </a>
               <a href={`mailto:${content.common.emailValue}`} className="group flex items-center gap-10 transition-all">
                  <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center group-hover:bg-primary transition-all group-hover:scale-110">
                    <Mail className="w-6 h-6 text-primary group-hover:text-white transition-colors" />
                  </div>
                  <div className="space-y-1 transition-transform duration-500 group-hover:translate-x-4">
                    <span className="text-[10px] font-black text-zinc-500 uppercase tracking-widest">{content.common.emailAddr}</span>
                    <p className="text-3xl md:text-4xl font-display font-bold text-white group-hover:text-primary transition-all">{content.common.emailValue}</p>
                  </div>
               </a>
            </motion.div>
         </div>
      </motion.section>

      <footer className="py-20 border-t border-white/5 text-center text-zinc-600 text-[11px] font-black uppercase tracking-[0.4em]">{content.footer.rights}</footer>

      <AnimatePresence>
        {selectedProject && <ProjectDetails project={selectedProject} onClose={() => setSelectedProject(null)} />}
        {selectedPost && <BlogEditorialLayout post={selectedPost} onClose={() => setSelectedPost(null)} language={language} />}
      </AnimatePresence>
    </div>
  );
};

export default DesktopApp;
