
import React, { useState, useEffect, useRef } from 'react';
import { motion as m, AnimatePresence, useScroll, useTransform, useSpring } from 'framer-motion';
import { Language, Project, BlogPost, ExperienceItem as ExperienceType, AwardItem } from '../types';
import ProjectDetails from '../components/ProjectDetails';
import BlogEditorialLayout from '../components/BlogEditorialLayout';
import { 
  Download, Menu, X, Phone, Mail, ChevronRight, 
  Sparkles, Target, TrendingUp, UserCircle, Briefcase, Layers,
  ArrowUpRight, ArrowUp, LayoutGrid, MessageCircle,
  Trophy, GraduationCap, Award, Star, ShieldCheck, ChevronDown, Minus
} from 'lucide-react';
import { CV_URL } from '../data/cn/index';
import TextType from '../components/TextType';
import DownloadButton from '../components/DownloadButton';
import { DESIGN_PHILOSOPHY_CN, DESIGN_PHILOSOPHY_EN } from '../constants';

const motion = m as any;

// 仅保留数据类关键词高亮
const KEYWORDS = [
  '10 倍', '10倍', '35%', '80%', '15%', '2 个月', '2个月', '50,000+', 
  '000980', '600696', '1.2M+', '9年+', '9+ years', '5 人的团队', '20 人的战力', 'ROI', 'GMV'
];

const highlightKeywords = (text: string) => {
  if (!text) return text;
  // 匹配数字、百分比、倍数等数据的正则
  const dataRegex = /(\d+(?:\.\d+)?%|\d+\s*倍|\d+,\d+\+|\d+\.\d+M\+|\d+年\+|\d+\+ years|\d+\s*人)/g;
  
  const parts = text.split(dataRegex);
  return parts.map((part, i) => {
    const isData = dataRegex.test(part) || KEYWORDS.some(k => k.toLowerCase() === part.toLowerCase());
    return isData ? <span key={i} className="text-white font-bold">{part}</span> : part;
  });
};

/**
 * 修复文字加粗逻辑：仅移除 ** 标记，不再强制加粗，交由 highlightKeywords 处理数据加粗
 */
const renderRichText = (text: string) => {
  if (!text) return text;
  // 移除所有 ** 标记
  const cleanText = text.replace(/\*\*/g, '');
  return highlightKeywords(cleanText);
};

const MobileAmbientLight = () => (
  <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none">
    <motion.div 
      animate={{ scale: [1, 1.15, 1], opacity: [0.2, 0.35, 0.2] }}
      transition={{ duration: 12, repeat: Infinity, ease: "linear" }}
      className="absolute top-[-10%] left-[-10%] w-[120%] h-[60%] bg-primary/10 blur-[120px] rounded-full"
    />
  </div>
);

const MorphingProjectCard: React.FC<{ project: Project, onClick: () => void, language: Language, index: number, total: number }> = ({ project, onClick, language, index, total }) => {
  return (
    <motion.div
      layoutId={`card-${project.id}`}
      onClick={onClick}
      whileTap={{ scale: 0.96 }}
      className="relative w-full aspect-[3/2] rounded-3xl overflow-hidden shadow-2xl bg-zinc-900 border border-white/5 group transform-gpu"
    >
      <motion.img 
        layoutId={`img-${project.id}`}
        src={project.imageUrl} 
        className="absolute inset-0 w-full h-full object-cover transition-transform duration-1000 group-active:scale-110"
        alt={project.title}
        loading="lazy"
        decoding="async"
      />
      <div 
        className="absolute inset-x-0 bottom-0 h-1/2 z-10 backdrop-blur-[20px]" 
        style={{ WebkitMaskImage: 'linear-gradient(to top, black 20%, transparent 80%)', maskImage: 'linear-gradient(to top, black 20%, transparent 80%)' }} 
      />
      
      <div className="absolute inset-0 z-20 p-5 flex flex-col justify-end items-start pointer-events-none">
        <motion.div layoutId={`info-${project.id}`}>
          <h3 className="text-lg font-bold text-white uppercase tracking-tighter leading-none drop-shadow-lg">
            {project.title}
          </h3>
        </motion.div>
      </div>
    </motion.div>
  );
};

// 小红书比例卡片 (3:4)
const BlogPostCard: React.FC<{ post: BlogPost, onClick: () => void, scrollY: any }> = ({ post, onClick, scrollY }) => {
  const [imgError, setImgError] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);
  const imageScale = useTransform(scrollY, [0, 8000], [1.02, 1.15]);

  return (
    <motion.div 
      onClick={onClick} 
      whileTap={{ scale: 0.96 }} 
      className="flex-shrink-0 w-[75vw] snap-center relative aspect-[3/4] rounded-3xl overflow-hidden bg-zinc-950 border border-white/10 shadow-2xl cursor-pointer transition-transform duration-300"
    >
      {/* 优雅的加载占位符 */}
      <div className={`absolute inset-0 z-0 bg-zinc-900 flex items-center justify-center transition-opacity duration-700 ${isLoaded ? 'opacity-0' : 'opacity-100'}`}>
         <div className="w-12 h-[1px] bg-primary/20 animate-pulse" />
      </div>

      {!imgError ? (
        <motion.img 
          src={post.imageUrl} 
          onLoad={() => setIsLoaded(true)}
          onError={() => setImgError(true)}
          className={`absolute inset-0 w-full h-full object-cover transition-all duration-1000 ${isLoaded ? 'scale-100 blur-0 opacity-100' : 'scale-110 blur-xl opacity-0'}`} 
          style={{ scale: imageScale }} 
          alt={post.title} 
          loading="eager"
          decoding="async"
        />
      ) : (
        <div className="absolute inset-0 flex items-center justify-center bg-zinc-900 z-[2]">
           <div className="flex flex-col items-center gap-2 opacity-20">
             <LayoutGrid className="w-8 h-8 text-zinc-400" />
             <span className="text-[9px] font-black text-zinc-500 uppercase tracking-widest">Image Unavailable</span>
           </div>
        </div>
      )}

      {/* 底部遮罩文字 */}
      <div className="absolute inset-x-0 bottom-0 h-1/2 bg-black/10 backdrop-blur-[25px] pointer-events-none transition-all duration-700 group-hover:h-[55%] group-hover:bg-black/20" style={{ WebkitMaskImage: 'linear-gradient(to top, black 15%, transparent 85%)', maskImage: 'linear-gradient(to top, black 15%, transparent 85%)' }} />
      <div className="absolute inset-x-0 bottom-0 h-2/3 flex flex-col justify-end p-6 z-20 transition-transform duration-700 group-hover:-translate-y-4">
        <div className="space-y-3">
          <div className="flex items-center gap-2.5">
            <span className="px-2.5 py-0.5 rounded bg-primary/20 border border-primary/30 text-[9px] font-black text-primary uppercase tracking-widest">{post.readTime}</span>
            <span className="text-[9px] text-white/40 font-mono tracking-widest">{post.date}</span>
          </div>
          <h3 className="text-xl font-bold leading-[1.2] text-white opacity-100 uppercase tracking-tight line-clamp-3">{post.title}</h3>
          <div className="flex items-center gap-2 text-primary text-[9px] font-black tracking-[0.3em] pt-2">
            EXPLORE <ArrowUpRight className="w-3 h-3" />
          </div>
        </div>
      </div>
    </motion.div>
  );
};

const ExperienceCard: React.FC<{ item: ExperienceType, isActive: boolean, onToggle: () => void, language: Language, labels: any }> = ({ item, isActive, onToggle, language, labels }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-10%" }}
      transition={{ duration: 0.6, ease: "easeOut" }}
      className={`relative pl-6 border-l border-white/10 py-5 transition-colors ${isActive ? 'bg-white/[0.02]' : ''}`}
    >
       {/* Active Indicator on the line */}
       <div className={`absolute left-[-1.5px] top-[2.25rem] w-[3px] h-[3px] rounded-full bg-zinc-500 ${isActive ? 'bg-primary scale-150' : ''} transition-all`} />

       <div onClick={onToggle} className="flex justify-between items-start gap-4">
          <div className="space-y-2">
             <span className="text-[10px] font-mono text-primary font-bold uppercase tracking-widest">{item.period}</span>
             <h3 className="text-xl font-bold text-white uppercase tracking-tight leading-tight">{item.role}</h3>
             <p className="text-sm text-zinc-400 font-medium uppercase tracking-wider">{item.company}</p>
          </div>
          <div className={`w-10 h-10 rounded-full flex items-center justify-center border border-white/10 transition-transform ${isActive ? 'rotate-180 bg-primary border-primary' : ''}`}>
             <ChevronDown className={`w-5 h-5 ${isActive ? 'text-white' : 'text-zinc-600'}`} />
          </div>
       </div>

       <AnimatePresence>
          {isActive && (
            <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden">
               <div className="pt-4 space-y-4">
                  <div className="space-y-4">
                     <div className="flex items-center gap-3"><Target className="w-4 h-4 text-primary/40" /><span className="text-[9px] font-black text-zinc-400 uppercase tracking-widest">{labels.scope}</span></div>
                     <div className="space-y-4 text-zinc-300 text-sm leading-relaxed">
                        {item.responsibilities?.map((r, i) => <p key={i}>{renderRichText(r)}</p>)}
                     </div>
                  </div>
                  <div className="space-y-3">
                     <div className="flex items-center gap-3"><TrendingUp className="w-4 h-4 text-primary/40" /><span className="text-[9px] font-black text-zinc-400 uppercase tracking-widest">{labels.performance}</span></div>
                     <div className="space-y-3">
                        {item.achievements?.map((ach, i) => (
                           <div key={i} className="pl-3 border-l border-primary/20 py-1">
                              <p className="text-zinc-400 text-sm leading-relaxed">{renderRichText(ach)}</p>
                           </div>
                        ))}
                     </div>
                  </div>
                  <button onClick={onToggle} className="flex items-center gap-2 text-[10px] font-black text-zinc-600 uppercase tracking-[0.3em] pt-4"><Minus className="w-3 h-3" /> {labels.collapse}</button>
               </div>
            </motion.div>
          )}
       </AnimatePresence>
    </motion.div>
  );
};

const MobileApp: React.FC<{ language: Language, setLanguage: (l: Language) => void, content: any, expertise: any[] }> = ({ language, setLanguage, content, expertise }) => {
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [selectedPost, setSelectedPost] = useState<BlogPost | null>(null);
  const [activeExpId, setActiveExpId] = useState<string | null>(content.experience[0]?.id || null);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [showFAB, setShowFAB] = useState(false);
  const [blogScrollProgress, setBlogScrollProgress] = useState(0);

  const blogRef = useRef<HTMLDivElement>(null);
  const { scrollY } = useScroll();
  const springScrollY = useSpring(scrollY, { stiffness: 100, damping: 30 });
  const isEn = language === 'EN';
  const philosophy = isEn ? DESIGN_PHILOSOPHY_EN : DESIGN_PHILOSOPHY_CN;

  useEffect(() => {
    const handleScroll = () => {
      const current = window.scrollY;
      setShowFAB(current > window.innerHeight * 0.8);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleBlogScroll = () => {
    if (blogRef.current) {
      const { scrollLeft, scrollWidth, clientWidth } = blogRef.current;
      const progress = scrollLeft / (scrollWidth - clientWidth);
      setBlogScrollProgress(isNaN(progress) ? 0 : progress);
    }
  };

  const handleNavClick = (id: string) => {
    setIsMenuOpen(false);
    setSelectedProject(null);
    setSelectedPost(null);
    const element = document.getElementById(id);
    if (element) {
      const offset = 80;
      window.scrollTo({ top: element.offsetTop - offset, behavior: 'smooth' });
    }
  };

  return (
    <div 
      className="lg:hidden min-h-screen bg-background text-white flex flex-col font-sans overflow-x-hidden relative"
      style={{ wordBreak: 'break-word', hyphens: 'auto' }}
    >
      
      <AnimatePresence>
        {selectedProject && (
          <ProjectDetails project={selectedProject} onClose={() => setSelectedProject(null)} />
        )}
      </AnimatePresence>

      <motion.nav 
        animate={{ y: 0 }}
        className="fixed top-0 left-0 right-0 z-[5000] h-16 px-4 flex items-center justify-between bg-black/60 backdrop-blur-3xl border-b border-white/5"
      >
        <div className="flex items-center gap-3">
          <motion.button whileTap={{ scale: 0.9 }} onClick={() => setIsMenuOpen(true)} className="p-2.5 bg-white/5 rounded-xl border border-white/10">
            <Menu className="w-5 h-5 text-zinc-300" />
          </motion.button>
          <span className="text-sm font-black uppercase tracking-[0.2em] text-white">Janice Mo</span>
        </div>
      </motion.nav>

      <AnimatePresence>
        {showFAB && !selectedProject && !selectedPost && (
          <motion.div initial={{ y: 50, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 50, opacity: 0 }} className="fixed bottom-8 right-6 z-[1500]">
             <button 
               onClick={() => { setSelectedProject(null); setSelectedPost(null); window.scrollTo({top: 0, behavior: 'smooth'}); }} 
               className="w-12 h-12 rounded-full bg-primary flex items-center justify-center shadow-2xl shadow-primary/20 border border-white/10 active:scale-90 transition-transform"
             >
               <ArrowUp className="w-6 h-6 text-white" />
             </button>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {isMenuOpen && (
          <motion.div initial={{ opacity: 0, scale: 1.05 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 1.05 }} className="fixed inset-0 z-[6000] bg-black/95 backdrop-blur-3xl p-8 flex flex-col">
             <div className="flex justify-between items-center mb-12">
                <span className="text-[10px] font-black uppercase tracking-[0.4em] text-zinc-500">Navigation</span>
                <div className="flex items-center gap-4">
                  <button onClick={() => setLanguage(isEn ? 'CN' : 'EN')} className="w-[44px] h-[44px] flex items-center justify-center bg-white/5 border border-white/10 rounded-lg text-[10px] font-black text-primary uppercase">
                    {isEn ? 'CN' : 'EN'}
                  </button>
                  <button onClick={() => setIsMenuOpen(false)} className="w-[44px] h-[44px] flex items-center justify-center bg-white/5 rounded-full border border-white/10"><X className="w-6 h-6" /></button>
                </div>
             </div>
             <div className="flex flex-col gap-8 text-xl font-bold uppercase tracking-[0.2em] flex-1">
                <button onClick={() => handleNavClick('projects')} className="text-left border-b border-white/5 pb-4 flex justify-between items-center"><span>{content.nav.portfolios}</span><ChevronRight className="text-primary w-5 h-5" /></button>
                <button onClick={() => handleNavClick('journey')} className="text-left border-b border-white/5 pb-4 flex justify-between items-center"><span>{content.nav.career}</span><ChevronRight className="text-primary w-5 h-5" /></button>
                <button onClick={() => handleNavClick('awards')} className="text-left border-b border-white/5 pb-4 flex justify-between items-center"><span>{content.nav.awards}</span><ChevronRight className="text-primary w-5 h-5" /></button>
                <button onClick={() => handleNavClick('credentials')} className="text-left border-b border-white/5 pb-4 flex justify-between items-center"><span>{content.nav.credentials}</span><ChevronRight className="text-primary w-5 h-5" /></button>
                <button onClick={() => handleNavClick('insights')} className="text-left border-b border-white/5 pb-4 flex justify-between items-center"><span>{content.nav.blog}</span><ChevronRight className="text-primary w-5 h-5" /></button>
                <div className="pt-4">
                  <DownloadButton href={CV_URL} label={content.nav.downloadCv} />
                </div>
             </div>
          </motion.div>
        )}
      </AnimatePresence>

      <main className="pt-24 px-6 space-y-20">
        {/* HERO */}
        <section className="py-12 space-y-10 relative">
          <MobileAmbientLight />
          <div className="relative z-10 space-y-6">
             <motion.h1 
               initial={{ opacity: 0, letterSpacing: "0.15em", filter: "blur(10px)" }}
               animate={{ opacity: 1, letterSpacing: "0.02em", filter: "blur(0px)" }}
               transition={{ duration: 1.5, ease: [0.16, 1, 0.3, 1] }}
               className="text-[14vw] font-display font-bold leading-[0.85] tracking-tighter uppercase text-white"
             >
               {content.hero.title}
             </motion.h1>
             <p className="text-xl font-bold text-zinc-200 leading-tight uppercase border-l-2 border-primary pl-6 max-w-[80%]">{content.hero.subtitle}</p>
             <p className="text-lg text-zinc-400 font-light leading-relaxed">{content.hero.description}</p>
          </div>
        </section>

        {/* EXPERTISE CONSOLIDATED */}
        <motion.section 
          className="space-y-10"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-50px" }}
          variants={{
            hidden: { opacity: 0 },
            visible: {
              opacity: 1,
              transition: {
                staggerChildren: 0.12
              }
            }
          }}
        >
           <motion.div 
             className="space-y-2"
             variants={{
               hidden: { opacity: 0, y: 80 },
               visible: { opacity: 1, y: 0, transition: { duration: 1.2, ease: [0.44, 0, 0.56, 1] } }
             }}
           >
              <span className="text-[10px] font-black text-primary tracking-[0.5em] uppercase">Core DNA</span>
              <h2 className="text-3xl font-black uppercase tracking-tighter">{isEn ? 'Strategic Value' : '核心价值与专长'}</h2>
           </motion.div>
           <motion.div 
             className="p-8 rounded-[2.5rem] bg-white/[0.03] border border-white/5 space-y-10"
             variants={{
               hidden: { opacity: 0, y: 80 },
               visible: { opacity: 1, y: 0, transition: { duration: 1.2, ease: [0.44, 0, 0.56, 1] } }
             }}
           >
              {expertise.map((item, i) => (
                <div key={i} className="space-y-4 group">
                   <div className="flex items-center gap-4">
                      <h3 className="text-lg font-bold text-white uppercase tracking-tight">{item.title}</h3>
                   </div>
                   <p className="text-sm text-zinc-400 font-light leading-relaxed pl-0">{renderRichText(item.desc)}</p>
                   {i !== expertise.length - 1 && <div className="h-px bg-white/5" />}
                </div>
              ))}
           </motion.div>
        </motion.section>

        {/* PROJECTS */}
        <motion.section 
          id="projects" 
          className="space-y-12"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-50px" }}
          variants={{
            hidden: { opacity: 0 },
            visible: {
              opacity: 1,
              transition: {
                staggerChildren: 0.12
              }
            }
          }}
        >
          <motion.div 
            className="space-y-2"
            variants={{
              hidden: { opacity: 0, y: 80 },
              visible: { opacity: 1, y: 0, transition: { duration: 1.2, ease: [0.44, 0, 0.56, 1] } }
            }}
          >
            <span className="text-[10px] font-black text-primary tracking-[0.5em] uppercase">Featured Cases</span><h2 className="text-4xl font-black uppercase tracking-tighter">{content.portfolio.title}</h2>
          </motion.div>
          <motion.div 
            className="flex flex-col gap-10"
            variants={{
              hidden: { opacity: 0, y: 80 },
              visible: { opacity: 1, y: 0, transition: { duration: 1.2, ease: [0.44, 0, 0.56, 1] } }
            }}
          >
            {content.projects.map((project: any, index: number) => (
              <MorphingProjectCard key={project.id} project={project} onClick={() => setSelectedProject(project)} language={language} index={index} total={content.projects.length} />
            ))}
          </motion.div>
        </motion.section>

        {/* JOURNEY */}
        <motion.section 
          id="journey" 
          className="px-6 space-y-12"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-50px" }}
          variants={{
            hidden: { opacity: 0 },
            visible: {
              opacity: 1,
              transition: {
                staggerChildren: 0.12
              }
            }
          }}
        >
           <motion.div 
             className="space-y-8"
             variants={{
               hidden: { opacity: 0, y: 80 },
               visible: { opacity: 1, y: 0, transition: { duration: 1.2, ease: [0.44, 0, 0.56, 1] } }
             }}
           >
              <div className="space-y-2">
                 <span className="text-[10px] font-black text-primary tracking-[0.5em] uppercase">Career Journey</span>
                 <h2 className="text-4xl font-black uppercase tracking-tighter">{content.nav.career}</h2>
              </div>
              <div className="py-10 border-y border-white/5 space-y-6">
                 <h3 className="text-2xl font-bold text-white uppercase leading-tight tracking-tight">
                    <TextType text={philosophy.quote} typingSpeed={60} loop={false} startOnVisible={true} />
                 </h3>
                 <p className="text-zinc-400 text-sm font-light leading-relaxed">{philosophy.description}</p>
              </div>
           </motion.div>
           <motion.div 
             className="flex flex-col"
             variants={{
               hidden: { opacity: 0, y: 80 },
               visible: { opacity: 1, y: 0, transition: { duration: 1.2, ease: [0.44, 0, 0.56, 1] } }
             }}
           >
              {content.experience.map((item: any) => (
                <ExperienceCard 
                  key={item.id} item={item} 
                  isActive={activeExpId === item.id} 
                  onToggle={() => setActiveExpId(activeExpId === item.id ? null : item.id)}
                  language={language}
                  labels={content.resume.labels}
                />
              ))}
           </motion.div>
        </motion.section>

        {/* AWARDS */}
        <motion.section 
          id="awards" 
          className="px-6 space-y-10"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-50px" }}
          variants={{
            hidden: { opacity: 0 },
            visible: {
              opacity: 1,
              transition: {
                staggerChildren: 0.12
              }
            }
          }}
        >
           <motion.div 
             className="space-y-2"
             variants={{
               hidden: { opacity: 0, y: 80 },
               visible: { opacity: 1, y: 0, transition: { duration: 1.2, ease: [0.44, 0, 0.56, 1] } }
             }}
           >
              <span className="text-[10px] font-black text-primary tracking-[0.5em] uppercase">Honors</span>
              <h2 className="text-3xl font-black uppercase tracking-tighter">{content.nav.awards}</h2>
           </motion.div>
           <motion.div 
             className="space-y-px bg-white/5 rounded-3xl overflow-hidden border border-white/5"
             variants={{
               hidden: { opacity: 0, y: 80 },
               visible: { opacity: 1, y: 0, transition: { duration: 1.2, ease: [0.44, 0, 0.56, 1] } }
             }}
           >
              {content.awards.map((award: any, i: number) => (
                <div key={i} className="bg-zinc-950 p-6 flex items-center justify-between gap-4">
                   <div className="space-y-1">
                      <h4 className="text-sm font-bold text-white uppercase">{award.name.split(' — ')[0]}</h4>
                      <p className="text-[10px] text-zinc-400 font-bold uppercase tracking-widest">{award.desc || award.name.split(' — ')[1]}</p>
                   </div>
                   <Trophy className={`w-5 h-5 shrink-0 ${award.level === 'GOLD' ? 'text-primary' : 'text-zinc-800'}`} />
                </div>
              ))}
           </motion.div>
        </motion.section>

        {/* CREDENTIALS */}
        <motion.section 
          id="credentials" 
          className="px-4 space-y-10"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-50px" }}
          variants={{
            hidden: { opacity: 0 },
            visible: {
              opacity: 1,
              transition: {
                staggerChildren: 0.12
              }
            }
          }}
        >
           <motion.div 
             className="space-y-2"
             variants={{
               hidden: { opacity: 0, y: 80 },
               visible: { opacity: 1, y: 0, transition: { duration: 1.2, ease: [0.44, 0, 0.56, 1] } }
             }}
           >
              <span className="text-[10px] font-black text-primary tracking-[0.5em] uppercase">Verification</span>
              <h2 className="text-3xl font-black uppercase tracking-tighter">{content.nav.credentials}</h2>
           </motion.div>

           {/* Education Section */}
           <motion.div 
             className="space-y-6"
             variants={{
               hidden: { opacity: 0, y: 80 },
               visible: { opacity: 1, y: 0, transition: { duration: 1.2, ease: [0.44, 0, 0.56, 1] } }
             }}
           >
              <div className="flex items-center gap-3 border-b border-white/10 pb-4">
                 <GraduationCap className="w-4 h-4 text-primary/40" />
                 <span className="text-[9px] font-black text-zinc-400 uppercase tracking-widest">{content.resume.eduTitle}</span>
              </div>
              <div className="space-y-0">
                 {content.education.map((edu: any, i: number) => (
                   <div key={i} className="py-6 border-b border-white/5 space-y-3 first:pt-0">
                      <div className="flex justify-between items-start">
                         <div className="space-y-1">
                            <h4 className="text-base font-bold text-white uppercase leading-tight">{edu.school}</h4>
                            <span className="text-[10px] font-mono text-zinc-500 font-bold uppercase">{edu.period}</span>
                         </div>
                      </div>
                      <div className="space-y-2">
                         {edu.degrees.map((degree: string, dIdx: number) => (
                            <div key={dIdx} className="flex items-start gap-3">
                               <div className="w-1 h-1 rounded-full bg-primary mt-1.5 shrink-0" />
                               <span className="text-[13px] text-zinc-400 font-medium leading-snug">{degree}</span>
                            </div>
                         ))}
                      </div>
                   </div>
                 ))}
              </div>
           </motion.div>

           {/* Certificates Section */}
           <motion.div 
             className="space-y-6 pt-2"
             variants={{
               hidden: { opacity: 0, y: 80 },
               visible: { opacity: 1, y: 0, transition: { duration: 1.2, ease: [0.44, 0, 0.56, 1] } }
             }}
           >
              <div className="flex items-center gap-3 border-b border-white/10 pb-4">
                 <Award className="w-4 h-4 text-primary/40" />
                 <span className="text-[9px] font-black text-zinc-400 uppercase tracking-widest">{content.resume.certTitle}</span>
              </div>
            <div className="space-y-0">
               {content.certificates.map((cert: any, i: number) => (
                 <div key={i} className="py-5 border-b border-white/5 flex items-start justify-between gap-4 first:pt-0">
                    <div className="space-y-1 flex-1">
                       <h4 className="text-sm font-bold text-zinc-200 uppercase leading-relaxed">{cert.name}</h4>
                       <span className="text-[10px] font-mono text-zinc-600 font-bold uppercase block">{cert.year}</span>
                    </div>
                    <ShieldCheck className="w-5 h-5 text-primary/60 shrink-0 mt-1" />
                 </div>
               ))}
            </div>
           </motion.div>
        </motion.section>

        {/* INSIGHTS - 小红书横滑风格 */}
        <motion.section 
          id="insights" 
          className="px-6 space-y-10"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-50px" }}
          variants={{
            hidden: { opacity: 0 },
            visible: {
              opacity: 1,
              transition: {
                staggerChildren: 0.12
              }
            }
          }}
        >
          <motion.div 
            className="space-y-2"
            variants={{
              hidden: { opacity: 0, y: 80 },
              visible: { opacity: 1, y: 0, transition: { duration: 1.2, ease: [0.44, 0, 0.56, 1] } }
            }}
          >
            <span className="text-[10px] font-black text-primary tracking-[0.5em] uppercase">Intelligence</span>
            <h2 className="text-4xl font-black uppercase tracking-tighter">{content.blog.title}</h2>
          </motion.div>
          <motion.div 
            ref={blogRef}
            onScroll={handleBlogScroll}
            className="flex gap-5 overflow-x-auto no-scrollbar snap-x snap-mandatory -mx-6 px-6 pb-6 min-h-[400px]"
            variants={{
              hidden: { opacity: 0, y: 80 },
              visible: { opacity: 1, y: 0, transition: { duration: 1.2, ease: [0.44, 0, 0.56, 1] } }
            }}
          >
            {content.blogPosts && content.blogPosts.length > 0 ? (
              content.blogPosts.map((post: any) => (
                <BlogPostCard key={post.id} post={post} onClick={() => setSelectedPost(post)} scrollY={springScrollY} />
              ))
            ) : (
              <div className="flex-1 flex items-center justify-center border border-white/5 rounded-3xl h-80 text-zinc-500 text-xs font-mono uppercase tracking-widest bg-white/5">
                Updating Insights...
              </div>
            )}
          </motion.div>
          <motion.div 
            className="h-[2px] bg-white/5 rounded-full overflow-hidden mx-auto w-1/2"
            variants={{
              hidden: { opacity: 0, y: 80 },
              visible: { opacity: 1, y: 0, transition: { duration: 1.2, ease: [0.44, 0, 0.56, 1] } }
            }}
          >
             <motion.div 
               className="h-full bg-primary origin-left"
               style={{ scaleX: blogScrollProgress }}
             />
          </motion.div>
        </motion.section>

        {/* CONNECT */}
        <motion.section 
          id="connect" 
          className="px-6 py-20 space-y-16 border-t border-white/5"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-50px" }}
          variants={{
            hidden: { opacity: 0 },
            visible: {
              opacity: 1,
              transition: {
                staggerChildren: 0.12
              }
            }
          }}
        >
           <motion.div 
             className="space-y-4"
             variants={{
               hidden: { opacity: 0, y: 80 },
               visible: { opacity: 1, y: 0, transition: { duration: 1.2, ease: [0.44, 0, 0.56, 1] } }
             }}
           >
              <span className="text-[10px] font-black text-primary uppercase tracking-[0.5em]">{content.nav.connect}</span>
              <h2 className="text-5xl font-black uppercase tracking-tighter leading-[0.9]">Let's <br/><span className="text-primary">Sync Up.</span></h2>
           </motion.div>
           <motion.div 
             className="space-y-8"
             variants={{
               hidden: { opacity: 0, y: 80 },
               visible: { opacity: 1, y: 0, transition: { duration: 1.2, ease: [0.44, 0, 0.56, 1] } }
             }}
           >
              <a href={`tel:${content.common.phoneValue}`} className="flex items-center gap-6 active:opacity-60 transition-opacity border-b border-white/5 pb-8">
                 <div className="w-12 h-12 rounded-full bg-white/5 flex items-center justify-center shrink-0">
                   <Phone className="w-5 h-5 text-primary" />
                 </div>
                 <div className="space-y-1 min-w-0">
                    <span className="text-[9px] font-black text-zinc-500 uppercase tracking-widest">{content.common.phoneWechat}</span>
                    <p className="text-xl font-bold text-white whitespace-nowrap">{content.common.phoneValue}</p>
                 </div>
              </a>
              <a href={`mailto:${content.common.emailValue}`} className="flex items-center gap-6 active:opacity-60 transition-opacity">
                 <div className="w-12 h-12 rounded-full bg-white/5 flex items-center justify-center shrink-0">
                   <Mail className="w-5 h-5 text-primary" />
                 </div>
                 <div className="space-y-1 min-w-0">
                    <span className="text-[9px] font-black text-zinc-500 uppercase tracking-widest">{content.common.emailAddr}</span>
                    <p className="text-[17px] sm:text-xl font-bold text-white whitespace-nowrap tracking-tight">{content.common.emailValue}</p>
                 </div>
              </a>
           </motion.div>
        </motion.section>

        <footer className="py-12 border-t border-white/5 text-center">
           <p className="text-[10px] font-black text-zinc-700 uppercase tracking-[0.4em]">{content.footer.rights}</p>
        </footer>
      </main>

      <AnimatePresence>
        {selectedPost && (
          <BlogEditorialLayout post={selectedPost} onClose={() => setSelectedPost(null)} language={language} />
        )}
      </AnimatePresence>

      <style>{`
        .no-scrollbar::-webkit-scrollbar { display: none; }
        .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
      `}</style>
    </div>
  );
};

export default MobileApp;
