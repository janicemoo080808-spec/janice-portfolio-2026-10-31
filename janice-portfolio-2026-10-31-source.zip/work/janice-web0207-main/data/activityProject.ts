export const ACTIVITY_PROJECT_SECTIONS = [
  {
    title: "品牌活动与空间",
    label: "ACTIVITY & SPACE OVERVIEW",
    icon: "Globe",
    images: []
  },
  {
    title: "Token 2049 全球品牌阵地操盘 (2024–2025)",
    label: "GLOBAL BRAND FRONTIER",
    icon: "ShieldCheck",
    description: "作为品牌负责人，我全程主导 Crydit 连续两届在新加坡 Token 2049 的深度亮相。从品牌出海的战略蓝图规划，到全链路视觉导视系统与高科技交互空间的无缝落地，确保在世界级金融流量中心实现品牌价值的高频且一致性输出。",
    images: [
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/campaign/token2049-01.webp",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/campaign/token2049-02.webp",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/campaign/token2049-03.webp",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/campaign/token2049-04.webp",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/campaign/token2049-05.webp",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/campaign/token2049-06.webp"
    ],
    points: [
      "• 累计精准触达全球 50,000+ 行业精英，线上线下协同传播矩阵共计达成 1.2M+ 次品牌曝光。",
      "• 通过差异化的沉浸式空间交互策划，现场高质量 BD 线索转化率较传统展位模式显著提升 35%。",
      "• 统筹跨国供应链及 10+ 全球合作伙伴，在 48 小时极速周期内完成从 0 到 1 的高规格品牌物理空间构建。",
    ],
    isSlider: true
  },
  {
    title: "肯尼亚公益行：以品牌温度赋能全球社区 (2024)",
    label: "GLOBAL ESG CAMPAIGN",
    icon: "Users",
    description: "主导 Crydit 肯尼亚公益行，在受洪灾影响的偏远地区深耕品牌社会责任。通过教育基础设施重建、关键物资捐赠及社区文化建设，成功塑造了品牌在非洲新兴市场的正面形象，建立起超越商业的深层价值链接。",
    images: [
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/campaign/kenya-charity-01.webp",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/campaign/kenya-charity-02.webp",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/campaign/kenya-charity-03.webp",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/campaign/kenya-charity-04.webp",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/campaign/kenya-charity-05.webp"
    ],
    points: [
      "基建重建：全程统筹受灾严重的 Kakola 小学教学楼修缮与加固工程，为逾 500 名学生恢复了安全且长久的受教育环境。",
      "心智占领闭环：精准配置数千册图书、现代化教学具及基础生活物资；并策划首届“Crydit 杯”青少年足球友谊赛，以文化共鸣达成深度的社区情感共振。",
      "媒体背书：活动获肯尼亚国家电视台 (KBC) 及多家当地权威报媒 360° 专题报道，将品牌形象从单一业务逻辑升华为具备国际视野的全球公益标杆。",
      "现场包含大量动人的纪实影像、当地主流媒体报道剪辑及完整的 ESG 项目复盘报告。如需了解品牌如何通过公益活动实现“低成本海外流量获取”与“政府级公信力背书”的策略逻辑，欢迎探讨。"
    ],
    isSlider: true
  },
  {
    title: "品牌重塑：上海贵酒国际版发布会暨徐汇体验中心全案策划",
    label: "REBRANDING & EXPERIENCE",
    icon: "Fingerprint",
    description: "打破传统白酒的陈旧叙事，我主导了上海贵酒“中西融合”的全球品牌叙事体系。从徐汇品牌体验中心的物理空间设计，到国际版发布会的沉浸式全息交互，通过全案闭环策划，成功将品牌推向国际奢侈品赛道。",
    images: [
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/campaign/guijiu-global-launch-01.webp",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/campaign/guijiu-global-launch-02.webp",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/campaign/guijiu-global-launch-03.webp",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/campaign/guijiu-global-launch-04.webp"
    ],
    points: [
      "空间美学逻辑：创新性引入全息影像与多维感官系统，打造了一个融合‘新中式传统’与‘西方超现实主义’的沉浸式视觉场馆。",
      "媒介传播高度：现场吸引了逾 50 家海内外主流及垂直媒体深度报道，社交媒体总曝光量达成 2.0M+，有效实现了从“产品发布”到“文化事件”的圈层跨越。",
      "商业价值闭环：该体验中心现已成为品牌服务高净值人群 (HNWI) 的核心阵地，成功建立起高频、高端的品牌线下交互通路。",
      "本项目涉及完整的全息影像交互脚本、跨时空空间策展方案及全链条公关传播矩阵。受限于网页展示空间，仅呈现核心视觉片段。"
    ]
  },
  {
    title: "CCTV-1 央视大片与“大国品牌”战略操盘",
    label: "NATIONAL NARRATIVE STRATEGY",
    icon: "Trophy",
    description: "深谙权威媒体赋能品牌的长远力量，我主导了上海贵酒两支核心 TVC 广告片的策略定位与视觉执行，并前瞻性布局 CCTV-1 等顶级频道。通过独家冠名 CCTV《大国品牌》等国家级叙事项目，成功将品牌资产与国家级声望深度绑定。",
    points: [
      "权威背书与双重大奖：主导的《大国品牌》系列故事片在第 29 届中国国际广告节荣获“2022 年度内容营销案例”与“2022 媒企合作年度案例”双项大奖，实现了艺术审美与商业价值的国际化公认。",
      "顶级频道心智触达：操盘两支 TVC 广告的全流程视觉与策略，在央视黄金档的精准投放，提升了品牌在全国范围内的市场美誉度。",
      "高品质消费案例：亲自策划并主导“千城万企”项目，在国际高品质消费博览会获评“十大高品质消费创新案例”，实现了品牌影响力对区域市场的降维打击。"
    ],
    images: [],
    videoUrl: "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/video/editorial/cctv-national-brand-01.mp4",
    additionalVideos: [
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/video/editorial/cctv-national-brand-02.mp4",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/video/editorial/cctv-national-brand-03.mp4"
    ]
  }
];