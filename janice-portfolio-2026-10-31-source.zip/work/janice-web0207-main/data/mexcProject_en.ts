import { ProjectSection } from '../types';

// Replace the labelled placeholders with approved MEXC assets and copy only
// publishable copy into the descriptions below. No performance claims are set
// until source material is provided.
export const MEXC_PROJECT_SECTIONS_EN: ProjectSection[] = [
  {
    title: '01 / MEXC Exchange',
    label: 'BRAND CASE OVERVIEW',
    icon: 'Layers3',
    description: 'Brand case structure prepared for approved MEXC materials. This section is intentionally a placeholder while final project context, scope, and publishable media are being collected.',
    images: [],
    isPlaceholder: true,
    placeholderLabel: 'MEXC CASE COVER — APPROVED MEDIA PENDING'
  },
  {
    title: 'MEXC Card',
    label: 'CARD EXPERIENCE',
    icon: 'CreditCard',
    description: 'Editable section for physical and virtual card directions, card-face visual language, material exploration, and presentation applications.',
    images: [],
    isPlaceholder: true,
    placeholderLabel: 'MEXC CARD MATERIALS — PENDING'
  },
  {
    title: 'Mascot & Brand IP',
    label: 'BRAND IP',
    icon: 'SmilePlus',
    description: 'Editable section for character design, motion exploration, expression and pose studies, and merchandise applications.',
    images: [],
    isPlaceholder: true,
    placeholderLabel: 'MASCOT & BRAND IP ASSETS — PENDING'
  },
  {
    title: 'Brand Visual Evolution',
    label: 'VISUAL SYSTEM',
    icon: 'Palette',
    description: 'Editable section for the visual evolution, template system, and standardised design guidance. Add only approved specifications and examples.',
    images: [],
    isPlaceholder: true,
    placeholderLabel: 'BRAND SYSTEM MATERIALS — PENDING'
  },
  {
    title: 'Selected Brand Applications',
    label: 'APPLICATIONS',
    icon: 'PanelsTopLeft',
    description: 'Editable section for selected campaigns, offline materials, events, and brand merchandise. Add a clear project context to each application.',
    images: [],
    isPlaceholder: true,
    placeholderLabel: 'SELECTED APPLICATIONS — PENDING'
  },
  {
    title: 'AI & Design Workflow',
    label: 'CREATIVE OPERATIONS',
    icon: 'Workflow',
    description: 'Editable section for AI skills, design workflows, review practices, and design-guideline optimisation. Add only processes that are approved for publication.',
    images: [],
    isPlaceholder: true,
    placeholderLabel: 'AI & DESIGN WORKFLOW — PENDING'
  }
];
