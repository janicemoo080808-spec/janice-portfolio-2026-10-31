export const ACTIVITY_PROJECT_SECTIONS_EN = [
  {
    title: "Brand Activity & Space",
    label: "ACTIVITY & SPACE OVERVIEW",
    icon: "Globe",
    images: []
  },
  {
    title: "Token 2049 Global Brand Operations (2024–2025)",
    label: "GLOBAL BRAND FRONTIER",
    icon: "ShieldCheck",
    description: "As brand lead, I spearheaded Crydit's continuous appearance at two Token 2049 Singapore events. From strategic blueprints for brand globalization to the seamless execution of full-link visual guidance and high-tech interaction spaces, ensuring high-frequency and consistent brand output at world-class financial hubs.",
    images: [
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/campaign/token2049-01.webp",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/campaign/token2049-02.webp",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/campaign/token2049-03.webp",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/campaign/token2049-04.webp",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/campaign/token2049-05.webp",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/campaign/token2049-06.webp"
    ],
    points: [
      "• Cumulatively reached 50,000+ industry elites globally, with 1.2M+ total brand impressions across online and offline matrices.",
      "• Achieved a 35% higher high-quality BD lead conversion rate than traditional booth models through differentiated immersive space interaction planning.",
      "• Orchestrated a global supply chain and 10+ partners, completing 0-1 high-spec physical brand space construction within an extremely fast 48-hour cycle.",
    ],
    isSlider: true
  },
  {
    title: "Kenya Charity: Empowering Communities with Brand Warmth (2024)",
    label: "GLOBAL ESG CAMPAIGN",
    icon: "Users",
    description: "Led the Crydit Kenya charity mission, deepening brand social responsibility in remote flood-affected areas. Through educational infrastructure reconstruction, key material donations, and community cultural building, we successfully shaped a positive brand image in the emerging African market, establishing a deep value link beyond commerce.",
    images: [
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/campaign/kenya-charity-01.webp",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/campaign/kenya-charity-02.webp",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/campaign/kenya-charity-03.webp",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/campaign/kenya-charity-04.webp",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/campaign/kenya-charity-05.webp"
    ],
    points: [
      "Infrastructure Reconstruction: Led the repair and reinforcement of the flood-damaged Kakola Primary School buildings, restoring a safe and long-term educational environment for over 500 students.",
      "Mental Occupation Loop: Precisely allocated thousands of books, modern teaching aids, and basic supplies; organized the first 'Crydit Cup' youth football match to achieve deep emotional resonance with the community.",
      "Media Endorsement: Activity received 360° coverage from Kenya Broadcasting Corporation (KBC) and local authoritative newspapers, elevating the brand image into a global charity benchmark with international vision.",
      "Includes touching documentary footage, local mainstream media clips, and full ESG project reviews. Let's discuss brand logic on 'low-cost overseas traffic acquisition' and 'government-level credibility endorsement' through charity."
    ],
    isSlider: true
  },
  {
    title: "Rebranding: Shanghai Guijiu International Launch & Xuhui Center",
    label: "REBRANDING & EXPERIENCE",
    icon: "Fingerprint",
    description: "Breaking the stale narrative of traditional Baijiu, I led Shanghai Guijiu's 'East-West Fusion' global brand narrative system. From the physical space design of the Xuhui Experience Center to the immersive holographic interactions of the international launch, we successfully pushed the brand into the international luxury track.",
    images: [
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/campaign/guijiu-global-launch-01.webp",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/campaign/guijiu-global-launch-02.webp",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/campaign/guijiu-global-launch-03.webp",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/campaign/guijiu-global-launch-04.webp"
    ],
    points: [
      "Spatial Aesthetic Logic: Innovative introduction of holography and multi-sensory systems, creating an immersive venue merging 'Neo-Chinese Tradition' with 'Western Surrealism'.",
      "Media Reach: Attracted over 50 domestic and overseas mainstream and niche media for deep reporting, with 2.0M+ social media impressions, turning a 'product launch' into a 'cultural event'.",
      "Business Value Loop: This experience center is now a core hub serving high-net-worth individuals (HNWI), establishing a high-frequency, high-end offline interaction channel.",
      "Features full holographic interaction scripts and space curation plans. Shown here are core visual fragments due to space limits."
    ]
  },
  {
    title: "CCTV-1 National Brand Narrative Strategy",
    label: "NATIONAL NARRATIVE STRATEGY",
    icon: "Trophy",
    description: "Understanding the power of authoritative media, I led the strategic positioning and visual execution of two core TVCs for Shanghai Guijiu, proactively placing them on top channels like CCTV-1. Through exclusive naming of national projects like CCTV's 'National Brand,' we successfully bonded brand assets with national prestige.",
    points: [
      "Authoritative Endorsement & Dual Awards: The 'National Brand' series won '2022 Content Marketing Case of the Year' and '2022 Media-Enterprise Cooperation Case of the Year' at the 29th China International Advertising Festival.",
      "Top Channel Reach: Lead the full visual and strategic process for two TVCs, achieving high brand recognition nationwide through prime-time CCTV slots.",
      "High-Quality Consumption Case: Personally initiated and led the 'Thousand Cities Ten Thousand Enterprises' project, rated a 'Top Ten High-Quality Consumption Innovation Case' at international expos."
    ],
    images: [],
    videoUrl: "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/video/editorial/cctv-national-brand-01.mp4",
    additionalVideos: [
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/video/editorial/cctv-national-brand-02.mp4",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/video/editorial/cctv-national-brand-03.mp4"
    ]
  }
];