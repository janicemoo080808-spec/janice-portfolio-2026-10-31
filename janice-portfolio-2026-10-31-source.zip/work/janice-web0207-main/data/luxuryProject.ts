
export const LUXURY_PROJECT_SECTIONS = [
  {
    title: "奢侈品美学与调性",
    label: "PROJECT OVERVIEW",
    icon: "Sparkles",
    images: []
  },
  {
    title: "LOEWE：有机超现实主义与触感温润",
    label: "LOEWE",
    icon: "Sparkles",
    description: "捕捉品牌独有的智性趣味与工匠精神。艺术指导的核心在于营造一种“梦境般的自然主义”。",
    images: [
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/luxury/loewe-organic-01.webp",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/luxury/loewe-organic-02.webp",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/luxury/loewe-organic-03.webp",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/luxury/loewe-organic-04.webp"
    ]
  },
  {
    title: "Loro Piana：静谧奢华与纤维之巅",
    label: "LORO PIANA",
    icon: "Layers",
    description: "深入 Loro Piana 的静谧奢华语境，通过视觉语言传达稀有纤维的触感美学与大自然的永恒韵律。",
    images: [
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/luxury/loropiana-fiber-01.webp",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/luxury/loropiana-fiber-02.webp",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/luxury/loropiana-fiber-03.webp"
    ],
    videoUrl: "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/video/luxury/loropiana-fiber-04.mp4"
  },
  {
    title: "CARTIER ：隽永光影",
    label: "CARTIER",
    icon: "Zap",
    description: "我以克制而精准的电影语言，主导了这场关于‘永恒’的光影探索，捕捉那些凝固在时光中的优雅瞬间。",
    images: [
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/luxury/cartier-light-01.webp",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/luxury/cartier-light-02.webp"
    ],
    points: [
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/video/luxury/cartier-light-03.mp4",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/video/luxury/cartier-light-04.mp4"
    ]
  }
];
