import { Project, ExperienceItem, BlogPost, EducationItem, CertificateItem, SiteContent, CategoryType } from '../types';
import { AI_CREATIVE_SECTIONS_EN } from './aigcProject_en';
import { WEB3_PROJECT_SECTIONS_EN } from './web3Project_en';
import { LUXURY_PROJECT_SECTIONS_EN } from './luxuryProject_en';
import { AUTOMOTIVE_PROJECT_SECTIONS_EN } from './automotiveProject_en';
import { ACTIVITY_PROJECT_SECTIONS_EN } from './activityProject_en';

export const CV_URL = 'https://janice-cv-1395762740.cos.ap-shanghai.myqcloud.com/JaniceMo_BrandCreative_CV_CN%2BEN.pdf';

export const PHILOSOPHY_EN = {
  quote: "Leveraging Aesthetics to Drive Business Growth.",
  description: "Aesthetics void of strategy is mere noise. I do not engineer mere eye candy—I architect commercial systems that convert fleeting attention into enduring asset value. Amidst the cacophony of algorithms, clarity is the ultimate competitive advantage."
};

export const EXPERTISE_EN = [
  { title: "Cross-Domain Strategy", desc: "9+ years of expertise across **Web3, Luxury, Automotive, and FMCG**. Expert at breaking industrial homogeneity through cross-disciplinary thinking, translating complex models into **instant visual narratives**." },
  { title: "Full-Chain Brand Ops", desc: "From **top-level deduction** to **pixel-perfect deployment**. Operating as a 'Value Architect' for brand assets, ensuring strategic precision at every touchpoint to achieve **maximum commercial ROI**." },
  { title: "AIGC Workflow Design", desc: "Architecting **Human-AI collaboration hubs**. Integrating AI into enterprise workflows—from model training to content scaling—reducing costs while ensuring **Brand Sovereignty**." },
  { title: "Agile Execution Leadership", desc: "Combines creative leadership with technical coaching. Leverages AI to scale team output, enabling a five-person team to perform at the level of a much larger organization." }
];

const projects_en: Project[] = [
  {
    id: 'p-aigc-en',
    title: 'AIGC Strategy & Production',
    category: 'AI_CREATIVE',
    subCategory: 'STRATEGY',
    description: 'Architecting proprietary AI engines to scale creative output exponentially.',
    imageUrl: 'https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/cover/cover7.webp',
    sections: AI_CREATIVE_SECTIONS_EN,
    tags: ['AI Strategy', 'Workflow', 'System Design']
  },
  {
    id: 'p-web3-en',
    title: 'Web3 Ecosystem',
    category: 'BRAND_ECOSYSTEM',
    subCategory: 'IDENTITY',
    description: 'Building trust foundations for Crydit, defining crypto luxury aesthetics.',
    imageUrl: 'https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/cover/cover2.webp',
    sections: WEB3_PROJECT_SECTIONS_EN,
    tags: ['Web3', 'Fintech', 'Identity']
  },
  {
    id: 'p-luxury-en',
    title: 'Luxury Aesthetics & Tone',
    category: 'LUXURY_DESIGN',
    subCategory: 'CONTENT_CREATION',
    description: 'Visual narrative practices within the LVMH ecosystem, reshaping digital sensory experiences.',
    imageUrl: 'https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/cover/cover1.webp',
    sections: LUXURY_PROJECT_SECTIONS_EN,
    tags: ['Luxury', 'Aesthetics', 'LVMH']
  },
  {
    id: 'p-auto-en',
    title: 'Smart Mobility',
    category: 'AUTOMOTIVE_DESIGN',
    subCategory: 'SYSTEMS',
    description: 'Merging industrial aesthetics with digital experience for future mobility.',
    imageUrl: 'https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/cover/cover3.webp',
    sections: AUTOMOTIVE_PROJECT_SECTIONS_EN,
    tags: ['Automotive', 'Smart Mobility', 'UI/UX']
  },
  {
    id: 'p-activity-en',
    title: 'Brand Activity & Space',
    category: 'ACTIVITY_VISUALS',
    subCategory: 'CAMPAIGN',
    description: 'From Token 2049 to global CSR, defining brand sovereignty through space.',
    imageUrl: 'https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/campaign/token2049-01.webp',
    sections: ACTIVITY_PROJECT_SECTIONS_EN,
    tags: ['Space', 'Global', 'Campaign']
  }
];

export const CONTENT_EN: SiteContent = {
  nav: {
    portfolios: "Portfolios",
    career: "Experience",
    credentials: "Credentials",
    awards: "Awards",
    blog: "Insights",
    connect: "Connect",
    downloadCv: "Download CV"
  },
  hero: {
    title: "JANICE MO",
    subtitle: "Brand & Experience Director / AIGC Architect",
    description: "A strategic sniper utilizing AI as a sight to precisely reconstruct global brand aesthetic assets and narrative logic.",
    cta: "Explore Works",
    available: "OPEN FOR COLLABORATION"
  },
  resume: {
    aboutTitle: "Strategic Architect",
    aboutText: "9+ years of cross-domain visual strategy, specialized in Web3, Luxury, and Mobility. Transforming complex logic into instant visual narratives.",
    stats: { exp: "9+ Years", projects: "50+", awards: "15+" },
    skillsTitle: "Core Skills",
    experienceTitle: "Journey",
    eduTitle: "Education",
    certTitle: "Certificates",
    labels: {
      journey: "Career Journey",
      impact: "Commercial Impact",
      viewMore: "VIEW MORE",
      reportTo: "Reporting To",
      scope: "Core Scope",
      performance: "Key Results",
      collapse: "Collapse Details"
    }
  },
  portfolio: {
    title: "Curated Portfolio",
    subtitle: "SELECTED WORKS",
    filters: {
      all: "All",
      activity: "Events",
      brand_ecosystem: "Web3",
      luxury: "Luxury",
      automotive: "Mobility",
      fnb: "Commercial",
      ai_drama: "AI Creative"
    }
  },
  blog: {
    title: "INSIGHTS",
    subtitle: "INSIGHTS",
    readMore: "Read More"
  },
  footer: {
    rights: "© 2026 JANICE MO. "
  },
  experience: [
    {
      id: 'exp-crydit',
      role: 'Brand Director & Design Director',
      company: 'Shanghai Tianzhuoyue Tech (Crydit)',
      period: '2023.12 – 2026.01',
      reportingTo: 'CEO',
      companyIntro: 'Crydit is a blockchain asset payment platform providing innovative transaction solutions for crypto users.',
      responsibilities: ['As a core startup member, I built the brand system from 0 to 1.'],
      achievements: ['Strategic Full-Case & 0-1 Construction: authored brand strategies.', 'Growth: Built Twitter content matrix, boosting brand awareness by 80%.']
    }
  ],
  education: [
    { school: "Harbin University of Science and Technology", period: "2014 – 2018", degrees: ["Visual Communication Design"] }
  ],
  certificates: [
    { year: "2023", name: "LVMH Luxury Brand Management Certificate" }
  ],
  skills: [],
  projects: projects_en,
  blogPosts: [],
  aiContext: "Janice Mo is a Brand Design Lead at MEXC Exchange, specialising in brand systems, cross-channel applications, and AI-enabled design workflows.",
  awards: [
    { name: "New York Product Design Awards — Silver Winner", desc: "Silver Winner", level: "SILVER" }
  ],
  common: {
    selectedWorks: "Selected Works",
    intelligence: "Insights",
    getInTouch: "Get In Touch",
    phoneWechat: "Phone / WeChat",
    emailAddr: "Email",
    // Fix: Added missing phoneValue and emailValue properties
    phoneValue: "18621568644",
    emailValue: "maoyujun08@163.com",
    awardsSubtitle: "International Honors",
    awardsDesc: "Multiple design awards validating global implementation standards."
  }
};
