
export const AUTOMOTIVE_PROJECT_SECTIONS_EN = [
  {
    title: "Smart Mobility Brand",
    label: "PROJECT OVERVIEW",
    icon: "Globe",
    description: "Cross-disciplinary practice of Digitalization and Industrial Aesthetics.\n\nFocusing on Rivian's digital experience reconstruction and the 0-1 strategic construction of the INTU brand. Defining the inspiration boundaries of future mobility through simulated real interaction logic and CMF narrative.",
    images: []
  },
  {
    title: "Rivian Official Website Interaction Design",
    label: "DIGITAL EXPERIENCE",
    icon: "Monitor",
    description: "This collaboration focused on the visual design and experience reconstruction of Rivian's official website, creating an ultimate digital exploration texture.",
    images: ["https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/mobility/assets%3Aimg%3Amobility%3Arivian-web-experience.webp"]
  },
  {
    title: "INTU Brand Strategy 0-1: From Function to Inspiration",
    label: "STRATEGIC ARCHITECTURE",
    icon: "Cpu",
    description: "Not building cold machines, but creating a soulmate for urban inspiration. INTU, as a 'lifestyle tech brand,' is a 'provider of urban inspiration.'",
    images: ["https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/mobility/assets%3Aimg%3Acover%3Aintu-brand-cover.webp"]
  },
  {
    title: "Visual Narrative & CMF Aesthetic System Design",
    label: "VISUAL & CMF SYSTEM",
    icon: "Layers",
    isSlider: true,
    description: "Integrating brand identity, independently designing interior and exterior CMF colors and original concept scenes, building a complete 'lifestyle tech' visual language system. Transforming urban street slices into materials to balance aesthetics and human emotions.",
    images: [
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/editorial/assets%3Aimg%3Aeditorial%3Aintu-cmf-01.webp",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/editorial/assets%3Aimg%3Aeditorial%3Aintu-cmf-02.webp",
      "https://cdn.jsdelivr.net/gh/janicemoo080808-spec/picx-images-hosting@master/毛宇君个人设计作品集(高清版)_页面_10.1hsoucbxzd.webp",
      "https://cdn.jsdelivr.net/gh/janicemoo080808-spec/picx-images-hosting@master/毛宇君个人设计作品集(高清版)_页面_11.eszktuu8e.webp"
    ]
  },
  {
    title: "Three-Act Campaign Strategy Planning",
    label: "CAMPAIGN STRATEGY",
    icon: "Rocket",
    description: "Strategy Core: Acute Entry × Cross-border Resonance × Scene Penetration. We packaged the communication rhythm as a 'City Inspiration Movie' trilogy.",
    points: [
      "Act I: Inspiration Opening | Theme: INSPIRED by FUN (Starting from Inspiration, Who it's for)\n\n• Ali Design Week Debut: Partnered with Alibaba Cloud Design at U Design Week to talk 'Design Inspiration' instead of parameters. Turned car body colors into 'slices of urban streetscapes,' defining INTU's exclusive color codes.\n• Bilibili 'The No Show Room': Refused traditional car reviews. Partnered with strict UP-loaders for 'abnormal' tests in extreme cold and tricky angles, endorsing 'pragmatism' with real strength.\n• 'Creativity Unlimited Corp' Hiring: Partnered with North Star Youth for autumn recruitment. Not hiring workers, only peers like 'Chief Inspiration Officers' to attract the most ambitious youth through high-topic engagement.",
      "Act II: Highlight Moment | Theme: Ins to U (Injecting Inspiration into Life)\n\n• INTU x LEGO: Launched same-size LEGO 'Inspiration Boxes,' conveying the car's gene of being full of creative fun and infinite possibilities like LEGO.\n• INTU x Nintendo Switch: Created a 'Mobile Game Center,' emphasizing high-performance car-machine interconnect for immersive gaming, directly hitting young audience entertainment pain points.\n• Cultural Tone: Partnered with GQ Lab for the ICON Project, mining stories from internal car builders and urban change-makers to tell a 'non-defined' brand spirit.\n• Variety Show Trigger: Sponsored 'Roast' and actively 'asked to be roasted,' showing brand openness and confidence through a non-typical car company persona.",
      "Act III: City Roaming | Theme: Ins to City (Injecting Inspiration into the City)\n\n• Inspiration General Store: Instead of traditional 4S shops, selling coffee, peripheral products, and design in trendy neighborhoods. Donating income to charity, integrating the brand into urban balance.\n• Hoarding Art: Partnered with OUTPUT artists to turn renovation hoardings into city center countdown devices, creating social check-in heat before opening.\n• 48 Hours is Enough: Launched weekend travel plans; booking premium homestays gets you a two-day deep test drive, turning test driving into a micro-vacation.\n• OT Night Shuttle: Caring for late-night office workers by providing free night shuttles, offering warm space at tired moments, proving brand value with temperature."
    ],
    images: [
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/campaign/intu-campaign-01.webp"
    ]
  }
];
