
export const WEB3_PROJECT_SECTIONS_EN = [
  {
    title: "02 / Crydit Financial Ecosystem",
    label: "BRAND CASE OVERVIEW",
    icon: "ShieldCheck",
    description: "Building the foundation of trust for decentralized finance.\n\nAs Brand & Experience Director, I led the 0-1 visual identity construction, strategic positioning, digital product design, and global PR strategy for Crydit. Providing global crypto users with an asset management experience defined by 'Trust' and 'High-end feel'.",
    images: ["https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/cover/cover2.webp"]
  },
  {
    title: "Core Visual Identity Standard",
    label: "VISUAL IDENTITY",
    icon: "Fingerprint",
    description: "Establishing the underlying visual DNA of Crydit, defining fintech through a highly geometric symbolic system.",
    images: ["https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/web3/crydit-visual-identity.webp"]
  },
  {
    title: "Strategic Positioning & Brand Manual",
    label: "BRAND STRATEGY",
    icon: "BookOpen",
    description: "From market competitive analysis to brand context deduction, I built a complete brand narrative logic, establishing a unique tone for an international fintech brand.",
    images: ["https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/web3/crydit-brand-strategy.webp"]
  },
  {
    title: "Digital Portal & Global Hub",
    label: "DIGITAL PORTAL",
    icon: "Globe",
    description: "Emphasizing efficient information flow and Web3 interaction aesthetics to enhance user trust in digital asset management.",
    images: ["https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/web3/crydit-digital-portal.webp"]
  },
  {
    title: "Fintech Core Product Interface",
    label: "UI/UX DESIGN",
    icon: "Smartphone",
    description: "Focusing on mobile UI/UX for decentralized asset management, providing a smooth operational experience while meeting compliance requirements.",
    images: ["https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/web3/crydit-product-ui.webp"]
  },
  {
    title: "Authoritative PR & Global Endorsement",
    label: "PR & GLOBALIZATION",
    icon: "Trophy",
    description: "Maintaining highly consistent brand voice in top financial media and international exhibitions to establish global industry credibility.",
    images: ["https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/web3/crydit-global-pr.webp"]
  },
  {
    title: "Social Narrative & IP Personalization",
    label: "SOCIAL NARRATIVE",
    icon: "Users",
    isSlider: true,
    description: "Building a warm IP narrative on social platforms, transforming complex Web3 concepts into easily shareable emotional content to bridge the gap with users.",
    images: [
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/web3/crydit-social-ip-01.webp",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/web3/crydit-social-ip-02.webp",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/web3/crydit-social-ip-03.webp",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/web3/crydit-social-ip-04.webp",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/web3/crydit-social-ip-05.webp"
    ]
  },
  {
    title: "Official Website Design",
    label: "WEBSITE DESIGN",
    icon: "Monitor",
    description: "Restricted by NDA, core data and sensitive info involved in the project have been desensitized or replaced.",
    images: ["https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/web3/crydit-website-design.webp"]
  }
];
