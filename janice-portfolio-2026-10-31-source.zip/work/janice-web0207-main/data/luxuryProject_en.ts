
export const LUXURY_PROJECT_SECTIONS_EN = [
  {
    title: "Luxury Aesthetics & Tone",
    label: "PROJECT OVERVIEW",
    icon: "Sparkles",
    images: []
  },
  {
    title: "LOEWE: Organic Surrealism & Tactile Warmth",
    label: "LOEWE",
    icon: "Sparkles",
    description: "Capturing the brand's unique intellectual wit and craftsmanship. The core of artistic direction lies in creating a 'dreamlike naturalism'.",
    images: [
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/luxury/loewe-organic-01.webp",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/luxury/loewe-organic-02.webp",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/luxury/loewe-organic-03.webp",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/luxury/loewe-organic-04.webp"
    ]
  },
  {
    title: "Loro Piana: Quiet Luxury & The Peak of Fibers",
    label: "LORO PIANA",
    icon: "Layers",
    description: "Delving into Loro Piana's quiet luxury context, conveying the tactile aesthetics of rare fibers and the eternal rhythm of nature through visual language.",
    images: [
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/luxury/loropiana-fiber-01.webp",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/luxury/loropiana-fiber-02.webp",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/luxury/loropiana-fiber-03.webp"
    ],
    videoUrl: "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/video/luxury/loropiana-fiber-04.mp4"
  },
  {
    title: "CARTIER: Timeless Light",
    label: "CARTIER",
    icon: "Zap",
    description: "Using restrained and precise cinematic language, I led this exploration of 'eternity' through light and shadow, capturing elegant moments frozen in time.",
    images: [
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/luxury/cartier-light-01.webp",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/luxury/cartier-light-02.webp"
    ],
    points: [
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/video/luxury/cartier-light-03.mp4",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/video/luxury/cartier-light-04.mp4"
    ]
  }
];
