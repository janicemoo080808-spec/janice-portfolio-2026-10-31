
export const WEB3_PROJECT_SECTIONS = [
  {
    title: "02 / Crydit 金融生态",
    label: "品牌案例概览",
    icon: "ShieldCheck",
    description: "构建去中心化金融的信任基石\n\n作为品牌与体验总监，我主导Crydit 从 0 到 1 的视觉身份构建、战略定位、数字化产品设计及全球化公关策略。为全球加密用户提供极具“信任感”与“高级感”的资产管理体验。",
    images: ["https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/cover/cover2.webp"]
  },
  {
    title: "核心视觉身份标准",
    label: "VISUAL IDENTITY",
    icon: "Fingerprint",
    description: "建立 Crydit 的底层视觉基因，通过高度几何化的符号系统定义金融科技。",
    images: ["https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/web3/crydit-visual-identity.webp"]
  },
  {
    title: "战略定位与品牌手册",
    label: "BRAND STRATEGY",
    icon: "BookOpen",
    description: "从市场竞争分析到品牌语境推演，构建了一套完整的品牌叙事逻辑，确立国际化金融科技品牌的独特调性。",
    images: ["https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/web3/crydit-brand-strategy.webp"]
  },
  {
    title: "数字化门户与官方枢纽",
    label: "DIGITAL PORTAL",
    icon: "Globe",
    description: "强调信息层级的高效流动与 Web3 交互美学，提升用户对数字资产管理的信任感。",
    images: ["https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/web3/crydit-digital-portal.webp"]
  },
  {
    title: "金融科技核心产品界面",
    label: "UI/UX DESIGN",
    icon: "Smartphone",
    description: "专注于去中心化资产管理的移动端 UI/UX，在满足合规性要求的条件下提供流畅的操作体验。",
    images: ["https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/web3/crydit-product-ui.webp"]
  },
  {
    title: "权威公关与全球化背书",
    label: "PR & GLOBALIZATION",
    icon: "Trophy",
    description: "在顶级金融媒体与国际展会中保持高度一致性的品牌发声，建立全球化的行业信誉。",
    images: ["https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/web3/crydit-global-pr.webp"]
  },
  {
    title: "社交叙事与 IP 人格化",
    label: "SOCIAL NARRATIVE",
    icon: "Users",
    isSlider: true,
    description: "在社交平台构建具有温度的 IP 叙事，将复杂的 Web3 概念转化为易于传播的感性内容，拉近与用户的距离。",
    images: [
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/web3/crydit-social-ip-01.webp",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/web3/crydit-social-ip-02.webp",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/web3/crydit-social-ip-03.webp",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/web3/crydit-social-ip-04.webp",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/web3/crydit-social-ip-05.webp"
    ]
  },
  {
    title: "官网页面设计",
    label: "WEBSITE DESIGN",
    icon: "Monitor",
    description: "受保密协议 (NDA) 限制，项目中涉及的核心数据与敏感信息已做脱敏或替换处理。",
    images: ["https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/web3/crydit-website-design.webp"]
  }
];
