
import { ExperienceItem } from '../types';

export const EXPERIENCE_EN: ExperienceItem[] = [
  {
    id: 'exp-mexc',
    role: 'Brand Design Lead',
    company: 'MEXC Exchange',
    period: '2026.04 – Present',
    companyIntro: 'Started 27 April 2026.',
    responsibilities: [
      'Building and standardising the brand visual system.',
      'Leading design work for MEXC Card, brand IP, and brand assets.',
      'Supporting online and offline brand applications through cross-functional collaboration.',
      'Improving AI-assisted design workflows and design guidelines.'
    ],
    achievements: []
  },
  {
    id: 'exp-crydit',
    role: 'Brand Director & Design Director',
    company: 'Shanghai Tianzhuoyue Tech (Crydit)',
    period: '2023.12 – 2026.01',
    reportingTo: 'CEO',
    companyIntro: 'Crydit is a blockchain asset payment platform providing innovative transaction solutions for crypto users.',
    responsibilities: [
      'As a core startup member, I built the brand system from 0 to 1. In the resource-scarce early days, I was both director and executor, establishing internal design teams and workflows while securing top-tier exhibitions like Token 2049, ensuring every cent was spent effectively.'
    ],
    achievements: [
      'Strategic Full-Case & 0-1 Construction: Independently authored brand marketing strategies, defining "Crypto Luxury" differentiation and global narrative. Completed user research, VIS system, UI interactive prototypes, and code spec writing.',
      'Team Management & Efficiency: Recruited and built a highly agile design team from 0-1. Management innovation: introduced AIGC workflows and LoRA model libraries, shortening project cycles by 15% through technical S.O.P.s.',
      'Cross-department & Resource Orchestration: Deeply collaborated with Product, Marketing, and Sales to align the value chain from "Product Function" to "Market Narrative." Managed multinational supplier pools for high-end boutique production.',
      'Core Campaigns & Growth: Token 2049 Global Front: Coordinated 10+ partners across borders, deploying high-spec booths in 48h. Reached 50,000+ elites, increasing BD conversion by 35%. Growth: Built Twitter content matrix, boosting brand awareness by 80% in 6 months.'
    ]
  },
  {
    id: 'exp-zotye',
    role: 'Senior Brand Visual Manager',
    company: 'Shanghai Junqu Auto (Zotye)',
    period: '2022.5 – 2023.6',
    reportingTo: 'Brand Director',
    companyIntro: 'The core operating body of Zotye Auto (000980), focused on global new energy vehicle layouts.',
    responsibilities: [
      'Acted as a visual hub connecting "Engineering Tech" and "User Experience" in the fierce NEV market. Responsible for defining visual language and managing cross-department needs and massive supplier systems.'
    ],
    achievements: [
      'Full-Case Control & Standards: Independently created and implemented brand VIS specs, ensuring pixel-perfect consistency across digital and physical terminals.',
      'Cross-border Collaboration: R&D Synergy: Led CMF (Color/Material/Finish) design for new models, testing 50+ leathers to solve craftsmanship hurdles. Supplier Management: Coordinated agencies and exhibition builders to meet rigorous car industry standards.',
      'Core Performance: Transformed abstract "Life Tech" concepts into tactile experiences and lifestyle narratives, ensuring competitive advantage in visuals and experience.'
    ]
  },
  {
    id: 'exp-gujie',
    role: 'Senior Brand Manager & Executive Assistant to President',
    company: 'China Guijiu Group (600696)',
    period: '2021.11 – 2022.4',
    reportingTo: 'CMO (Marketing President)',
    companyIntro: 'An A-share listed liquor group redefining high-end Chinese Baijiu with international standards.',
    responsibilities: [
      'Assisted CMO and President in brand management systems for the listed group. Multi-threaded project management and high-level resource integration.',
    ],
    achievements: [
      'Management & Organization: Responsible for full-cycle orchestration of key group projects, including rapid team formation and cross-subsidiary coordination. Completed system design and execution for the Huao Group within 2 months.',
      'Public Relations & Endorsement: Integrated group resources to interface with national media. CCTV-1 "National Brand": Led exclusive sponsorship, winning dual awards at the Advertising Festival for "Content Marketing Case of the Year."',
      'Innovation Performance: Planned the "Thousand Cities Ten Thousand Enterprises" project, awarded "Top Ten High-Quality Consumption Innovation Cases."'
    ]
  },
  {
    id: 'exp-chunmai',
    role: 'Visual Design Manager',
    company: 'Shanghai Chunmai Brand Management',
    period: '2018.7 – 2021.10',
    reportingTo: 'Executive Director',
    companyIntro: 'Exclusive brand operator for the French flour brand Les Moulines d\'Antoine in Mainland China.',
    responsibilities: [
      'Responsible for the overall visual strategy of the French brand in China. Driving sales with design and building management capability from zero.',
    ],
    achievements: [
      'Team Building: Led a design team through KPI management and skill coaching, completing full-case outputs from VI and packaging to spatial design.',
      'Business Conversion: Leading the team to design 20+ new product packages, optimizing visuals based on e-commerce data to drive 10x year-on-year sales growth. Managed construction of offline "Internet Famous" shops.',
      'Rebranding: Independently completed the brand VIS 2.0 upgrade, establishing standardized systems still in use today.'
    ]
  },
  {
    id: 'exp-jd',
    role: 'Visual Designer (Intern)',
    company: 'JD.com (Beijing Jingdong)',
    period: '2017.02 – 2018.07',
    companyIntro: 'A top Chinese e-commerce giant.',
    responsibilities: [
      'Practical training at a top tech firm. Established foundational knowledge in "Data-Driven Design" and "User Conversion Logic" within a high-traffic environment.'
    ],
    achievements: [
      'S-Class Mega Promotions: Deeply participated in page design for JD’s major campaigns (618, Double 11), ensuring brand consistency across massive materials.',
      'E-commerce Conversion: Designed promotion pages with strong conversion focus. Gained insights into the commercial logic of "Visuals Serving GMV."'
    ]
  }
];
