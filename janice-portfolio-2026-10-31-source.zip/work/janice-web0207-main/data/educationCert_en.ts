
import { EducationItem, CertificateItem } from '../types';

export const EDUCATION_EN: EducationItem[] = [
  {
    school: "Harbin University of Science and Technology",
    period: "2014 – 2018",
    degrees: [
      "Visual Communication Design 【First Degree】",
      "Human Resource Management 【Second Degree】"
    ]
  }
];

export const CERTIFICATES_EN: CertificateItem[] = [
  {
    year: "2023",
    name: "LVMH Luxury Brand Management Certificate",
    focus: "Luxury Brand Strategy & Operations Management"
  },
  {
    year: "2025",
    name: "Google Data Analytics Professional Certificate",
    focus: "SQL, Tableau, R & Data Driven Decision Making"
  },
  {
    year: "2025",
    name: "Google Digital Marketing & E-commerce Professional Certificate",
    focus: "SEO, SEM & Customer Journey Optimization"
  },
  {
    year: "2025",
    name: "Google UX Design Professional Certificate",
    focus: "UX Research, Prototyping & Figma Master Class"
  }
];
