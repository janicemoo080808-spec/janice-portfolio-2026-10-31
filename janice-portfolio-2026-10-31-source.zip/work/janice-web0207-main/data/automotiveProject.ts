
export const AUTOMOTIVE_PROJECT_SECTIONS = [
  {
    title: "智能出行品牌",
    label: "PROJECT OVERVIEW",
    icon: "Globe",
    description: "数字化与工业美学的跨界实践\n\n聚焦于 Rivian 的数字体验重构与 INTU 品牌从 0 到 1 的战略构建。通过模拟真实的交互逻辑与 CMF 叙事，定义未来出行的灵感边界。",
    images: []
  },
  {
    title: "Rivian 官网交互体验设计",
    label: "DIGITAL EXPERIENCE",
    icon: "Monitor",
    description: "本次合作聚焦于 Rivian 官网的视觉设计与体验重构，营造极致的数字探险质感。",
    images: ["https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/mobility/assets%3Aimg%3Amobility%3Arivian-web-experience.webp"]
  },
  {
    title: "INTU 品牌战略0-1：从功能到灵感",
    label: "STRATEGIC ARCHITECTURE",
    icon: "Cpu",
    description: "不造冷冰冰的机器，只做懂你的都市灵感伴侣。INTU 作为“生活科技品牌”是城市生活的“灵感提供商”。",
    images: ["https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/mobility/assets%3Aimg%3Acover%3Aintu-brand-cover.webp"]
  },
  {
    title: "视觉叙事与CMF 美学系统设计",
    label: "VISUAL & CMF SYSTEM",
    icon: "Layers",
    isSlider: true,
    description: "整合品牌标识、独立设计内外饰 CMF 颜色设计与原创概念场景，构建一套完整的“生活科技”视觉语言体系。将城市街景切片转化为材质，实现美学与人文情感的平衡。",
    images: [
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/editorial/assets%3Aimg%3Aeditorial%3Aintu-cmf-01.webp",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/editorial/assets%3Aimg%3Aeditorial%3Aintu-cmf-02.webp",
      "https://cdn.jsdelivr.net/gh/janicemoo080808-spec/picx-images-hosting@master/毛宇君个人设计作品集(高清版)_页面_10.1hsoucbxzd.webp",
      "https://cdn.jsdelivr.net/gh/janicemoo080808-spec/picx-images-hosting@master/毛宇君个人设计作品集(高清版)_页面_11.eszktuu8e.webp"
    ]
  },
  {
    title: "三幕式传播战役规划",
    label: "CAMPAIGN STRATEGY",
    icon: "Rocket",
    description: "策略核心：锐角切入 × 跨界共振 × 场景渗透。我们将传播节奏包装为一部“都市灵感电影”的三部曲。",
    points: [
      "第一幕：灵感启幕 ｜ 主题：INSPIRED by FUN (始于启发，为谁而生)\n\n• 阿里设计周首秀：联合 Alibaba Cloud Design，在 U Design Week 上不讲参数，只讲“设计灵感”。把车身颜色变成“城市街景的切片”，定义属于 INTU 的专属色号。\n• B站 “The No Show Room”：拒绝传统车评。联合最严苛 UP 主打造极寒、刁钻角度等“反常规”测试，用实力为“务实”理念背书。\n• “创造力无限公司”招聘：联合北辰青年发起秋招。不招打工人只招同类“首席灵感官”，通过高话题度吸引最有野心的年轻人。",
      "第二幕：高光时刻 ｜ 主题：Ins to U (灵感注入生活)\n\n• INTU x LEGO：推出同尺寸乐高“灵感盒子”，传达车像乐高般充满创造乐趣与无限可能的基因。\n• INTU x Nintendo Switch：打造“移动游戏厅”，强调车机高性能互联，在车内沉浸式游戏，直击年轻群体娱乐痛点。\n• 文化定调：联合 GQ Lab 发起 ICON Project，挖掘内部造车人与城市创变者故事，讲述“不被定义”的品牌精神。\n• 综艺引爆：赞助《吐槽大会》并主动“求吐槽”，以“自黑”展现品牌开放自信的非典型车企人设。",
      "第三幕：城市漫游 ｜ 主题：Ins to City (灵感注入城市)\n\n• 灵感杂货铺：不做传统 4S 店，在网红街区售卖咖啡、周边与设计。收入捐赠公益，将品牌融入城市平衡点。\n• 围挡艺术：联合 OUTPUT 艺术家将装修围挡变成城市中心倒计时装置，在开业前即制造社交打卡热潮。\n• 48 小时够你玩：推出周末旅行计划，预订精品民宿即可获得两天深度试驾权，让试驾变成一次微度假。\n• 深夜接驳车 (OT Night Shuttle): 关注大厂加班族提供深夜免费接驳，在疲惫时刻提供温暖空间，用温度证明品牌价值。"
    ],
    images: [
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/campaign/intu-campaign-01.webp"
    ]
  }
];
