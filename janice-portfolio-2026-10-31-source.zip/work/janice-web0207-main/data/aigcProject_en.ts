export const AI_CREATIVE_SECTIONS_EN = [
  {
    title: "Silicon Strategy: Autonomous Brand Audit & Asset Architecture",
    label: "PROJECT: SILICON STRATEGY // BRAND DIRECTOR & ARCHITECT",
    icon: "Cpu",
    description: "I am not just using AI to generate content; I am designing a cognitive system that transforms raw information into strategic judgment.\n\nWhile most teams still rely on manual periodic market research and data organization, I have built a hybrid agent architecture to accelerate brand judgment, structure core assets, and establish a continuous information advantage while ensuring security and control.",
    images: ["https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/cover/cover7.webp"],
    points: [
      "This system is not for 'automating creativity,' but for solving a core management problem: how to transform noise into actionable signals faster in a highly overloaded information environment.",
      "【System Structure】 Hybrid Agent Architecture: This architecture explicitly separates 'Environmental Scanning' from 'Asset Control' and designs specialized agent roles for each.",
      "【Cloud Auditor · Scanning Layer】 Manus (Cloud Agent):\nFunction: Global market reconnaissance\nRole: Decision-support catalyst, not the primary arbiter\n• Autonomously scans major competitors' seasonal brand activities and visual systems\n• Covers visual language, CMF trends, and narrative patterns in public channels\n• Outputs structured audit results for management reference\nAll cloud analysis is for trend identification and information compression, not for brand direction or aesthetic decisions.\nStatus: Audit reports generated overnight",
      "【Local Architect · Execution Layer】 Clawdbot (Local Agent):\nFunction: Core asset structuring and execution\nRole: Transforming judgment into a localized system\n• Processes core brand design assets in a local secure environment\n• Reorganizes internal asset libraries based on confirmed trend judgments at a semantic level\n• Builds dynamic 'Style DNA' structures to support team collaboration and rapid deployment\nCore brand assets remain within the local system, ensuring security, control, and organizational consistency.\nStatus: Local secure execution complete",
      "Efficiency Comparison:\nDimension | Traditional Method | Hybrid Agent Orchestration\nMarket Audit Cycle | Approx. 2 Weeks (Manual) | Overnight (Autonomous Scan)\nInfo Coverage | Local Sampling | Global Public Information\nAsset Organization | Static Classification | Dynamic Semantic Structure\nStrategic Response | Passive | Proactive Prediction\nDecision Readiness | Lagging | Continuously Online",
      "【Architect's Note】 The velocity of noise-to-signal conversion: Future core competitiveness lies not in acquiring more information, but in the speed at which you can transform unordered information into a structural form that can be judged and executed.",
      "【Decision Authority】 Final judgment always rests with humans. All strategic level decisions—including brand positioning, visual boundaries, and risk/trade-off decisions—are made by brand and creative leads. The agent system's role is to: compress information, reduce decision latency, and eliminate repetitive management overhead. They do not define style, take responsibility, or replace aesthetics.",
      "【Project Result】 Decision preparation time significantly shortened, team always works based on the latest information, security and consistency of core assets guaranteed, managers can focus on high-value judgment layers.",
      "【Positioning Summary】 This case is not about AI tools themselves, but about demonstrating how managers can design systems that let organizations think faster and decide more steadily."
    ]
  },
  {
    title: "CREATIVE INFRASTRUCTURE | Organizational Evolution",
    label: "ORGANIZATIONAL DESIGN",
    icon: "Layers",
    description: "A core pain point for enterprises is the non-replicability of senior creativity. As a Creative Architect, I am committed to building a 'Human-AI Collaboration Hub.' By encapsulating private models with standardized workflows, I empower junior talent with director-level output capabilities, achieving organizational evolution from 'linear growth' to 'exponential scaling.'",
    images: [
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/blog/aigc-case02-workflow-architect-squad-decision.webp",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/blog/aigc-creative-architecture-insight-01.webp"
    ],
    points: [
      "Impact Data (Organizational Efficiency):\nDIMENSION | TRADITIONAL TEAM | AI-AUGMENTED SQUAD\nStructure | Pyramid | Hub & Spoke\nJunior Role | Execution (Clipping) | Generation (Creative Ideation)\nOutput Cap | Limited by Experience | Limited by Imagination\nScalability | High Cost | Zero Marginal Cost"
    ]
  },
  {
    title: "Netflix Production: VERMILION",
    label: "CASE STUDY 02: NARRATIVE FILM",
    icon: "Monitor",
    description: "Netflix-level historical thriller: Zero-cost virtual set design.\n\nHistorical themes usually represent the cost ceiling of film production: expensive silk costumes, grand palace sets, and hundreds of extras.\nWho says AI doesn't understand Eastern aesthetics? Period dramas used to be the cost peak. Here, I trained AI to be the 'Art Director.' From the pearls on a phoenix crown to the murderous intent in eyes, everything is algorithmically generated. In 48 hours, I completed pre-production that would take a traditional crew 3 months.",
    images: [
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/editorial/vermilion-atmosphere-01.webp",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/editorial/vermilion-atmosphere-02.webp"
    ],
    videoUrl: "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/video/editorial/vermilion-performance-loop.mp4",
    points: [
      "\nimagine prompt: Subject: Close-up of a powerful Chinese Empress, intricate gold headdress, sharp eyeliner, intense gaze. Atmosphere: Dark palace interior, candle lights in background, mysterious, Netflix thriller series style. Tech: Shot on ARRI Alexa 65, vintage Cooke lenses, cinematic color grading. --ar 2.39:1 --style raw --v 7.0 --s 250",
      "Many believe AI completed 3 months of pre-production in 48 hours. Notice the slight twitch of the Empress's mouth and the change in her gaze—this isn't random pixel generation; this is 'directed' performance."
    ]
  },
  {
    title: "Aston Martin: SILVER WINGS",
    label: "CASE 03: ASTON MARTIN - CLIENT STRATEGY",
    icon: "Rocket",
    description: "Designing for the 0.1% requires 100% precision.\n\nPrivate Previews for top supercars are not just about showing the car—it's a lifestyle field. Traditional 3D workflows struggle to quickly validate complex 'Light-Material-Space' interactions early on (e.g., the flow of metallic paint on a DB12 under specific lighting).\n\nIn this project, as an Experience Architect, I built a high-end spatial decision system based on Midjourney V7 + Stable Diffusion to rapidly validate physical feasibility of light, material, and space during early design phases.",
    images: [],
    points: [
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/luxury/astonmartin-silverwings-interface-01.webp",
      "Caption: In the proposal demo, I drove the system with hand-drawn sketches, generating 30 material/lighting combinations (from British walnut to liquid silver) in 1 hour, collaborating in real-time with the client to lock the final direction.",
      "STEP 01. Line Structure: Constrained organic sketches defining the brand's British curves. Input strict aerodynamic structural constraints to capture the brand's unique 'British Aerodynamic Curve.'",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/luxury/astonmartin-silverwings-sketch-01.webp",
      "Caption: Instructions: Architectural sketch of a fluid organic pavilion, inspired by Aston Martin DB12 grille curves, minimalist flowing lines, black on white paper, rough pencil drawing style, da vinci sketch aesthetic --ar 16:9 --raw",
      "STEP 02. Material Expression: Quickly comparing 'Classic Gentleman' vs. 'Avant-garde Agent.' Use semantic control to rapidly validate two entirely different brand narratives.",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/luxury/astonmartin-silverwings-cmf-01.webp",
      "Caption: STEP 03 — Primary Hero — Light-Validated Moment",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/luxury/astonmartin-silverwings-hero-01.webp",
      "Caption: Hero Visual: The Golden Hour under light validation (Phase One quality).",
      "STEP 03 — Spatial Context",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/luxury/astonmartin-silverwings-spatial-01.webp",
      "Caption: Spatial context: Architecture as a light controller (including water surface reflection samples).",
      "STEP 03 — Material & Light Fidelity Check (extreme close up)",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/video/luxury/astonmartin-silverwings-material-01.mp4",
      "Caption: Material and Light Fidelity: Micro-reflections of car paint and tactile validation.",
      "STEP 03 — Temporal State — Pre-Event Transition",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/luxury/astonmartin-silverwings-temporal-01.webp",
      "Caption: Temporal state: The critical moment before the launch (evening transition).",
      "Efficiency Data:\n• Iterations: 30 material combinations within 60 minutes.\n• Decision Speed: 2 rounds of communication -> 1 hour to lock direction (traditionally takes 2 weeks).\n• Efficiency: Visualization cycle reduced by approx. 60-80%.",
      "From feedback loops to real-time correction. The rapid nature of this workflow allowed me to achieve 'real-time collaborative creation' with the client during the proposal. We settled the final design direction in 1 hour, completely replacing what used to be two weeks of back-and-forth email communication.",
      "Efficiency Data Table:\nDimension | Traditional Rendering | My AI Workflow\nDrafting Speed | 2 Days per concept | 30 Concepts per hour\nMateriality | Slow Adjustment | Instant Texturing (Semantic level)\nLighting | Bake time: 8 hours | Real-time Raytracing\nClient Buy-in | 'Imagination needed' | 'Photoreal confirmation'"
    ]
  },
  {
    title: "HIPAY | Expanding Decision Boundaries in Web3 Payment with AI",
    label: "CASE STUDY 04: WEB3 PAYMENT",
    icon: "BarChart3",
    description: "HIPAY is a conceptual Web3 aggregate payment product prototype, primarily for cross-border payments and crypto asset consumption scenarios.\n\nFor me, this project is more of a practice in 'when should design intervene in judgment' rather than a standard product design task.\n\nIn a complex system like Web3 with many constraints, if design only intervenes for visual packaging at the end, many critical problems are already too late to discuss.\nSo this time I focused more on: can design establish an understanding of the system earlier, and judge directions based on that understanding, even before clear conclusions are made.\n\nI did not participate in the underlying technical or protocol design, but I needed to clarify complex information relationships and make relatively stable choices at the experience and brand levels. This work itself constitutes the most valuable part of the project.",
    images: [
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/web3/hipay-payment-logic-01.webp",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/web3/hipay-payment-ui-01.webp"
    ],
    points: [
      "Project Context | Elaboration",
      "The complexity of Web3 payment is much higher than traditional products. On-chain assets, fiat settlement, compliance requirements, user trust—all these factors exist simultaneously and are intertwined.\n\nIn such an environment, if design only waits until the end to intervene, it often can only passively accept fixed structures, making it hard to truly influence experience stability.\n\nThis project aims to verify: Can design enter the judgment stage earlier before conclusions are fully determined, rather than waiting until all decisions have been made?",
      "My Role | Core Responsibilities",
      "In HIPAY, my focus was not on defining product logic, but on seeing the system clearly first.\n\nIncluding:\n• Clarifying relationships between different modules\n• Transforming complex information into discussable experience directions\n• Reducing understanding deviations between design, product, and tech\n\nThe tool's role here is simple—it lets me see the structure faster, rather than deciding for me. The final judgment still needs to be made by humans.",
      "Workflow Overview",
      "This time I reorganized some tools into a process to assist judgment, used to speed up the journey from idea to discussable prototype.\n\nDirections that might have taken one to two weeks to verify were compressed into a much shorter time window. Speed itself is not the point; the point is: can design enter judgment earlier, rather than decorating it after a conclusion is reached?",
      "Step 1 | Let Payment Logic Precede Interface Formation",
      "In the early stages, I didn't go straight into UI design but first clarified payment paths and state logic.\n\nThe focus was to confirm several things:\n• Which funding states must be clearly perceived by users\n• Which complex processes should be absorbed by the system rather than exposed to users\n• Which expressions will directly affect the sense of trust\n\nThrough conversational tools and whiteboard mapping, I first established a discussable structure of payment paths and states, ensuring subsequent design is built on clear logic rather than visual assumptions.\n\nThe goal of this stage is not interface output, but ensuring we understand the same system. Only when logic is clear can visual and interaction judgments truly be meaningful.",
      "Step 2 | Exploring Design Directions within Product Constraints",
      "Once the boundaries of product logic became gradually clear, I entered the visual and interaction layer exploration.\n\nIn this stage, I acted more as a direction judge than a pure executor of design.\nNeeded to quickly judge:\n• How information priority is ranked in financial payment scenarios\n• Which visual language helps establish security intuition\n• Which expressions should be eliminated early\n\nThrough auxiliary tools, I could test multiple directions in parallel within a short time, pulling the discussion back from 'is it pretty' to 'is it credible and clear.' The focus is not producing more interfaces, but forming verifiable judgments as early as possible.",
      "Step 3 | Establishing a Consensus Mechanism Between Design and Engineering",
      "In HIPAY, I am more concerned about whether design can be accurately implemented rather than if the interface is finished.\n\nIf engineering needs to guess design intent, risk is amplified.\nTherefore, design here is more of an intermediate language used to express structure, states, and priorities, rather than a pure visual result.\n\nIn this stage, I organize design results into expressions closer to the engineering context, such as:\n• Component structure and reuse relationships\n• Interaction instructions under different states\n• Clear priorities and conditional changes\n\nThese contents are not code, but they help the team reduce understanding deviations during implementation. Design is no longer just a 'reference image' but a consensus carrier that can directly enter review and implementation flows.\n\nOn 'Unfinishedness'\n\nIn HIPAY, I deliberately kept part of the interface in an unfinished state. The reason is simple: premature visual certainty often creates a false sense of stability. In high-risk systems, keeping discussion space is more important than pursuing completeness. Moderate white space and structural expression help the team clearly see which parts are still being evaluated, rather than being covered by visual form. In payment systems, premature certainty is sometimes more dangerous than imperfection.",
      "My Thinking | Design Lead’s Note",
      "In high-risk, complex fields like Web3, the value of design often doesn't manifest in the final visual presentation, but in whether it can establish an understanding of the system earlier and make judgments based on that understanding. Tools didn't change the essence of design; they just let me see system structures, information relationships, and potential boundaries faster, allowing me to focus on what's more important: judgment, trade-offs, and direction. I show this case not to prove design can replace product or technical decisions, but to show that when design enters the understanding stage earlier, subsequent judgments are more stable and controllable.",
      "My Delivery Standard | THE LEADER'S TOOLKIT",
      "Beyond visuals, I build assets that belong to the enterprise.",
      "🏆 Private Model Library: 3 Brand-exclusive LoRA models (solidifying Brand DNA).",
      "📚 Prompt Dictionary: 200+ Standardized prompt libraries (0-threshold onboarding for junior teams).",
      "⚙️ Workflow S.O.P.: 4 AIGC Collaboration Whitepapers (Standard Operating Procedures)."
    ]
  }
];