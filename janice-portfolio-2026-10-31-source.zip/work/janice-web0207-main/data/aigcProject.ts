export const AI_CREATIVE_SECTIONS = [
  {
    title: "硅基战略：自主品牌审计与资产架构体系",
    label: "PROJECT: SILICON STRATEGY // BRAND DIRECTOR & ARCHITECT",
    icon: "Cpu",
    description: "我并不是用 AI 生成内容，而是在 design 一套 system，把信息转化为判断。\n\n当多数团队仍依赖人工进行周期性的市场调研与资料整理时，我构建了一套混合智能体架构，用于加速品牌判断、结构化核心资产，并在确保安全与控制权的前提下，建立持续的信息先发优势。",
    images: ["https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/cover/cover7.webp"],
    points: [
      "该体系并非为了“自动化创意”，而是解决一个管理层面的核心问题：在信息高度过载的环境中，如何更快地把噪音转化为可执行的判断。",
      "【系统结构】 混合智能体架构设计：该架构将 信息感知 与 资产控制 明确拆分为两个层级，并为其分别设计不同的智能体角色。",
      "【云端审计者 · 信息感知层】 Manus（云端智能体）：\n职能：全球市场侦察\n角色定位：判断辅助，而非决策主体\n• 自主扫描全球主要竞品的当季品牌活动与视觉系统\n• 覆盖公开渠道中的视觉语言、CMF 趋势与叙事模式\n• 输出结构化审计结果，为管理层提供判断参考\n所有云端分析仅用于趋势识别与信息压缩，不参与品牌方向与审美决策。\n状态: 审计报告隔夜生成",
      "【本地架构师 · 资产执行层】 Clawdbot（本地智能体）：\n职能：核心资产结构化与执行\n角色定位：将判断转化为可落地系统\n• 在本地安全环境中处理企业核心设计资产\n• 基于已确认的趋势判断，对内部素材库进行语义级重组\n• 构建动态「风格 DNA」结构，支持团队协作与快速调用\n核心品牌资产始终保留在本地系统中，确保安全性、可控性与组织一致性。\n状态: 本地安全执行完成",
      "效能对比:\n维度 | 传统方式 | 混合智能体编排\n市场审计周期 | 约 2 周（人工） | 隔夜完成（自主扫描）\n信息覆盖率 | 局部抽样 | 广域公开信息\n资产整理方式 | 静态分类 | 动态语义结构\n战略响应方式 | 被动 | 主动预判\n决策准备状态 | 滞后 | 持续在线",
      "【架构师笔记】 将噪音转化为信号的速度：未来的核心竞争力，不在于获取更多信息，而在于 多快能将无序信息转化为可判断、可执行的结构。\n在该体系中，我刻意为 AI 设定了清晰边界：云端智能体用于加速感知，本地智能体用于放大执行。而 品牌方向判断、审美边界设定、风险与取舍决策 始终由人类主导。AI 不替代判断，它只确保判断始终建立在最新信息之上。",
      "【决策权归属】 最终判断权始终由人类负责. 所有战略层决策——包括品牌定位、视觉边界与风险取舍——均由品牌与创意负责人做出。智能体系统的职责在于：压缩信息、降低决策延迟、消除重复性管理消耗。它们不定义风格，不承担责任，也不替代审美。",
      "【项目结果】 决策准备时间显著缩短，团队始终基于最新信息工作，核心资产安全性与一致性得到保障，管理者可聚焦高价值判断层。",
      "【定位总结】 这个案例并不在讨论 AI 工具本身，而是在展示：管理者如何通过系统设计，让组织更快思考、更稳决策。"
    ]
  },
  {
    title: "CREATIVE INFRASTRUCTURE | 组织架构进化",
    label: "ORGANIZATIONAL DESIGN",
    icon: "Layers",
    description: "企业的核心痛点在于资深创意的不可复制性. 作为创意架构师，我致力于搭建一套“人机协作中枢”。通过封装私有模型 with 标准化工作流，让初级人才具备总监级的产出能力，实现从“线性增长”到“指数级裂变”的组织进化。",
    images: [
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/blog/aigc-case02-workflow-architect-squad-decision.webp",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/blog/aigc-creative-architecture-insight-01.webp"
    ],
    points: [
      "Impact Data (组织效能数据):\nDIMENSION | TRADITIONAL TEAM | AI-AUGMENTED SQUAD\nStructure | Pyramid (金制层级) | Hub & Spoke (去中心化网络)\nJunior Role | Execution (执行/抠图) | Generation (创意生成)\nOutput Cap | Limited by Experience | Limited by Imagination\nScalability | High Cost | Zero Marginal Cost"
    ]
  },
  {
    title: "Netflix 影视制作：VERMILION",
    label: "CASE STUDY 02: NARRATIVE FILM",
    icon: "Monitor",
    description: "Netflix 级历史惊悚剧：零成本的虚拟置景\n\n历史题材通常代表着影视制作的成本天花板：昂贵的丝绸戏服、宏大的宫廷置景以及成百上千的群演。\n谁说 AI 不懂东方美学？古装剧曾是成本天花板。在这里，我训练 AI 成为‘美术指导’。从凤冠的珍珠到眼神的杀气，全由算法生成。我在 48 小时内，完成了传统剧组 3 个月的前期筹备。",
    images: [
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/editorial/vermilion-atmosphere-01.webp",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/editorial/vermilion-atmosphere-02.webp"
    ],
    videoUrl: "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/video/editorial/vermilion-performance-loop.mp4",
    points: [
      "\nimagine prompt: Subject: Close-up of a powerful Chinese Empress, intricate gold headdress, sharp eyeliner, intense gaze. Atmosphere: Dark palace interior, candle lights in background, mysterious, Netflix thriller series style. Tech: Shot on ARRI Alexa 65, vintage Cooke lenses, cinematic color grading. --ar 2.39:1 --style raw --v 7.0 --s 250",
      "很多人认为 AI 48 小时内，完成了传统剧组 3 个月的前期筹备。注意视频中皇后嘴角的微动和眼神的变化——这不是随机生成的像素，这是被“导演”过的演技。"
    ]
  },
  {
    title: "Aston Martin ：SILVER WINGS",
    label: "CASE 03: ASTON MARTIN - CLIENT STRATEGY",
    icon: "Rocket",
    description: "为 0.1% 的人 design，需要 100% 的精准。\n\n顶级超跑的 Private Preview 并非单纯的展车——它是一个生活方式的场域. 传统 3D 流程难以在早期快速验证复杂的“光—材质—空间”交互（例如 DB12 金属漆在特定光照下的流动感）。\n\n本项目中，我作为体验架构师，构建了一套基于 Midjourney V7 + Stable Diffusion 的高奢空间决策系统，用于在设计早期快速验证光线、材质与空间的物理可行性。",
    images: [],
    points: [
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/luxury/astonmartin-silverwings-interface-01.webp",
      "Caption: 提案演示中，我用手绘草图驱动系统，在 1 小时内推演出 30 套材质/光照组合（从英伦胡桃木到液态银），并实时与客户协作锁定最终方向。",
      "STEP 01. 线稿结构: 有约束的有机线稿, 定义品牌英伦曲线. 输入严格的流线型结构限制, 捕捉品牌独有的“英伦空气动力学曲线”。",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/luxury/astonmartin-silverwings-sketch-01.webp",
      "Caption: ",
      "指令：Architectural sketch of a fluid organic pavilion, inspired by Aston Martin DB12 grille curves, minimalist flowing lines, black on white paper, rough pencil drawing style, da vinci sketch aesthetic --ar 16:9 --raw ",
      "STEP 02. 材质表现：快速比对“经典绅士”与“先锋特工”。\n通过语义控制，快速验证两种截然不同的品牌叙事。",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/luxury/astonmartin-silverwings-cmf-01.webp",
      "Caption: ",
      "STEP 03 — Primary Hero — Light-Validated Moment",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/luxury/astonmartin-silverwings-hero-01.webp",
      "Caption: 主视觉：光线验证下的黄金时刻（Phase One 质感）",
      "STEP 03 — Spatial Context",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/luxury/astonmartin-silverwings-spatial-01.webp",
      "Caption: 空间语境：建筑作为光线控制器（含水面反射示例）。",
      "STEP 03 — Material & Light Fidelity Check (extreme close up)",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/video/luxury/astonmartin-silverwings-material-01.mp4",
      "Caption: 材质与光线校验：车漆微观反射与触感验证。",
      "STEP 03 — Temporal State — Pre-Event Transition",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/luxury/astonmartin-silverwings-temporal-01.webp",
      "Caption: 时间状态：发布会前的临界时刻（傍晚过渡）。",
      "效能数据：\n• 迭代次数：60 分钟内推演 30 套材质组合。\n• 决策速度：2 轮沟通 -> 1 小时内锁定方案（传统流程通常需 2 周）。\n• 降本增效：可视化周期缩短约 60-80%。",
      "从反馈循环到实时修正。这种工作流的极速特性让我在提案现场实现了与客户的‘实时协同创作’。我们在 1 小时内就敲定了最终的设计方向，彻底取代了以往长达两周的邮件反复沟通。”",
      "效能数据表 / Efficiency Data:\n维度 | 传统渲染 | 我的 AI 工作流\nDrafting Speed | 2 Days per concept (每版2天) | 30 Concepts per hour (每小时30版)\nMateriality | Slow Adjustment (贴图调整慢) | Instant Texturing (语义级材质切换)\nLighting | Bake time: 8 hours (烘焙耗时) | Real-time Raytracing (实时光影)\nClient Buy-in | \"Imagination needed\" (需靠脑补) | \"Photoreal confirmation\" (实景确认)"
    ]
  },
  {
    title: "HIPAY｜用 AI 扩展我在 Web3 支付项目中的决策边界",
    label: "CASE STUDY 04: WEB3 PAYMENT",
    icon: "BarChart3",
    description: "HIPAY 是一个处在概念阶段的 Web3 聚合支付产品 prototype，主要面向跨境支付和加密资产消费场景。\n\n这个项目对我来说，更像一次关于“设计什么时候应该介入判断”的实践，而不是一个常规的产品设计任务。\n\n在 Web3 这样结构复杂、约束很多的系统里，如果设计只在最后阶段做视觉包装，很多关键问题其实已经来不及讨论了。  \n所以这次我更关注的是：在还没有明确结论之前，设计能否更早建立对系统的理解，并基于这些理解去判断方向。\n\n我没有参与底层技术或协议设计，但需要把复杂的信息关系理清，并在体验与品牌层面做出相对稳妥的选择。这部分工作本身，也构成了这个项目最有价值的地方。",
    images: [
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/web3/hipay-payment-logic-01.webp",
      "https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/web3/hipay-payment-ui-01.webp"
    ],
    points: [
      "Project Context｜背景阐述",
      "Web3 支付的复杂度，比传统产品要高得多。  \n链上资产、法币结算、合规要求、用户信任，这些因素同时存在，而且彼此牵连。\n\n在这样的环境里，设计如果只等到最后再介入，往往只能被动接受既定结构，很难真正影响体验的稳定性。\n\n这个项目想验证的是：  \n在结论尚未完全确定之前，设计是否可以更早进入判断阶段，而不是等到所有决定都已经做完。",
      "My Role｜我的核心职责",
      "在 HIPAY 中，我的工作重点并不是定义产品逻辑，而是先把系统本身看清楚。\n\n包括：\n• 理清不同模块之间的关系  \n• 把复杂信息转化为可以讨论的体验方向  \n• 在设计、产品和技术之间减少理解偏差  \n\n工具在这里的作用很简单——它让我更快看清结构，  \n而不是替我做决定。  \n最终的判断仍然需要由人来完成。",
      "Workflow Overview｜工作流概览",
      "这次我把一些工具重新组织成一套辅助判断的流程，用来加快从想法到可讨论原型的过程。\n\n原本可能需要一到两周才能验证的方向，被压缩到了更短的时间窗口。  \n速度本身不是重点，重点在于：  \n设计是否能更早进入判断，而不是在结论确定之后再去修饰它。",
      "Step 1｜让支付逻辑先于界面成形",
      "项目初期，我没有直接进入 UI 设计，而是先把支付路径与状态逻辑理清。\n\n重点是确认几件事：\n\n• 哪些资金状态必须被用户清楚感知\n\n• 哪些复杂流程应该由系统消化，而不是暴露给用户\n\n• 哪些表达方式会直接影响信任感\n\n通过对话式工具和白板梳理，我先建立了一套可讨论的支付路径与状态结构，让后续设计建立在清晰的逻辑基础上，而不是视觉假设之上。\n\n这一阶段的目标不是产出界面，而是确保我们理解的是同一个系统。\n\n只有当逻辑被看清，视觉与交互判断才真正有意义。",
      "Step 2｜在产品约束内探索设计方向",
      "当产品逻辑的边界逐渐清晰之后，我才进入视觉与交互层的探索。\n\n在这个阶段，我更像一个方向判断者，而不是单纯执行设计的人。\n需要快速判断：\n\n• 在金融支付场景中，信息的优先级如何排序\n\n• 哪种视觉语言更有助于建立安全直觉\n\n• 哪些表达方式应该被尽早排除\n\n通过辅助工具，我可以在较短时间内并行测试多个方向，把讨论从“好不好看”拉回到“是否可信、是否清晰”。\n\n重点不是产出更多界面，而是尽早形成可被验证的判断。",
      "Step 3｜建立设计到工程之间的共识机制",
      "在 HIPAY 中，我更关注设计是否能被准确实现，而不是界面本身是否完成。\n\n如果工程需要去猜测设计意图，风险会被放大。\n因此，设计在这里更像一种中间语言，用来表达结构、状态和优先级，而不是单纯的视觉结果。\n\n在这个阶段，我会把设计结果整理为更接近工程语境的表达方式，例如：\n\n• 组件结构与复用关系\n\n• 不同状态下的交互说明\n\n• 明确的优先级与条件变化\n\n这些内容不是代码，但可以帮助团队在实现过程中减少理解偏差。\n\n设计不再只是“参考图”，而是可以直接进入评审与实现流程的共识载体。\n\n关于“未完成感”\n\n在 HIPAY 中，我刻意保留了一部分界面的未完成状态。\n\n原因很简单：\n过早的视觉确定，往往会制造一种虚假的稳定感。\n而在高风险系统里，保持讨论空间，比追求完整更重要。\n\n适度的留白和结构化表达，可以帮助团队清楚地看到哪些部分仍在评估中，而不是被视觉形式掩盖。\n\n在支付系统里，过早的确定性，有时比不完美更危险。",
      "我的思考｜Design Lead’s Note",
      "在 Web3 这样高风险、结构复杂的领域里，设计的价值往往不体现在最后一步的视觉呈现，而在于是否能够更早建立对系统的理解，并基于这种理解做出判断。\n\n工具并没有改变设计的本质。\n它只是让我更快看清系统结构、信息关系和潜在边界，从而把精力放在更重要的事情上：判断、取舍，以及方向。\n\n我展示这个案例，并不是为了证明设计可以替代产品或技术决策，而是想说明：\n当设计更早进入理解阶段，后续的判断会更稳定，也更可控。",
      "我的交付标准｜THE LEADER'S TOOLKIT",
      "Beyond visuals, I build assets that belong to the enterprise.",
      "🏆 Private Model Library: 3 个品牌专属 LoRA 模型 (Brand DNA 固化).",
      "📚 Prompt Dictionary: 200+ 标准化提示词库 (让初级团队 0 门槛上手).",
      "⚙️ Workflow S.O.P.: 4 套 AIGC 协作白皮书 (标准化作业程序)."
    ]
  }
];