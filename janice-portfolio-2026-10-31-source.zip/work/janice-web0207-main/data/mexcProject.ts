import { ProjectSection } from '../types';

// 请在获得可公开的 MEXC 文案与素材后，直接替换下列占位内容和 images 数组。
// 当前不使用任何虚构图片、业务数据或项目成果。
export const MEXC_PROJECT_SECTIONS: ProjectSection[] = [
  {
    title: '01 / MEXC Exchange',
    label: '品牌案例概览',
    icon: 'Layers3',
    description: '已建立 MEXC 品牌案例的页面结构。项目背景、职责范围和可公开素材将在确认后补充；当前保留清晰占位，不虚构项目成果。',
    images: [],
    isPlaceholder: true,
    placeholderLabel: 'MEXC 案例封面 — 待补充审核素材'
  },
  {
    title: 'MEXC Card',
    label: '卡片体验',
    icon: 'CreditCard',
    description: '用于编辑实体与虚拟卡、卡面视觉、材质探索及展示效果。',
    images: [],
    isPlaceholder: true,
    placeholderLabel: 'MEXC Card 素材 — 待补充'
  },
  {
    title: 'Mascot & Brand IP',
    label: '品牌 IP',
    icon: 'SmilePlus',
    description: '用于编辑角色设计、动作探索、表情/姿态研究及周边应用。',
    images: [],
    isPlaceholder: true,
    placeholderLabel: '品牌 IP 素材 — 待补充'
  },
  {
    title: 'Brand Visual Evolution',
    label: '视觉体系',
    icon: 'Palette',
    description: '用于编辑品牌视觉升级、模板体系与规范化设计；请仅加入已确认可公开的规范与示例。',
    images: [],
    isPlaceholder: true,
    placeholderLabel: '品牌体系素材 — 待补充'
  },
  {
    title: 'Selected Brand Applications',
    label: '精选应用',
    icon: 'PanelsTopLeft',
    description: '用于编辑活动、线下物料、品牌周边等精选内容，并为每项应用补充必要的项目背景。',
    images: [],
    isPlaceholder: true,
    placeholderLabel: '精选应用素材 — 待补充'
  },
  {
    title: 'AI & Design Workflow',
    label: '创意运营',
    icon: 'Workflow',
    description: '用于编辑 AI Skill、设计流程、评审实践和设计规范优化；仅发布获准对外披露的流程。',
    images: [],
    isPlaceholder: true,
    placeholderLabel: 'AI 与设计流程素材 — 待补充'
  }
];
