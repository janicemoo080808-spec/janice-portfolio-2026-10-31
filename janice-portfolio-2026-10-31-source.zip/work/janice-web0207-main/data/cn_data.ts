import { Project, ExperienceItem, BlogPost, EducationItem, CertificateItem, SiteContent, CategoryType } from '../types';
import { AI_CREATIVE_SECTIONS } from './aigcProject';
import { WEB3_PROJECT_SECTIONS } from './web3Project';
import { LUXURY_PROJECT_SECTIONS } from './luxuryProject';
import { AUTOMOTIVE_PROJECT_SECTIONS } from './automotiveProject';
import { ACTIVITY_PROJECT_SECTIONS } from './activityProject';

export const CV_URL = 'https://janice-cv-1395762740.cos.ap-shanghai.myqcloud.com/JaniceMo_BrandCreative_CV_CN%2BEN.pdf';

export const PHILOSOPHY_CN = {
  quote: "Leveraging Aesthetics to Drive Business Growth.",
  description: "没有策略的美学，一文不值。我不制造单纯的视觉糖果，将‘注意力’转化为‘资产价值’的商业系统。在算法制造的噪音中，清晰是唯一的杀手锏。"
};

export const EXPERTISE_CN = [
  { title: "跨域视觉战略", desc: "9年+实战，深耕涵盖Web3 、高奢、 车企及快消等多维赛道。擅长用跨界思维打破行业同质化，捕捉不同商业形态下的核心共性，把复杂的商业模式翻译成**秒懂的视觉语言**. 让品牌在第一眼赢过对手" },
  { title: "全链路品牌操盘", desc: "从**顶层战略推演**到**像素级落地**. 拒绝割裂执行，作为品牌资产的“**增值操盘手**”，确保品牌策略在每一个视觉触点都能精准兑现，实现**商业价值最大化**。" },
  { title: "AIGC 流程重构", desc: "构建**人机协作中枢**，将AI工具整合进企业工作流。从模型训练到内容裂变，将创意生产成本降低 80% 的同时，确保持续的**品牌主权**与叙事一致性。" },
  { title: "敏捷效能领导力", desc: "我不只是管理者，更是技术教练。通过 AI 赋能，能让 5 人的团队发挥出 20 人的战力，拿结果说话。" }
];

const projects_cn: Project[] = [
  {
    id: 'p-aigc',
    title: 'AIGC 战略与全域制作',
    category: 'AI_CREATIVE',
    subCategory: 'STRATEGY',
    description: '构建品牌专属的 AI 生产引擎，实现从创意到产出的指数级效率提升。',
    imageUrl: 'https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/cover/cover7.webp',
    sections: AI_CREATIVE_SECTIONS,
    tags: ['AI Strategy', 'Workflow', 'System Design']
  },
  {
    id: 'p-web3',
    title: 'Web3 金融生态',
    category: 'BRAND_ECOSYSTEM',
    subCategory: 'IDENTITY',
    description: '为 Crydit 构建去中心化金融的信任基石，定义加密世界的奢侈美学。',
    imageUrl: 'https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/cover/cover2.webp',
    sections: WEB3_PROJECT_SECTIONS,
    tags: ['Web3', 'Fintech', 'Identity']
  },
  {
    id: 'p-luxury',
    title: '奢侈品美学与调性',
    category: 'LUXURY_DESIGN',
    subCategory: 'CONTENT_CREATION',
    description: '在 LVMH 体系下的视觉叙事实践，重塑品牌的数字感官体验。',
    imageUrl: 'https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/cover/cover1.webp',
    sections: LUXURY_PROJECT_SECTIONS,
    tags: ['Luxury', 'Aesthetics', 'LVMH']
  },
  {
    id: 'p-auto',
    title: '智能出行',
    category: 'AUTOMOTIVE_DESIGN',
    subCategory: 'SYSTEMS',
    description: '工业美学与数字体验的跨界融合，定义未来出行的灵感边界。',
    imageUrl: 'https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/cover/cover3.webp',
    sections: AUTOMOTIVE_PROJECT_SECTIONS,
    tags: ['Automotive', 'Smart Mobility', 'UI/UX']
  },
  {
    id: 'p-activity',
    title: '品牌活动与空间',
    category: 'ACTIVITY_VISUALS',
    subCategory: 'CAMPAIGN',
    description: '从 Token 2049 到全球公益行，用空间叙事定义品牌主权。',
    imageUrl: 'https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/campaign/token2049-01.webp',
    sections: ACTIVITY_PROJECT_SECTIONS,
    tags: ['Space', 'Global', 'Campaign']
  }
];

export const CONTENT_CN: SiteContent = {
  nav: {
    portfolios: "精选案例",
    career: "个人履历",
    credentials: "专业资质",
    awards: "国际荣誉",
    blog: "行业洞察",
    connect: "联系我",
    downloadCv: "下载简历"
  },
  hero: {
    title: "JANICE MO",
    subtitle: "品牌创意总监 / AIGC 流程架构师",
    description: "一个以 AI 为准星，精准重构全球品牌美学资产与叙事逻辑的狙击手",
    cta: "浏览作品",
    available: "OPEN FOR COLLABORATION"
  },
  resume: {
    aboutTitle: "战略美学架构师",
    aboutText: "拥有 9 年以上跨域视觉战略经验，深耕 Web3、高奢及智能出行领域。擅长将复杂的商业逻辑转化为秒懂的视觉语言。",
    stats: { exp: "9年+", projects: "50+", awards: "15+" },
    skillsTitle: "核心专业力",
    experienceTitle: "个人履历",
    eduTitle: "教育背景",
    certTitle: "专业资质",
    labels: {
      journey: "个人履历",
      impact: "商业影响",
      viewMore: "更多",
      reportTo: "汇报对象",
      scope: "职责范畴",
      performance: "核心战果",
      collapse: "收起"
    }
  },
  portfolio: {
    title: "精选案例",
    subtitle: "SELECTED WORKS",
    filters: {
      all: "全部",
      activity: "品牌活动",
      brand_ecosystem: "Web3 生态",
      luxury: "奢侈品美学",
      automotive: "智能出行",
      fnb: "快消商业",
      ai_drama: "AI 创意"
    }
  },
  blog: {
    title: "行业洞察",
    subtitle: "INSIGHTS",
    readMore: "阅读全文"
  },
  footer: {
    rights: "© 2026 JANICE MO."
  },
  experience: [
    {
      id: 'exp-crydit-cn',
      role: '品牌总监 & 设计总监',
      company: '上海天卓悦科技有限公司 (Crydit)',
      period: '2023.12 – 2026.01',
      reportingTo: 'CEO',
      companyIntro: 'Crydit 是一家区块链资产支付平台，为加密用户提供创新交易解决方案。',
      responsibilities: ['作为初创核心成员，从 0 到 1 搭建品牌体系。 在资源匮乏的早期，我既是总监也是执行者。对内建立设计团队 and 工作流，对外搞定 Token 2049 这种顶级展会。我确保每一分预算都花在刀刃上，迅速建立起具备国际一线水准的品牌信任背书。'],
      achievements: [
        '战略全案与 0-1 构建 : 独立撰写全案品牌营销策略，制定“加密奢侈品”差异化定位与全球叙事逻辑。在团队组建初期，独立完成用户调研、VIS系统、UI交互原型及代码规范编写，确保策略无损落地。',
        '团队管理与效能: 从 0 到 1 招募并组建高敏捷设计团队，建立人才培养与绩效考核体系。管理创新： 引入 AIGC 工作流与 LoRA 模型库，制定标准化协作 S.O.P.，通过技术手段将团队项目交付周期缩短 15%，实现降本增效。',
        '跨部门与资源统筹 : 跨职能协同： 深度协同产品、市场、销售三大中心，拉通从“产品功能”到“市场叙事”的价值链，确保品牌发声的一致性。全球供应链管控： 建立并管理跨国供应商库（搭建、印刷、周边生产），亲自把控高定周边的工艺品控与成本谈判，确保实物产出的高奢标准。',
        '核心战役与增长 : Token 2049 全球阵地操盘： 统筹内外部 10+ 合作伙伴，克服跨国物流与施工难题，48 小时极速落地高规格展位。触达 50,000+行业精英，BD 线索转化率提升 35%。社媒增长： 搭建 Twitter 国际化内容矩阵，通过话题策划与社区互动建立话语主权，助力品牌知名度 6 个月内提升 80%。荣誉收割： 带领团队斩获伦敦设计奖金奖、MUSE 金奖等多项国际大奖。'
      ]
    },
    {
      id: 'exp-zotye-cn',
      role: '资深视觉经理',
      company: '上海君趣汽车 (众泰汽车)',
      period: '2022.5 – 2023.6',
      reportingTo: '品牌部总监',
      companyIntro: '是众泰汽车 (股票代码: 000980) 重整后的核心运营主体，专注于新能源赛道的全球化布局，致力于构建以“生活科技”为核心的智能出行生态。',
      responsibilities: ['在新能源汽车红海中，作为视觉枢纽连接“工程技术”与“用户体验”。负责定义品牌视觉语言，并作为核心接口人管理跨部门需求与庞大的外部供应商体系。'],
      achievements: [
        '全案管控与标准: 独立创建并实施品牌 VIS 规范。建立严格的输出审核机制，确保品牌资产在数字化交互与物理终端的像素级一致性。',
        '跨界协同与外联: 研发协同： 深入车间一线，与工程部门紧密配合，主导新款车型的 CMF (色彩/材料/工艺) 设计。亲自筛选测试 50+ 种皮料，解决设计落地的工艺难题。供应商管理： 统筹管理广告公司、展会搭建商及物料制作商，通过精细化沟通与谈判，确保所有外部产出符合车企的严苛标准，有效控制预算。',
        '核心业绩: 将抽象的“生活科技”理念转化为具体的触感体验与生活方式叙事，确保新车型在视觉与体验上的差异化竞争优势。'
      ]
    },
    {
      id: 'exp-guijiu-cn',
      role: '资深品牌经理 & 总裁执行助理',
      company: '中国贵酒集团(股票代码: 600696)',
      period: '2021.11 – 2022.4',
      reportingTo: 'CMO营销总裁',
      companyIntro: '融合经典与创新的 A 股上市综合性酒业集团，以“国际化标准”重新定义中国高端白酒。',
      responsibilities: ['协助 CMO 及总裁统筹上市集团的品牌管理体系。核心能力在于多线程项目管理与高层级资源整合，通过极速组织部署实现战略目标。'],
      achievements: [
        '统筹管理与组织: 负责集团重点项目的全周期统筹，包括团队极速组建、进度追踪及跨子公司人员调配。极速体系搭建： 仅用 2 个月 时间完成花王集团体系设计搭建及执行，保障品牌上市发布会的高规格完美交付。',
        '公共关系与背书: 作为品牌部核心代表，整合集团各职能部门资源，对接国家级媒体平台。操盘 CCTV-1《大国品牌》： 主导独家冠名项目，协调制作方与企业方需求，最终荣获广告节“年度内容营销案例”双料大奖。',
        '创新业绩: 策划“千城万企”项目，获评“十大高品质消费创新案例”，成功拓展高端市场版图。'
      ]
    },
    {
      id: 'exp-chunmai-cn',
      role: '视觉设计经理',
      company: '上海淳麦品牌管理有限公司',
      period: '2018.7 – 2021.10',
      reportingTo: '执行董事',
      companyIntro: '法国百年面粉品牌 Les Moulines d\'Antoine 在中国大陆的独家品牌授权运营商，专注于将顶级法式烘焙供应链进行本土化品牌重塑与商业落地。',
      responsibilities: ['负责法国品牌中国区的整体视觉战略。核心价值在于“用设计驱动销售”以及“从 0 培养团队”的管理能力。'],
      achievements: [
        '团队建设: 组建并领导设计团队，负责团队的绩效管理（KPI）与专业技能辅导，带领团队完成从 VI、包装到空间设计的全案输出。',
        '商业转化与落地 : 爆款驱动： 带领团队设计 20+ 款新品包装，基于电商数据优化视觉，推动核心单品销量同比增长 10 倍。空间落地管理： 负责线下网红店的软装设计与施工落地，现场把控工程细节与陈列效果，打造区域热门打卡地标。',
        '品牌重塑: 独立完成 品牌 VIS 2.0 版本升级，建立标准化的视觉系统并沿用至今。'
      ]
    },
    {
      id: 'exp-jd-cn',
      role: '视觉设计师 (实习)',
      company: '北京京东世纪贸易有限公司 (JD.com)',
      period: '2017.02 – 2018.07',
      companyIntro: '中国顶级互联网电商巨头。',
      responsibilities: ['在中国顶级互联网电商巨头的实战历练。作为职业生涯的起点，在高流量、高并发的正向电商大促环境下，建立了**“数据驱动设计”与“用户转化逻辑”**的底层认知。'],
      achievements: [
        'S 级大促实战: 深度参与京东（618、双 11）等 S 级大型营销战役的页面设计。在高压快节奏下，完成从主会场到分会场的视觉延展，确保品牌调性在海量物料中的统一性。',
        '电商视觉转化: 针对不同节日节点与重点项目，设计具有强促销感与差异化风格的活动页面。',
        '成长价值: 早期掌握学习了“视觉服务于 GMV”的商业逻辑，为日后在淳麦实现 10 倍销量增长打下了坚实的电商基因基础。'
      ]
    }
  ],
  education: [
    {
      school: "哈尔滨理工大学",
      period: "2014 – 2018",
      degrees: ["视觉传达设计 【第一学位】", "人力资源管理 【第二学位】"]
    }
  ],
  certificates: [
    { year: "2023", name: "LVMH 奢侈品品牌管理证书", focus: "奢侈品品牌战略与运营管理" },
    { year: "2025", name: "Google 数据分析专业证书", focus: "SQL, Tableau, R & 数据驱动决策" },
    { year: "2025", name: "Google 数字营销与电子商务专业证书", focus: "SEO, SEM & 用户旅程优化" },
    { year: "2025", name: "Google UX 设计专业证书", focus: "UX 研究、原型设计与 Figma 高级应用" }
  ],
  skills: [],
  projects: projects_cn,
  blogPosts: [
    {
      id: 'blog-scarcity',
      title: '丰饶的悖论：在 AI 浪潮中重构“奢侈品稀缺性”',
      author: 'Janice Mo | Brand & Design Director',
      date: '2025.04',
      readTime: '7 分钟',
      summary: '随着 AI 能够源源不断地生成极致精美的视觉，品牌必须建立“私有化模型”。未来的奢侈品不再源于手工的缓慢，而源于由算法与直觉共同构筑的“定制孤独”与不可复制的品牌主权。',
      content: '',
      imageUrl: 'https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/cover/cover5.1.webp',
      sections: [
        {
          subtitle: '审美平权后的“资产贬值”',
          text: '我们要承认一个残酷的事实：“高级感”已经不再稀缺。\n在过去，一张拥有完美光影、顶级模特质感的广告片，需要一支 50 人的团队、几十万美金的预算和数月的筹备。这是奢侈品的护城河。\n但今天，利用 LoRA 模型配合 Midjourney v7，一个懂行的大学生可以在一小时内生成 100 张同等质量的“大片”。\n\n犀利洞察：\n如果奢侈品仅仅停留在“视觉美学”的竞争，那么它们已经输了。\n在 AI 时代，拼“好看”是低维竞争，拼“排他性的叙事”才是高维生存。',
          isGrid: true,
          images: [
            'https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/blog/aigc-luxury-aesthetic-depreciation-02.webp',
            'https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/video/insights/aigc-luxury-aesthetic-depreciation-04.MP4'
          ]
        },
        {
          subtitle: '从“手工崇拜”到“智力溢价”',
          text: '很多人恐惧 AI 会毁掉奢侈品的“工匠精神”。这种担忧是肤浅的。\n奢侈品的本质不是“手做（Handmade）”，而是“人性的极致投射”。\nAI 不应被视为“廉价的替代劳动力”，而应被视为“极速的灵感显影液”。\n作为品牌操盘手，我主张建立“私有化模型（Proprietary Models）”。我们不应该使用通用的 AI 模型，而应该将品牌百年的历史图谱、设计手稿、特定的色彩配比“喂”给 AI。\n这样生成的，不是随机的图片，而是品牌 DNA 的数字化繁延。\n\n犀利洞察：\n未来的稀缺，不再是“我花了一千小时缝制”，\n而是“我用独有的品牌数据模型，为你计算出了世上唯一的那个解”。\n这是从“劳动力溢价”向“智力 / 数据溢价”的转移。',
          image: 'https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/blog/aigc-luxury-intellectual-premium-01.webp'
        },
        {
          subtitle: 'AI 的终极战场：超个性化的“叙事主权”',
          text: '奢侈品的最高境界是“懂你”。\n在 Web3 和元宇宙的语境下，AI 带来的最大机会是 “1-on-1 的叙事服务”。\n试想，当你购买一瓶香水时，AI 不仅仅是为你生成一个包装，而是根据你的数字足迹、你的审美偏好，实时生成一部“只为你一个人播放的”30 秒品牌微电影。\n这部电影里有你的影子，有品牌的故事，且阅后焚，不可复制。\n这就是我所说的“定制孤独”。在算法的海洋里，品牌为你圈出了一块只属于你的精神领地。这才是 AI 时代真正的“信任溢价”。',
        }
      ]
    },
    {
      id: 'blog-architect',
      title: '职能重塑：从创意总监到创意架构师',
      author: 'Janice Mo | AIGC Workflow Architect',
      date: '2025.11',
      readTime: '7 分钟',
      summary: '在 AIGC 重构生产力的今天，企业的痛点不再是创意匮乏，而是失控。传统的创意总监正在向“创意架构师”转型：不再只是像素的监督者，而是企业审美算法与人机协作系统的构建者。',
      content: '',
      imageUrl: 'https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/cover/cover6.webp',
      sections: [
        {
          subtitle: '为什么传统的 CD 正在变得“过时”？',
          text: '在过去的 4A 体系或大厂设计中心里，一个 CD 的价值由三部分组成：\n1. 审美霸权： 只有我说的才算对。\n2. 资源垄断： 我手里有最好的插画师、摄影师和修图团队。\n3. 时间壁垒： 只有我知道如何用 3 周磨出一张 KV。\n但 AI 瞬间击碎了这三堵墙。 审美变得多元且廉价，资源变成了算力，时间被压缩成秒。如果一个总监今天还在强调“我能把图修得多细”，那他实际上是在用公司的钱在做 AI 一秒钟能做的事。',
          image: 'https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/blog/aigc-creative-architecture-insight-01.webp'
        },
        {
          subtitle: '三大核心职能重构',
          text: 'A. 从“带团队”到“设计人机工作流”\nB. 从“品控”到“模型训练”\nC. 从“创意发散”到“精准狙击”',
          image: 'https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/blog/aigc-creative-architect-core-functions-01.webp'
        }
      ]
    }
  ],
  aiContext: "Janice Mo 是 MEXC Exchange 的品牌设计 Lead，专注于品牌视觉体系、全渠道品牌应用与 AI 辅助设计工作流。",
  awards: [
    { name: "New York Product Design Awards — Silver Winner", desc: "纽约产品设计奖 · 银奖", level: "SILVER" },
    { name: "London Design Awards — Gold Winner", desc: "伦敦设计奖 · 金奖", level: "GOLD" },
    { name: "French Design Awards — Gold Winner", desc: "法国设计奖 · 金奖", level: "GOLD" },
    { name: "MUSE Design Awards (USA) — Gold Winner", desc: "美国 MUSE 设计奖 · 金奖", level: "GOLD" },
    { name: "European Design Awards — Gold Winner", desc: "欧洲设计奖 · 金奖", level: "GOLD" }
  ],
  common: {
    selectedWorks: "精选案例",
    intelligence: "行业洞察",
    getInTouch: "联系我",
    phoneWechat: "电话 / 微信",
    emailAddr: "电子邮件",
    // Fix: Added missing phoneValue and emailValue properties
    phoneValue: "18621568644",
    emailValue: "maoyujun08@163.com",
    awardsSubtitle: "国际荣誉",
    awardsDesc: "在 LVMH 生态与 Web3 领域的多项设计大奖，是对商业成熟度与落地标准的全球化公认。"
  }
};
