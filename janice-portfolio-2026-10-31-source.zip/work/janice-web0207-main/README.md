<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://github.com/user-attachments/assets/0aa67016-6eaf-458a-adb2-6e31a0763ed6" />
</div>

# Janice Mo portfolio

This contains everything you need to run your app locally.

This is the working copy restored from `janice-web0207-main(1).zip`. It preserves the original portfolio structure and adds an editable MEXC case inside Web3 Ecosystem.

## Run Locally

**Prerequisites:**  Node.js


1. Install dependencies:
   `npm install`
2. Run the app:
   `npm run dev`

## MEXC content

- English case copy and placeholders: `data/mexcProject_en.ts`
- Chinese case copy and placeholders: `data/mexcProject.ts`
- Web3 case order and entry: `data/en/index.ts` and `data/cn/index.ts`
- Career entries: `data/experience_en.ts` and `data/cn/index.ts`

Every MEXC media slot is deliberately marked as pending. Replace a section's `images` array only with approved, publishable material. The original Crydit sections remain below MEXC and are unchanged apart from their `02 / Crydit` label.
