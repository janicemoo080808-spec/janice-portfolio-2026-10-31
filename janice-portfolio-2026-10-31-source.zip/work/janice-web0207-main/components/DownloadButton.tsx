import React from 'react';
import { motion } from 'framer-motion';
import { Download } from 'lucide-react';

interface DownloadButtonProps {
  href: string;
  label: string;
}

const DownloadButton: React.FC<DownloadButtonProps> = ({ href, label }) => {
  const maskStyle: React.CSSProperties = {
    padding: '1px',
    WebkitMaskImage: 'linear-gradient(#fff 0 0), linear-gradient(#fff 0 0)',
    WebkitMaskClip: 'content-box, border-box',
    WebkitMaskComposite: 'xor',
    maskImage: 'linear-gradient(#fff 0 0), linear-gradient(#fff 0 0)',
    maskClip: 'content-box, border-box',
    maskComposite: 'exclude',
  };

  return (
    <motion.a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      download
      className="relative group block rounded-full bg-[#000000] overflow-visible"
      whileHover={{ scale: 1.02 }}
      transition={{ duration: 0.3 }}
    >
      {/* Fixed border track */}
      <div className="absolute inset-0 rounded-full border border-white/10 pointer-events-none" />

      {/* The Beam (Middle layer) */}
      <div 
        className="absolute inset-0 rounded-full pointer-events-none"
        style={maskStyle}
      >
        <motion.div
          className="absolute left-1/2 top-1/2 w-[300%] aspect-square"
          style={{ 
            x: '-50%', 
            y: '-50%', 
            background: 'conic-gradient(from 0deg, transparent 0%, transparent 83%, white 100%)' 
          }}
          animate={{ rotate: 360 }}
          transition={{ duration: 4, ease: "linear", repeat: Infinity }}
        />
      </div>

      {/* Glow/Halo (Top layer) */}
      <div className="absolute inset-0 pointer-events-none blur-[10px]">
        <div 
          className="absolute inset-0 rounded-full"
          style={maskStyle}
        >
          <motion.div
            className="absolute left-1/2 top-1/2 w-[300%] aspect-square"
            style={{ 
              x: '-50%', 
              y: '-50%', 
              background: 'conic-gradient(from 0deg, transparent 0%, transparent 83%, white 100%)' 
            }}
            animate={{ rotate: 360 }}
            transition={{ duration: 4, ease: "linear", repeat: Infinity }}
          />
        </div>
      </div>

      {/* Content */}
      <div className="relative z-20 px-6 py-3 flex items-center justify-center gap-2">
        <Download className="w-3.5 h-3.5 text-white" />
        <span className="text-[10px] font-black uppercase tracking-widest text-white">
          {label}
        </span>
      </div>
    </motion.a>
  );
};

export default DownloadButton;
