
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Award, Check } from 'lucide-react';
import { EducationItem, CertificateItem } from '../types';

interface EndorsementArchiveProps {
  education: EducationItem[];
  certificates: CertificateItem[];
  titleEdu: string;
  titleCert: string;
  language: string;
}

const EndorsementArchive: React.FC<EndorsementArchiveProps> = ({ education, certificates, titleEdu, titleCert, language }) => {
  const [hoveredCert, setHoveredCert] = useState<number | null>(null);

  return (
    <div className="relative w-full bg-black py-16 md:py-20">
      {/* 1. Optical Entry: Progressive Blur Layer */}
      <div 
        className="absolute top-0 left-0 right-0 h-40 backdrop-blur-[40px] z-10 pointer-events-none" 
        style={{ 
          maskImage: 'linear-gradient(to bottom, black 0%, transparent 100%)',
          WebkitMaskImage: 'linear-gradient(to bottom, black 0%, transparent 100%)'
        }} 
      />

      <div className="max-w-[1440px] mx-auto px-4 md:px-12 relative z-20">
        
        {/* Main Section Header */}
        <div className="mb-16 md:mb-24">
          <h2 className="text-4xl md:text-[4vw] font-sans font-bold tracking-tighter text-white opacity-100 leading-tight">
            {language === 'EN' ? 'Endorsements & Education' : titleCert}
          </h2>
        </div>

        {/* --- SECTION: EDUCATION --- */}
        <div className="mb-16 md:mb-24">
          <div className="flex items-center gap-6 mb-8 border-b border-white/10 pb-4">
            <span className={`text-[12px] uppercase ${language === 'EN' ? 'font-bold tracking-[0.2em]' : 'font-bold tracking-[0.2em]'} text-zinc-500`}>{titleEdu}</span>
          </div>

          <div className="space-y-0">
            {education.map((edu, idx) => (
              <div key={idx} className="py-8 border-b border-white/5 flex flex-col md:flex-row md:items-start justify-between gap-4 group">
                {/* School & Period */}
                <div className="flex-1">
                   <div className="flex items-baseline justify-between md:justify-start md:gap-6">
                      <h3 className="text-xl font-medium text-white group-hover:text-primary transition-colors">{edu.school}</h3>
                      <span className="text-sm text-zinc-500 font-mono">{edu.period}</span>
                   </div>
                   {/* Degrees */}
                   <div className="mt-3 space-y-2">
                      {edu.degrees.map((degree, dIdx) => (
                         <div key={dIdx} className="flex items-center gap-2">
                            <div className="w-1 h-1 rounded-full bg-zinc-700" />
                            <p className="text-zinc-400 text-sm leading-relaxed">{degree}</p>
                         </div>
                      ))}
                   </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* --- SECTION: CERTIFICATIONS --- */}
        <div id="credentials" className="pt-10">
          <div className="flex items-center gap-6 mb-8 border-b border-white/10 pb-4">
            <span className={`text-[12px] uppercase ${language === 'EN' ? 'font-bold tracking-[0.2em]' : 'font-bold tracking-[0.2em]'} text-zinc-500`}>Certifications</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-20 gap-y-4">
            {certificates.map((cert, cIdx) => (
              <motion.div
                key={cIdx}
                onMouseEnter={() => setHoveredCert(cIdx)}
                onMouseLeave={() => setHoveredCert(null)}
                className={`relative p-6 transition-all duration-500 cursor-default group
                  ${hoveredCert === cIdx ? 'bg-white/[0.03] backdrop-blur-md rounded-2xl' : ''}
                  ${hoveredCert !== null && hoveredCert !== cIdx ? 'opacity-30' : 'opacity-100'}
                `}
              >
                <div className="flex flex-col gap-2">
                   <div className="flex items-start justify-between gap-4">
                      <h4 className="text-lg font-medium text-zinc-200 group-hover:text-primary transition-colors leading-relaxed">
                        {cert.name}
                        <Check className="inline-block ml-2 w-4 h-4 text-[#86570B] drop-shadow-sm" />
                      </h4>
                      <span className="text-sm text-zinc-500 font-mono whitespace-nowrap pt-1">{cert.year}</span>
                   </div>
                   {cert.focus && (
                      <p className="text-sm text-zinc-600 leading-relaxed max-w-[90%]">
                        {cert.focus}
                      </p>
                   )}
                </div>
              </motion.div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
};

export default EndorsementArchive;
