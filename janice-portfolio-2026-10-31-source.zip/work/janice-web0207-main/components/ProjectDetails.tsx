
import React, { useRef } from 'react';
import { motion as m, useScroll, useTransform } from 'framer-motion';
import { X, ChevronLeft } from 'lucide-react';
import { Project } from '../types';
import AIGCLayout from './AIGCLayout';
import Web3Layout from './Web3Layout';
import LuxuryLayout from './LuxuryLayout';
import AutomotiveLayout from './AutomotiveLayout';
import ActivityLayout from './ActivityLayout';

// Cast motion to any to bypass environment-specific type definition issues
const motion = m as any;

const GenericProjectLayout: React.FC<{ project: Project; onClose: () => void }> = ({ project, onClose }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ container: containerRef });
  const navBgOpacity = useTransform(scrollYProgress, [0, 0.05], [0, 0.98]);

  return (
    <motion.div 
      initial={{ opacity: 0 }} 
      animate={{ opacity: 1 }} 
      exit={{ opacity: 0 }} 
      className="fixed inset-0 z-[1200] bg-black overflow-hidden"
    >
      {/* Integrated Header for Fallback */}
      <motion.nav 
        style={{ 
          backgroundColor: `rgba(10, 10, 10, ${navBgOpacity.get()})`,
          backdropFilter: 'blur(50px)'
        }}
        className="fixed top-0 left-0 right-0 z-[1500] h-16 md:h-20 border-b border-white/5 flex items-center px-6 md:px-12 transition-all duration-700"
      >
        <button 
          onClick={onClose} 
          className="flex items-center gap-3 px-4 py-2 md:px-6 md:py-2 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 text-white font-black uppercase text-[10px] md:text-[11px] tracking-[0.2em] transition-all group"
        >
          <ChevronLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
          <span className="hidden lg:block">BACK</span>
        </button>
      </motion.nav>

      <div 
        ref={containerRef}
        className="w-full h-full overflow-y-auto no-scrollbar scroll-smooth"
      >
        <div className="w-full max-w-[1440px] mx-auto px-6 md:px-12 py-32">
          <h1 className="text-5xl md:text-[8vw] font-display font-bold mb-12 uppercase tracking-tighter leading-[0.9]">{project.title}</h1>
          <p className="text-xl md:text-3xl text-zinc-400 font-light max-w-[80%] leading-relaxed mb-32">{project.description}</p>
          <div className="space-y-48">
            {project.sections.map((section, idx) => (
              <div key={idx} className="space-y-16">
                <div className="flex items-center gap-10">
                  <div className="h-[2px] w-16 bg-primary" />
                  <h2 className="text-2xl md:text-5xl font-display font-bold uppercase tracking-tight">{section.title}</h2>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                  {section.images?.map((img, i) => <img key={i} src={img} className="rounded-3xl w-full h-auto border border-white/5 shadow-4xl hover:border-primary/20 transition-all duration-700" alt="" />)}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </motion.div>
  );
};

const ProjectDetails: React.FC<{ project: Project; onClose: () => void }> = ({ project, onClose }) => {
  // Category-based routing to isolated components
  switch (project.category) {
    case 'AI_CREATIVE':
      return <AIGCLayout project={project} onClose={onClose} />;
    case 'BRAND_ECOSYSTEM':
      return <Web3Layout project={project} onClose={onClose} />;
    case 'LUXURY_DESIGN':
      return <LuxuryLayout project={project} onClose={onClose} />;
    case 'AUTOMOTIVE_DESIGN':
      return <AutomotiveLayout project={project} onClose={onClose} />;
    case 'ACTIVITY_VISUALS':
      return <ActivityLayout project={project} onClose={onClose} />;
    default:
      return <GenericProjectLayout project={project} onClose={onClose} />;
  }
};

export default ProjectDetails;
