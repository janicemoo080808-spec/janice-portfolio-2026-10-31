
import React, { useState, useEffect, useRef } from 'react';
import { motion as m, AnimatePresence, LayoutGroup } from 'framer-motion';
import { Sparkles, TrendingUp, Target, ArrowUpRight, UserCircle, ChevronDown, ChevronUp, Minus } from 'lucide-react';
import { DESIGN_PHILOSOPHY_CN, DESIGN_PHILOSOPHY_EN } from '../constants';
import TextType from './TextType';

// Cast motion to any to bypass environment-specific type definition issues
const motion = m as any;

// 仅保留数据类关键词高亮
const KEYWORDS = [
  '10 倍', '10倍', '35%', '80%', '15%', '2 个月', '2个月', '50,000+', 
  '000980', '600696', '1.2M+', '9年+', '9+ years', '5 人的团队', '20 人的战力', 'ROI', 'GMV'
];

const highlightKeywords = (text: string) => {
  if (!text) return text;
  // 匹配数字、百分比、倍数等数据的正则
  const dataRegex = /(\d+(?:\.\d+)?%|\d+\s*倍|\d+,\d+\+|\d+\.\d+M\+|\d+年\+|\d+\+ years|\d+\s*人)/g;
  
  const parts = text.split(dataRegex);
  return parts.map((part, i) => {
    const isData = dataRegex.test(part) || KEYWORDS.some(k => k.toLowerCase() === part.toLowerCase());
    return isData ? (
      <span key={i} className="text-white font-black drop-shadow-[0_0_12px_rgba(197,160,89,0.35)] transition-all">{part}</span>
    ) : part;
  });
};

const renderRichText = (text: string) => {
  if (!text) return text;
  // 移除所有 ** 标记，交由 highlightKeywords 处理数据加粗
  const cleanText = text.replace(/\*\*/g, '');
  return highlightKeywords(cleanText);
};

const ExperienceItem: React.FC<{ 
  item: any; 
  index: number; 
  activeId: string | null; 
  toggleActive: (id: string) => void;
  labels: any;
  language: string;
}> = ({ item, index, activeId, toggleActive, labels, language }) => {
  const isActive = activeId === item.id;
  const itemRef = useRef<HTMLDivElement>(null);
  const hasClicked = useRef(false);

  useEffect(() => {
    if (isActive && itemRef.current && hasClicked.current) {
      const timer = setTimeout(() => {
        const navHeight = 100;
        const rect = itemRef.current?.getBoundingClientRect();
        if (rect) {
          const targetPosition = rect.top + window.pageYOffset - navHeight;
          window.scrollTo({ top: targetPosition, behavior: 'smooth' });
        }
        hasClicked.current = false;
      }, 350); 
      return () => clearTimeout(timer);
    }
  }, [isActive]);

  const previewMetrics = item.achievements?.[0]?.split(/[:：]\s*/)?.[1]?.substring(0, 40) || item.achievements?.[0]?.substring(0, 40) || "";

  return (
    <motion.div 
      ref={itemRef}
      layout
      initial={{ opacity: 0, y: 60 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-10%" }}
      transition={{ 
        layout: { type: "spring", stiffness: 300, damping: 35 },
        opacity: { duration: 1.2, ease: [0.16, 1, 0.3, 1] }
      }}
      className="relative w-full border-b border-white/5 group"
    >
      <div 
        onClick={() => {
          hasClicked.current = true;
          toggleActive(item.id);
        }}
        className="py-10 md:py-16 px-4 md:px-8 cursor-pointer transition-colors duration-500 hover:bg-white/[0.01]"
      >
        <div className="absolute left-0 top-[3.5rem] md:top-[4.5rem] flex flex-col items-center z-10">
          <motion.div 
            animate={{ 
              scale: isActive ? 1.6 : 1,
              backgroundColor: isActive ? '#86570B' : 'rgb(39, 39, 42)',
              boxShadow: isActive ? '0 0 25px rgba(134, 87, 11, 0.6)' : 'none'
            }}
            className="w-2 h-2 md:w-2.5 md:h-2.5 rounded-full border border-white/10"
          />
        </div>

        <div className="flex flex-col xl:flex-row xl:items-start gap-6 md:gap-16 pl-6 md:pl-12">
          <div className="xl:w-1/4">
            <motion.div layout="position" className="flex flex-col gap-3">
              <div className="flex flex-col gap-1.5">
                <span className={`text-[11px] md:text-[14px] font-mono uppercase tracking-[0.3em] transition-colors duration-500 ${isActive ? 'text-primary' : 'text-zinc-500'} ${language === 'EN' ? 'font-bold' : 'font-black'}`}>
                  {item.period}
                </span>
                <span className={`text-[13px] md:text-[15px] font-bold text-zinc-300 leading-tight ${language === 'EN' ? 'tracking-tight' : ''}`}>{item.company}</span>
              </div>
              
              {!isActive && previewMetrics && (
                <div className={`flex items-center gap-2 text-[10px] md:text-[12px] text-primary/70 mt-2 uppercase ${language === 'EN' ? 'font-bold tracking-[0.2em]' : 'font-black tracking-widest'}`}>
                  <div className="w-1 h-1 rounded-full bg-primary" />
                  {previewMetrics}...
                </div>
              )}

              <AnimatePresence>
                {isActive && (
                  <motion.div 
                    initial={{ opacity: 0, x: -5 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -5 }}
                    className="flex flex-col gap-3"
                  >
                    {item.reportingTo && (
                      <div className={`flex items-center gap-2 text-[10px] md:text-[12px] text-zinc-400 bg-white/5 w-fit px-2.5 py-1 rounded uppercase ${language === 'EN' ? 'font-bold tracking-[0.3em]' : 'font-black tracking-widest'}`}>
                        <UserCircle className="w-3.5 h-3.5 text-primary/60" />
                        {labels.reportTo}: {item.reportingTo}
                      </div>
                    )}
                    <p className="text-[12px] md:text-[13px] text-zinc-500 font-normal leading-relaxed">
                      {item.companyIntro}
                    </p>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          </div>

          <div className="xl:w-3/4">
            <motion.div layout="position" className="flex flex-col gap-4">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <h3 className={`text-lg md:text-3xl xl:text-4xl font-sans font-bold tracking-tighter uppercase transition-all duration-700 ${language === 'EN' ? 'leading-[1.1]' : 'leading-[1.15]'} ${isActive ? 'text-white translate-x-1' : 'text-zinc-500 group-hover:text-zinc-300 group-hover:translate-x-2 transition-transform duration-500'}`}>
                  {item.role}
                </h3>
                
                <div className="flex items-center justify-between md:justify-end gap-6 border-t md:border-t-0 border-white/5 pt-3 md:pt-0">
                  <span className={`text-[9px] md:text-[12px] transition-opacity duration-500 uppercase whitespace-nowrap ${isActive ? 'opacity-0' : 'opacity-40'} ${language === 'EN' ? 'font-bold tracking-[0.4em]' : 'font-black tracking-[0.2em]'}`}>
                    {isActive ? '' : labels.viewMore}
                  </span>
                  {isActive ? (
                    <ChevronUp className="w-5 h-5 md:w-8 md:h-8 text-primary" />
                  ) : (
                    <ChevronDown className="w-5 h-5 md:w-8 md:h-8 text-zinc-800 group-hover:text-zinc-600 transition-colors" />
                  )}
                </div>
              </div>
            </motion.div>

            <AnimatePresence>
              {isActive && (
                <motion.div
                  initial={{ opacity: 0, height: 0, filter: 'blur(8px)' }}
                  animate={{ opacity: 1, height: 'auto', filter: 'blur(0px)' }}
                  exit={{ opacity: 0, height: 0, filter: 'blur(8px)' }}
                  transition={{ 
                    height: { type: "spring", stiffness: 300, damping: 35 },
                    opacity: { duration: 0.4 }
                  }}
                  className="overflow-hidden"
                >
                  <div className="flex flex-col gap-8 md:gap-12 pt-8 md:pt-12 mt-8 md:mt-12 border-t border-white/5">
                    <div className="space-y-4">
                      <div className="flex items-center gap-4">
                        <Target className="w-3.5 h-3.5 md:w-5 md:h-5 text-primary/40" />
                        <span className={`text-[9px] md:text-[12px] text-zinc-500 uppercase ${language === 'EN' ? 'font-bold tracking-[0.5em]' : 'font-black tracking-[0.4em]'}`}>{labels.scope}</span>
                      </div>
                      <div className="space-y-4">
                        {item.responsibilities?.map((res: string, i: number) => (
                          <p key={i} className={`text-[13px] md:text-base lg:text-lg text-zinc-300 font-normal leading-relaxed`}>
                            {renderRichText(res)}
                          </p>
                        ))}
                      </div>
                    </div>

                    <div className="space-y-8">
                      <div className="flex items-center gap-4">
                        <TrendingUp className="w-3.5 h-3.5 md:w-5 md:h-5 text-primary/40" />
                        <span className={`text-[9px] md:text-[12px] text-zinc-500 uppercase ${language === 'EN' ? 'font-bold tracking-[0.5em]' : 'font-black tracking-[0.4em]'}`}>{labels.performance}</span>
                      </div>
                      <div className="grid grid-cols-1 gap-6 md:gap-8">
                        {item.achievements?.map((ach: string, i: number) => {
                          const separatorMatch = ach.match(/[:：]\s*/);
                          let title = "";
                          let desc = ach;

                          if (separatorMatch) {
                            const sepIndex = ach.indexOf(separatorMatch[0]);
                            title = ach.substring(0, sepIndex).trim();
                            desc = ach.substring(sepIndex + separatorMatch[0].length).trim();
                            if (title && desc.toLowerCase().startsWith(title.toLowerCase())) {
                               desc = desc.substring(title.length).replace(/^[:：\s,，]+/, '').trim();
                            }
                          }

                          if (!desc || desc === title) {
                            desc = title || ach;
                            title = "";
                          }

                          return (
                            <div key={i} className="group/item pb-6 border-b border-white/[0.03] last:border-0">
                              {title && (
                                <h4 className={`text-sm md:text-base lg:text-lg font-bold text-zinc-200 mb-2 md:mb-3 group-hover/item:text-primary transition-colors tracking-tight ${language === 'EN' ? 'leading-snug' : ''}`}>
                                  {title}
                                </h4>
                              )}
                              <p className="text-[12px] md:sm lg:text-base text-zinc-400 font-normal leading-loose">
                                {renderRichText(desc)}
                              </p>
                            </div>
                          );
                        })}
                      </div>
                    </div>

                    <motion.button
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={(e: React.MouseEvent) => {
                        e.stopPropagation();
                        toggleActive(item.id);
                      }}
                      className={`mt-6 md:mt-8 self-end flex items-center gap-3 px-6 md:px-8 py-2.5 md:py-3 rounded-full bg-white/5 border border-white/10 text-[9px] md:text-[12px] text-zinc-500 hover:bg-[#C5A059]/10 hover:border-[#C5A059]/50 hover:text-white transition-all uppercase ${language === 'EN' ? 'font-bold tracking-[0.4em]' : 'font-black tracking-[0.3em]'}`}
                    >
                      <Minus className="w-3 h-3 md:w-4 md:h-4 text-primary" />
                      {labels.collapse}
                    </motion.button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

const ResumeSection: React.FC<any> = ({ content, experience, language }) => {
  const [activeId, setActiveId] = useState<string | null>(experience[0]?.id || null);
  const labels = content.resume.labels;
  const philosophy = language === 'EN' ? DESIGN_PHILOSOPHY_EN : DESIGN_PHILOSOPHY_CN;

  const toggleActive = (id: string) => {
    setActiveId(activeId === id ? null : id);
  };

  return (
    <div className="w-full max-w-7xl mx-auto px-6 py-20">
      <motion.div 
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="mb-40"
      >
        <div className="flex flex-col gap-10">
          <h3 className={`text-base md:text-[3.3vw] font-sans font-bold text-white tracking-tighter max-w-4xl uppercase leading-[1.1]`}>
            <TextType text={philosophy.quote} typingSpeed={60} loop={false} startOnVisible={true} />
          </h3>
          <div className="flex items-center gap-8 pl-1">
            <div className="h-[1px] w-20 bg-primary/40" />
            <p className={`max-w-xl text-lg md:text-xl text-zinc-400 font-light leading-relaxed`}>
              {philosophy.description}
            </p>
          </div>
        </div>
      </motion.div>

      <div className="relative">
        <div className="absolute left-[4.5px] top-0 bottom-0 w-[1px] bg-white/[0.05]" />
        
        <div className="mb-16 md:mb-20 flex items-center gap-6">
          <Sparkles className="w-6 h-6 text-primary" />
          <span className={`text-[12px] uppercase ${language === 'EN' ? 'font-bold tracking-[0.6em]' : 'font-black tracking-[0.5em]'} text-primary`}>{labels.journey}</span>
        </div>

        <LayoutGroup>
          <div className="flex flex-col">
            {experience.map((item: any, idx: number) => (
              <ExperienceItem 
                key={item.id} 
                item={item} 
                index={idx} 
                activeId={activeId}
                toggleActive={toggleActive}
                labels={labels}
                language={language}
              />
            ))}
          </div>
        </LayoutGroup>
      </div>
    </div>
  );
};

export default ResumeSection;
