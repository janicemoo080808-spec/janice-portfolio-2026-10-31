import React, { useState, useEffect, useRef } from 'react';
import { Language } from '../types';

const SKILLS_LIST = [
  "Brand Strategy & Identity",
  "Visual Arts & Aesthetic Mastery",
  "Human-AI Collaborative Design",
  "UI/UX & Product Experience",
  "CMF (Color, Material, Finish)",
  "Leadership & Resource Integration"
];

interface SkillsMarqueeProps {
  className?: string;
  language: Language;
}

const SkillsMarquee: React.FC<SkillsMarqueeProps> = ({ className, language }) => {
  const [isInView, setIsInView] = useState(false);
  const [isHovered, setIsHovered] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        setIsInView(entry.isIntersecting);
      },
      { threshold: 0.1 }
    );

    if (containerRef.current) {
      observer.observe(containerRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <div 
      ref={containerRef}
      className={`relative flex items-center overflow-hidden py-6 transform-gpu ${className || ''}`}
      style={{
        maskImage: 'linear-gradient(to right, transparent, black 15%, black 85%, transparent)',
        WebkitMaskImage: 'linear-gradient(to right, transparent, black 15%, black 85%, transparent)'
      }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="flex-shrink-0 flex items-center gap-4 mr-10 z-10 bg-black pr-8 border-r border-white/10">
        <span className={`text-[10px] uppercase whitespace-nowrap ${language === 'EN' ? 'font-bold tracking-[0.6em]' : 'font-black tracking-[0.5em]'} text-primary`}>SKILLS</span>
      </div>
      <div className="flex-1 overflow-hidden">
        <div 
          className="marquee-inner flex items-center gap-16 whitespace-nowrap will-change-transform"
          style={{ 
            animationPlayState: isInView ? 'running' : 'paused',
            animationDuration: isHovered ? '80s' : '40s'
          }}
        >
          {/* Reduced node count: Two sets are sufficient for a seamless -50% translateX loop */}
          {[...SKILLS_LIST, ...SKILLS_LIST].map((skill, idx) => (
            <span 
              key={idx} 
              className="text-sm md:text-lg font-black tracking-[0.2em] text-zinc-600 hover:text-white transition-all duration-500 uppercase hover:scale-110 hover:-translate-y-1 inline-block cursor-default"
            >
              {skill}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
};

export default SkillsMarquee;