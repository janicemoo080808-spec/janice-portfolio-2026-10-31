
import React from 'react';
import { motion as m } from 'framer-motion';

// Cast motion to any to bypass environment-specific type definition issues
const motion = m as any;

interface HorizonItem {
  title: string;
  desc: string;
}

interface StrategicHorizonProps {
  items: HorizonItem[];
  language: string;
}

const StrategicHorizon: React.FC<StrategicHorizonProps> = ({ items, language }) => {
  // Helper to format text with bold markers **text**
  const formatDesc = (text: string) => {
    const parts = text.split(/(\*\*.*?\*\*)/g);
    return parts.map((part, i) => {
      if (part.startsWith('**') && part.endsWith('**')) {
        return (
          <strong key={i} className={`transition-colors font-bold text-zinc-100`}>
            {part.slice(2, -2)}
          </strong>
        );
      }
      return part;
    });
  };

  const isEn = language === 'EN';

  return (
    <div className="w-full">
      <div className={`grid grid-cols-1 md:grid-cols-2 gap-x-12 lg:gap-x-20 ${isEn ? 'gap-y-6 md:gap-y-8' : 'gap-y-10 md:gap-y-14'}`}>
        {items.map((item, idx) => (
          <motion.div 
            key={idx}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: idx * 0.1, ease: [0.16, 1, 0.3, 1] }}
            className={`group flex flex-col ${isEn ? 'gap-3 md:gap-4' : 'gap-6 md:gap-8'}`}
          >
            {/* Minimalist marker and title */}
            <div className="flex flex-col gap-4">
              <div className="h-[1px] w-8 bg-primary/20 group-hover:w-12 group-hover:bg-primary transition-all duration-700" />
              <h3 className={`font-sans font-bold text-white tracking-tight uppercase group-hover:text-primary transition-colors ${
                isEn 
                  ? 'text-lg md:text-xl lg:text-[21px] leading-[1.1]' 
                  : 'text-lg md:text-xl lg:text-2xl leading-none'
              }`}>
                {item.title}
              </h3>
            </div>
            
            {/* Description */}
            <p className={`text-zinc-400 md:text-zinc-500 font-light transition-colors duration-500 max-w-xl group-hover:text-zinc-300 ${
              isEn 
                ? 'text-[13px] md:text-[14px] lg:text-[15px] leading-[1.6]' 
                : 'text-base md:text-base lg:text-lg leading-relaxed'
            }`}>
              {formatDesc(item.desc)}
            </p>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default StrategicHorizon;
