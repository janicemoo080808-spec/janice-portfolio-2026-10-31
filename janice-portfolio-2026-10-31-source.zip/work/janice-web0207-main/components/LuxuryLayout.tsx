import React, { useState, useRef, useEffect } from 'react';
import { motion as m, AnimatePresence, useScroll, useTransform, useSpring } from 'framer-motion';
import { 
  X, ChevronLeft, ArrowUp
} from 'lucide-react';
import { Project } from '../types';

// Cast motion to any to bypass environment-specific type definition issues
const motion = m as any;

const ZoomImage: React.FC<{ 
  src: string; 
  className?: string; 
  alt?: string; 
  type?: 'image' | 'video';
}> = ({ src, className = "", alt = "", type = 'image' }) => {
  const [transformOrigin, setTransformOrigin] = useState("center center");

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    setTransformOrigin(`${x}% ${y}%`);
  };

  return (
    <motion.div 
      onMouseMove={handleMouseMove}
      className={`relative overflow-hidden group/zoom bg-transparent transform-gpu will-change-transform rounded-xl ${className}`}
    >
      {type === 'video' ? (
        <motion.video 
          src={src} 
          autoPlay muted loop playsInline 
          style={{ transformOrigin }}
          whileHover={{ scale: 1.05 }}
          transition={{ type: "spring", stiffness: 80, damping: 20 }}
          poster={src.replace('.MP4', '.webp').replace('.mp4', '.webp')}
          className="w-full h-auto max-h-[90vh] object-contain block transition-transform duration-700 will-change-transform bg-transparent" 
        />
      ) : (
        <motion.img
          src={src}
          alt={alt}
          style={{ transformOrigin }}
          whileHover={{ scale: 1.05 }}
          transition={{ type: "spring", stiffness: 80, damping: 20 }}
          className="w-full h-auto max-h-[90vh] object-contain block transition-transform duration-700 will-change-transform bg-transparent"
        />
      )}
    </motion.div>
  );
};

const MobileLuxuryCarousel: React.FC<{ 
  items: { type: 'image' | 'video'; url: string }[] 
}> = ({ items }) => {
  const [activeIndex, setActiveIndex] = useState(0);
  const scrollRef = useRef<HTMLDivElement>(null);

  const handleScroll = () => {
    if (scrollRef.current) {
      const { scrollLeft, offsetWidth } = scrollRef.current;
      const index = Math.round(scrollLeft / offsetWidth);
      if (index !== activeIndex) setActiveIndex(index);
    }
  };

  return (
    <div className="w-full space-y-0.5">
      <div 
        ref={scrollRef}
        onScroll={handleScroll}
        className="flex overflow-x-auto snap-x snap-mandatory no-scrollbar -mx-6 px-4 md:px-12"
      >
        {items.map((item, i) => (
          <div key={i} className="flex-shrink-0 w-full snap-center px-2">
            <ZoomImage 
              src={item.url} 
              type={item.type} 
              className="w-full aspect-[4/5] object-cover shadow-lg" 
            />
          </div>
        ))}
      </div>
      
      {/* Xiaohongshu Style Indicators */}
      <div className="flex justify-center items-center gap-1 pt-0">
        {items.map((_, i) => (
          <motion.div
            key={i}
            animate={{ 
              width: i === activeIndex ? 16 : 4,
              opacity: i === activeIndex ? 1 : 0.3
            }}
            className={`h-1 rounded-full bg-primary/90 opacity-90 transition-all duration-300`}
          />
        ))}
      </div>
    </div>
  );
};

const LuxuryLayout: React.FC<{ project: Project; onClose: () => void }> = ({ project, onClose }) => {
  const [activeTab, setActiveTab] = useState<number>(0);
  const containerRef = useRef<HTMLDivElement>(null);

  const { scrollYProgress } = useScroll({ container: containerRef });
  const springProgress = useSpring(scrollYProgress, { stiffness: 100, damping: 30 });
  const navBgOpacity = useTransform(scrollYProgress, [0, 0.05], [0, 0.98]);

  const displaySections = project.sections.slice(1);
  const isEn = !/[\u4e00-\u9fa5]/.test(project.title);

  useEffect(() => {
    const options = {
      root: containerRef.current,
      rootMargin: '-20% 0px -60% 0px',
      threshold: 0
    };

    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          const index = parseInt(entry.target.getAttribute('data-index') || '0');
          setActiveTab(index);
        }
      });
    }, options);

    displaySections.forEach((_, i) => {
      const el = document.getElementById(`luxury-section-${i}`);
      if (el) observer.observe(el);
    });

    return () => observer.disconnect();
  }, [displaySections]);

  const scrollToSection = (index: number) => {
    const el = document.getElementById(`luxury-section-${index}`);
    if (el && containerRef.current) {
      const offset = 120;
      containerRef.current.scrollTo({
        top: el.offsetTop - offset,
        behavior: 'smooth'
      });
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }} 
      animate={{ opacity: 1 }} 
      exit={{ opacity: 0 }} 
      className="fixed inset-0 z-[3000] bg-black overflow-hidden transform-gpu translate-z-0 isolate"
    >
      <motion.div 
        style={{ scaleX: springProgress }}
        className="fixed top-0 left-0 right-0 h-[2px] bg-primary z-[3200] origin-left pointer-events-none"
      />

      <motion.nav 
        style={{ 
          backgroundColor: `rgba(10, 10, 10, ${navBgOpacity.get()})`, 
          borderBottomColor: `rgba(255, 255, 255, ${navBgOpacity.get() * 0.05})`,
          backdropFilter: 'blur(50px)'
        }}
        className="fixed top-0 left-0 right-0 h-16 md:h-20 z-[3100] border-b border-transparent flex items-center px-6 md:px-12 transition-all duration-700 isolate"
      >
        <div className="w-full max-w-[1550px] mx-auto flex items-center pointer-events-auto">
          <button 
            onClick={onClose} 
            className="flex items-center justify-center min-w-[44px] gap-3 px-5 py-2 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 text-white font-black uppercase font-sans text-[10px] tracking-[0.2em] transition-all group shrink-0 relative z-20 isolate"
          >
            <ChevronLeft className="w-5 h-5 md:w-3.5 md:h-3.5 group-hover:-translate-x-1 transition-transform" />
            <span className="hidden lg:block">BACK</span>
          </button>
          
          <div className="w-[1px] h-6 bg-white/10 mx-6 md:mx-8 shrink-0" />
          
          <div className={`flex-1 flex items-center gap-8 md:gap-12 font-sans font-black uppercase text-[10px] tracking-[0.2em] overflow-x-auto no-scrollbar whitespace-nowrap min-w-0`}>
            {displaySections.map((section, idx) => (
              <button 
                key={idx} 
                onClick={() => scrollToSection(idx)} 
                className={`transition-all hover:text-primary shrink-0 ${activeTab === idx ? 'text-primary' : 'text-zinc-600'}`}
              >
                0{idx + 1} · {section.label}
              </button>
            ))}
          </div>
        </div>
      </motion.nav>

      <div 
        ref={containerRef}
        className="w-full h-full overflow-y-auto no-scrollbar scroll-smooth"
      >
        <section className="h-[100dvh] flex flex-col justify-end pb-24 px-6 md:px-24 relative overflow-hidden bg-black">
          <div className="absolute inset-0 z-0">
            <video 
              src="https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/video/luxury/chanel_01_video.MP4"
              autoPlay 
              muted 
              loop 
              playsInline
              poster="https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/cover/cover1.webp"
              className="w-full h-full object-cover opacity-80 saturate-[0.85] scale-100" 
            />
            <div className="absolute inset-x-0 bottom-0 h-[50vh] bg-transparent backdrop-blur-[30px]" style={{ WebkitMaskImage: 'linear-gradient(to top, black 0%, transparent 100%)', maskImage: 'linear-gradient(to top, black 0%, transparent 100%)' }} />
          </div>

          <div className="relative z-10 max-w-[1550px] mx-auto w-full flex flex-col items-start">
            <motion.h1 
              initial={{ opacity: 0, y: 15 }} 
              animate={{ opacity: 1, y: 0 }} 
              transition={{ duration: 1.5, ease: [0.16, 1, 0.3, 1] }} 
              className="text-3xl md:text-[4vw] font-sans font-bold leading-[1.1] tracking-tight text-white uppercase drop-shadow-2xl"
            >
              {project.title}
            </motion.h1>
          </div>
        </section>

        <div className="space-y-16 lg:space-y-60 pb-40 md:pb-80 mt-16 md:mt-24">
          {displaySections.map((section, idx) => {
            const allMedia: { type: 'image' | 'video'; url: string }[] = [];
            section.images?.forEach(img => allMedia.push({ type: 'image', url: img }));
            if (section.videoUrl) allMedia.push({ type: 'video', url: section.videoUrl });
            section.points?.forEach(pt => {
              if (typeof pt === 'string' && pt.includes('.mp4')) {
                allMedia.push({ type: 'video', url: pt });
              }
            });

            const upperTitle = section.title.toUpperCase();
            const isTwoColumn = upperTitle.includes('LOEWE') || upperTitle.includes('LORO PIANA') || upperTitle.includes('CARTIER');

            return (
              <section 
                key={idx} 
                id={`luxury-section-${idx}`} 
                data-index={idx}
                className="px-6 md:px-24 max-w-[1550px] mx-auto w-full group scroll-mt-32 content-visibility-auto"
              >
                <div className="hidden lg:grid grid-cols-12 gap-24 items-start">
                  <div className="lg:col-span-4 space-y-10 lg:sticky lg:top-40 h-fit">
                    <div className="space-y-6">
                      <div className="flex items-center gap-4">
                        <span className="text-[10px] font-black text-primary font-light opacity-90 tracking-[0.8em] uppercase">CHAPTER 0{idx + 1}</span>
                        <div className="h-[1px] flex-1 bg-white/10" />
                      </div>
                      <h2 className="text-xl md:text-[2vw] font-sans font-bold text-white tracking-tighter uppercase leading-[1.1] text-left">
                        {section.title}
                      </h2>
                      <p className="text-[13px] md:text-lg text-zinc-400 leading-relaxed font-light text-left">
                        {section.description}
                      </p>
                    </div>
                  </div>

                  <div className="lg:col-span-8">
                    <div className={isTwoColumn ? "grid grid-cols-2 gap-8 items-start" : "space-y-20"}>
                      {allMedia.map((item, mIdx) => (
                        <motion.div 
                          key={mIdx}
                          initial={{ opacity: 0, y: 15 }}
                          whileInView={{ opacity: 1, y: 0 }}
                          viewport={{ once: true, margin: "-10%" }}
                          transition={{ duration: 0.8, ease: "easeOut" }}
                          className="w-full flex justify-center"
                        >
                          <ZoomImage 
                            src={item.url} 
                            type={item.type}
                            className="w-full bg-transparent shadow-2xl"
                          />
                        </motion.div>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="lg:hidden flex flex-col space-y-8">
                  <div className="space-y-4">
                    <div className="flex items-center gap-4">
                      <span className="text-[9px] font-black text-primary font-light opacity-90 tracking-[0.4em] uppercase">CHAPTER 0{idx + 1}</span>
                      <div className="h-[1px] flex-1 bg-white/5" />
                    </div>
                    <h2 className="text-xl font-sans font-bold text-white tracking-tighter uppercase leading-[1.1]">
                      {section.title}
                    </h2>
                    <p className="text-[13px] text-zinc-400 leading-relaxed font-light">
                      {section.description}
                    </p>
                  </div>
                  
                  <MobileLuxuryCarousel items={allMedia} />
                </div>
              </section>
            );
          })}
        </div>

        <section className="px-6 py-12 md:py-60 border-t border-white/5 bg-zinc-950/30 text-center relative overflow-hidden min-h-fit md:min-h-[80vh] flex flex-col justify-center">
           <div className="max-w-5xl mx-auto relative z-10 px-6">
              <motion.div initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }}>
                <h3 className={`font-sans font-bold text-white mb-6 md:mb-20 tracking-tight text-balance max-w-6xl mx-auto text-center leading-relaxed ${isEn ? 'text-[clamp(1.1rem,4.5vw,2rem)]' : 'text-[clamp(1.5rem,6vw,2.5rem)]'}`}>
                  {isEn ? (
                    <>Architecting <span className="text-primary font-light opacity-90">non-replicable brand sovereignty</span> <br className="hidden md:block" /><span className="text-primary font-light opacity-90">through high-dimensional aesthetic resonance.</span></>
                  ) : (
                    <>在高维审美的共振中，<br/><span className="text-primary font-light opacity-90 whitespace-nowrap">构建不可复制的品牌主权。</span></>
                  )}
                </h3>
                <div className="flex flex-col md:flex-row items-center justify-center gap-6">
                  <button onClick={onClose} className="px-6 py-2.5 md:px-16 md:py-6 rounded-full bg-white text-black font-black uppercase text-[10px] md:text-[12px] tracking-[0.4em] hover:bg-[#E5E5E5] hover:text-black transition-all shadow-4xl duration-500">BACK</button>
                </div>
              </motion.div>
           </div>
        </section>
      </div>

      <style>{`
        .no-scrollbar::-webkit-scrollbar { display: none; }
        .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
        .text-balance { text-wrap: balance; }
        .content-visibility-auto { content-visibility: auto; contain-intrinsic-size: 1px 1000px; }
      `}</style>
    </motion.div>
  );
};

export default LuxuryLayout;