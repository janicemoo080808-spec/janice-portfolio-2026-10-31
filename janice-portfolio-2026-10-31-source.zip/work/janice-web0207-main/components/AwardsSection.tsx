
import React, { useState } from 'react';
import { motion as m } from 'framer-motion';
import { Trophy, Star, CheckCircle2 } from 'lucide-react';
import { AwardItem } from '../types';

// Cast motion to any to bypass environment-specific type definition issues
const motion = m as any;

const AwardCard: React.FC<{ name: string; desc: string; index: number; language: string }> = ({ name, desc, index, language }) => {
  const isGold = name.toLowerCase().includes('gold');
  const isSilver = name.toLowerCase().includes('silver');

  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay: index * 0.1, duration: 0.8, ease: [0.21, 0.47, 0.32, 0.98] }}
      className="group relative py-8 border-b border-white/5 flex flex-col md:flex-row md:items-center justify-between gap-4"
    >
      <div className="flex-1">
        <div className={`flex items-center gap-6 ${desc && language !== 'EN' ? 'mb-2' : ''}`}>
          <span className="text-[13px] font-mono font-black text-zinc-700 tracking-tighter w-8">0{index + 1}</span>
          <h4 className={`text-[16px] md:text-[18px] font-display font-bold tracking-tight transition-colors duration-500 ${isGold ? 'group-hover:text-primary' : 'group-hover:text-white'} text-zinc-300`}>
            {name.split(' — ')[0]}
          </h4>
        </div>
        {desc && language !== 'EN' && (
          <p className="text-[11px] md:text-[12px] text-zinc-500 font-normal uppercase ml-14 tracking-[0.15em]">
            {desc}
          </p>
        )}
      </div>
      
      <div className="flex items-center gap-6 ml-14 md:ml-0">
        <span className={`text-[10px] uppercase tracking-[0.2em] px-4 py-1.5 rounded-full border transition-all duration-700 ${language === 'EN' ? 'font-bold' : 'font-black'}
          ${isGold ? 'border-primary/30 bg-primary/5 text-primary group-hover:bg-primary group-hover:text-white' : 
            isSilver ? 'border-zinc-800 bg-zinc-900/50 text-zinc-400 group-hover:bg-zinc-100 group-hover:text-black' : 
            'border-white/5 bg-white/5 text-zinc-500 group-hover:bg-white/10 group-hover:text-white'}
        `}>
          {name.split(' — ')[1] || 'FINALIST'}
        </span>
        <Trophy className={`w-4 h-4 transition-all duration-700 ${isGold ? 'text-primary/20 group-hover:text-primary' : 'text-zinc-900 group-hover:text-zinc-500'}`} />
      </div>
      
      {/* Hover Background Accent */}
      <div className="absolute inset-0 -z-10 bg-gradient-to-r from-white/[0.02] to-transparent opacity-0 group-hover:opacity-100 transition-opacity rounded-xl" />
    </motion.div>
  );
};

interface AwardsSectionProps {
  subtitle?: string;
  desc?: string;
  items?: AwardItem[];
  language: string;
}

const AwardsSection: React.FC<AwardsSectionProps> = ({ subtitle = "International Honors", desc, items = [], language }) => {
  // Use provided items from props, or fallback
  const displayAwards = items.length > 0 ? items : [
    { name: "New York Product Design Awards — Silver Winner", desc: "纽约产品设计奖 · 银奖", level: "" },
    { name: "London Design Awards — Gold Winner", level: "", desc: "伦敦设计奖 · 金奖" },
    { name: "French Design Awards — Gold Winner", level: "", desc: "法国设计奖 · 金奖" },
    { name: "MUSE Design Awards (USA) — Gold Winner", level: "", desc: "美国 MUSE 设计奖 · 金奖" },
    { name: "European Design Awards — Gold Winner", level: "", desc: "欧洲设计奖 · 金奖" },
    { name: "iida Design Award (Italy) — Finalist", level: "", desc: "意大利 iida 设计奖 · 入围" },
    { name: "iF Design Award — Finalist", level: "", desc: "iF 设计奖 · 入围" }
  ];

  return (
    <section id="awards" className="w-full bg-black py-16 md:py-20 border-t border-white/5 overflow-hidden">
      <div className="max-w-[1440px] mx-auto px-6 md:px-12">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 md:gap-16">
          
          {/* Left Axis: Strategic Narrative */}
          <div className="lg:col-span-5">
            <div className="sticky top-32">
              <motion.h2 
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.1 }}
                className={`text-2xl md:text-[5vw] font-sans font-bold text-white tracking-tighter uppercase mb-8 ${language === 'EN' ? 'leading-[1.1]' : 'leading-[0.85]'}`}
              >
                {subtitle}
              </motion.h2>

              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.2 }}
                className="space-y-6"
              >
                <h3 className="text-xl md:text-2xl font-bold text-primary tracking-tight">Crydit (0–1 Phase)</h3>
              </motion.div>
            </div>
          </div>

          {/* Right Axis: Awards Ledger */}
          <div className="lg:col-span-7">
            <div className="flex flex-col">
              {displayAwards.map((award, idx) => (
                <AwardCard key={idx} index={idx} name={award.name} desc={award.desc} language={language} />
              ))}
            </div>
            
            <motion.div 
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              className="mt-12 flex items-center justify-center lg:justify-start"
            >
               <div className="flex items-center gap-6 opacity-20">
                  <Star className="w-3.5 h-3.5 text-white" />
                  <div className="h-[0.5px] w-24 bg-gradient-to-r from-white to-transparent" />
               </div>
            </motion.div>
          </div>

        </div>
      </div>
    </section>
  );
};

export default AwardsSection;
