import React, { useState, useRef, useEffect, useCallback } from 'react';
import { motion as m, AnimatePresence, useScroll, useTransform, useSpring } from 'framer-motion';
import { 
  ChevronLeft, ArrowUp, X, Maximize2, ChevronRight, Circle, ArrowRight
} from 'lucide-react';
import { Project } from '../types';

// Cast motion to any to bypass environment-specific type definition issues
// In this file, the alias used is "Motion" (capital M)
const Motion = m as any;

const GrainOverlay = () => (
  <div className="fixed inset-0 pointer-events-none z-[1001] opacity-[0.03] mix-blend-overlay">
    <svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
      <filter id="noiseFilter">
        <feTurbulence type="fractalNoise" baseFrequency="0.65" numOctaves="3" stitchTiles="stitch" />
      </filter>
      <rect width="100%" height="100%" filter="url(#noiseFilter)" />
    </svg>
  </div>
);

const ActivityImage: React.FC<{ 
  src: string; 
  className?: string; 
  alt?: string; 
  onPreview?: () => void;
}> = ({ src, className = "", alt = "", onPreview }) => {
  return (
    <div 
      onClick={onPreview}
      className={`relative cursor-zoom-in group/img overflow-hidden rounded-[12px] border border-white/10 transition-all duration-500 shadow-2xl aspect-video ${className}`}
    >
      <img
        src={src}
        alt={alt}
        className="w-full h-full object-cover block transition-transform duration-1000 group-hover/img:scale-[1.05]"
      />
      <div className="absolute top-4 right-4 opacity-0 group-hover/img:opacity-100 transition-opacity bg-black/40 backdrop-blur-md p-2 rounded-full">
         <Maximize2 className="w-3.5 h-3.5 text-white" />
      </div>
    </div>
  );
};

const KenyaCollageSection: React.FC<{ images: string[]; onPreview: (src: string) => void }> = ({ images, onPreview }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [mouseX, setMouseX] = useState(0.5);

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    setMouseX((e.clientX - rect.left) / rect.width);
  };

  const baseX = (mouseX - 0.5) * -100;
  const detailsX = (mouseX - 0.5) * 150;

  return (
    <div 
      ref={containerRef}
      onMouseMove={handleMouseMove}
      onMouseLeave={() => setMouseX(0.5)}
      className="relative w-full h-[550px] md:h-[800px] overflow-hidden my-8 md:no-scrollbar my-16 rounded-[2rem] cursor-crosshair group/collage"
    >
      <Motion.div 
        animate={{ baseX }}
        transition={{ type: 'spring', stiffness: 50, damping: 20 }}
        className="absolute inset-y-0 w-[150%] left-[-25%] z-0"
      >
        <img 
          src={images[0]} 
          className="w-full h-full object-cover" 
          alt="Community Panorama" 
        />
        <div className="absolute inset-0 bg-black/40 group-hover/collage:bg-black/20 transition-colors duration-700" />
      </Motion.div>

      <Motion.div 
        animate={{ x: detailsX }}
        transition={{ type: 'spring', stiffness: 40, damping: 25 }}
        className="absolute inset-0 z-10 pointer-events-none"
      >
        {images.slice(1, 5).map((img, i) => (
          <Motion.div 
            key={i}
            className={`absolute w-[45%] md:w-[28%] pointer-events-auto`}
            style={{ 
              top: `${10 + i * 15}%`, 
              left: i % 2 === 0 ? '5%' : '50%',
              rotate: i % 2 === 0 ? -5 : 5
            }}
            whileHover={{ scale: 1.05, rotate: 0, zIndex: 50 }}
          >
            <ActivityImage src={img} onPreview={() => onPreview(img)} />
          </Motion.div>
        ))}
      </Motion.div>
    </div>
  );
};

const StrategicHorizontalBlueprint: React.FC<{ points: string[] }> = ({ points }) => {
  const validPoints = points.filter(p => !p.startsWith('*'));

  return (
    <div className="relative mt-16 md:mt-32 pb-20">
      <div className="hidden md:block absolute top-0 left-0 right-0 h-[1px] bg-white/10 overflow-hidden">
        <Motion.div 
          initial={{ x: '-100%' }}
          whileInView={{ x: '100%' }}
          viewport={{ once: true }}
          transition={{ duration: 2, ease: "easeInOut" }}
          className="w-full h-full bg-gradient-to-r from-transparent via-primary to-transparent"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 md:gap-0 relative">
        {validPoints.map((p, idx) => {
          const parts = p.split(/[：:]/);
          const isEnglish = !/[\u4e00-\u9fa5]/.test(p);
          
          let title = "";
          let desc = "";

          if (parts.length > 1) {
            title = parts[0].trim();
            desc = parts.slice(1).join(':').trim();
          } else {
            desc = p.trim();
          }

          return (
            <Motion.div 
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: idx * 0.1, ease: [0.16, 1, 0.3, 1] }}
              className={`relative md:pt-16 md:px-8 group border-l md:border-l-0 ${idx !== 0 ? 'md:border-l md:border-white/5' : ''} border-white/10 pl-8`}
            >
              <div className="absolute -left-[5px] md:left-1/2 md:-translate-x-1/2 top-0 w-2.5 h-2.5 rounded-full bg-black border border-primary group-hover:scale-150 transition-transform duration-500 shadow-[0_0_10px_rgba(134,87,11,0.5)] hidden md:block" />
              
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <span className="text-[13px] font-mono font-black text-primary/90 opacity-90 group-hover:text-primary transition-colors">
                    LOGIC_0{idx + 1}
                  </span>
                  <ArrowRight className="w-3.5 h-3.5 text-white/10 group-hover:translate-x-1 transition-all group-hover:text-[#E5E5E5]" />
                </div>
                
                {title && (
                  <h4 className={`font-sans text-white tracking-tight leading-snug transition-colors group-hover:text-white ${
                    isEnglish 
                      ? 'text-base md:text-lg font-bold' 
                      : 'text-xl md:text-3xl font-bold uppercase'
                  }`}>
                    {title}
                  </h4>
                )}
                
                <p className={`${
                  isEnglish ? 'text-[13px] md:text-[14px]' : 'text-[13px] md:text-lg'
                } text-zinc-500 font-light leading-relaxed group-hover:text-zinc-300 transition-colors`}>
                  {desc}
                </p>

                <span className="absolute -bottom-4 -right-2 text-[10vw] md:text-[6vw] font-black text-white/[0.02] pointer-events-none select-none group-hover:text-white/[0.04] transition-colors duration-1000">
                  {idx + 1}
                </span>
              </div>
            </Motion.div>
          );
        })}
      </div>
    </div>
  );
};

const AssetCarousel: React.FC<{ images: string[]; onPreview: (src: string) => void }> = ({ images, onPreview }) => {
  const scrollRef = useRef<HTMLDivElement>(null);

  const scroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const { scrollLeft, clientWidth } = scrollRef.current;
      const scrollTo = direction === 'left' ? scrollLeft - clientWidth : scrollLeft + clientWidth;
      scrollRef.current.scrollTo({ left: scrollTo, behavior: 'smooth' });
    }
  };

  return (
    <div className="relative w-full group/carousel">
      <div className="flex items-center gap-6 mb-6">
        <div className="h-[1px] flex-1 bg-white/10" />
        <div className="flex gap-4">
          <button onClick={() => scroll('left')} className="p-3 rounded-full bg-white/5 border border-white/10 hover:bg-[#E5E5E5] hover:text-black transition-all"><ChevronLeft className="w-4 h-4" /></button>
          <button onClick={() => scroll('right')} className="p-3 rounded-full bg-white/5 border border-white/10 hover:bg-[#E5E5E5] hover:text-black transition-all"><ChevronRight className="w-4 h-4" /></button>
        </div>
      </div>
      
      <div 
        ref={scrollRef}
        className="flex gap-8 overflow-x-auto no-scrollbar snap-x snap-mandatory pb-8"
      >
        {images.map((img, idx) => (
          <Motion.div 
            key={idx}
            className="flex-shrink-0 w-[85vw] md:w-[60vw] lg:w-[45vw] snap-center aspect-video rounded-[16px] overflow-hidden bg-zinc-950 border border-white/5"
          >
            <img 
              src={img} 
              onClick={() => onPreview(img)}
              className="w-full h-full object-cover cursor-zoom-in hover:scale-105 transition-transform duration-1000" 
              alt={`Asset ${idx}`} 
            />
          </Motion.div>
        ))}
      </div>
      <div className="flex justify-center gap-2 mt-4 opacity-0 group-hover/carousel:opacity-100 transition-opacity">
        <span className="text-[9px] font-black text-zinc-500 uppercase tracking-widest">DRAG OR USE ARROWS TO BROWSE FULL ASSETS</span>
      </div>
    </div>
  );
};

const StrategicText: React.FC<{ points: string[] }> = ({ points }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-6 text-[13px] md:text-lg leading-relaxed text-zinc-400 font-light">
      {points.map((p, idx) => (
        <div key={idx} className="flex gap-4 group/point">
          <div className="w-1.5 h-1.5 rounded-full bg-primary/90 opacity-90 mt-2 flex-shrink-0" />
          <p>{p.startsWith('• ') ? p.substring(2) : p}</p>
        </div>
      ))}
    </div>
  );
};

const ImagePreviewModal: React.FC<{ src: string | null; onClose: () => void }> = ({ src, onClose }) => (
  <AnimatePresence>
    {src && (
      <Motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="fixed inset-0 z-[4000] bg-black/95 backdrop-blur-xl flex items-center justify-center p-4 md:p-12 cursor-zoom-out"
      >
        <button className="absolute top-8 right-8 w-12 h-12 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-white z-10 hover:bg-white/10 transition-all"><X className="w-6 h-6" /></button>
        <Motion.img
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          src={src}
          className="max-w-full max-h-full object-contain"
        />
      </Motion.div>
    )}
  </AnimatePresence>
);

const ActivityLayout: React.FC<{ project: Project; onClose: () => void }> = ({ project, onClose }) => {
  const [activeTab, setActiveTab] = useState<number>(0);
  const [previewImage, setPreviewImage] = useState<string | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const { scrollYProgress } = useScroll({ container: containerRef });
  const springProgress = useSpring(scrollYProgress, { stiffness: 100, damping: 30 });
  const navBgOpacity = useTransform(scrollYProgress, [0, 0.05], [0, 0.98]);

  const displaySections = project.sections.slice(1);
  const isEn = !/[\u4e00-\u9fa5]/.test(project.title);

  const scrollToSection = (index: number) => {
    const el = document.getElementById(`activity-section-${index}`);
    if (el && containerRef.current) {
      containerRef.current.scrollTo({
        top: el.offsetTop - 160,
        behavior: 'smooth'
      });
      setActiveTab(index);
    }
  };

  useEffect(() => {
    const options = {
      root: containerRef.current,
      rootMargin: '-20% 0px -60% 0px',
      threshold: 0
    };

    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          const index = parseInt(entry.target.getAttribute('data-index') || '0');
          setActiveTab(index);
        }
      });
    }, options);

    displaySections.forEach((_, i) => {
      const el = document.getElementById(`activity-section-${i}`);
      if (el) observer.observe(el);
    });

    return () => observer.disconnect();
  }, [displaySections]);

  return (
    <Motion.div 
      initial={{ opacity: 0 }} 
      animate={{ opacity: 1 }} 
      exit={{ opacity: 0 }} 
      className="fixed inset-0 z-[3000] bg-black overflow-hidden isolate"
    >
      <ImagePreviewModal src={previewImage} onClose={() => setPreviewImage(null)} />

      <Motion.div 
        style={{ scaleX: springProgress }}
        className="fixed top-16 md:top-20 left-0 right-0 h-[2px] bg-primary z-[5200] origin-left pointer-events-none"
      />

      <Motion.nav 
        style={{ 
          backgroundColor: `rgba(10, 10, 10, ${navBgOpacity.get()})`, 
          borderBottomColor: `rgba(255, 255, 255, ${navBgOpacity.get() * 0.05})`,
          backdropFilter: 'blur(50px)'
        }}
        className="fixed top-16 md:top-20 left-0 right-0 h-16 md:h-20 z-[5100] border-b border-transparent flex items-center px-6 md:px-12 transition-all duration-700 isolate"
      >
        <div className="w-full max-w-[1550px] mx-auto flex items-center pointer-events-auto">
          <button 
            onClick={onClose} 
            className="flex items-center justify-center min-w-[44px] gap-3 px-5 py-2 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 text-white font-black uppercase font-sans text-[10px] tracking-[0.2em] transition-all group shrink-0 relative z-20 isolate"
          >
            <ChevronLeft className="w-5 h-5 md:w-3.5 md:h-3.5 group-hover:-translate-x-1 transition-transform" />
            <span className="hidden lg:block">BACK</span>
          </button>
          
          <div className="w-[1px] h-6 bg-white/10 mx-6 md:mx-8 shrink-0" />
          
          <div className={`flex-1 flex items-center gap-8 md:gap-12 font-sans font-black uppercase text-[10px] tracking-[0.2em] overflow-x-auto no-scrollbar whitespace-nowrap min-w-0`}>
            {displaySections.map((section, idx) => (
              <button 
                key={idx} 
                onClick={() => scrollToSection(idx)} 
                className={`transition-all hover:text-primary shrink-0 ${activeTab === idx ? 'text-primary' : 'text-zinc-600'}`}
              >
                0{idx + 1} · {section.label}
              </button>
            ))}
          </div>
        </div>
      </Motion.nav>

      <div 
        ref={containerRef}
        className="w-full h-full overflow-y-auto no-scrollbar scroll-smooth scroll-pt-[128px] md:scroll-pt-[160px]"
      >
        <section className="min-h-[60vh] flex flex-col justify-end pb-20 px-6 md:px-24 relative overflow-hidden bg-black border-b border-white/5">
          <div className="absolute inset-0 z-0">
            <img src={project.imageUrl} className="w-full h-full object-cover opacity-45" alt="Hero" />
            <div className="absolute inset-x-0 bottom-0 h-[50vh] bg-transparent backdrop-blur-[30px]" style={{ WebkitMaskImage: 'linear-gradient(to top, black 0%, transparent 100%)', maskImage: 'linear-gradient(to top, black 0%, transparent 100%)' }} />
          </div>
          <div className="relative z-10 max-w-[1550px] mx-auto w-full flex flex-col items-start">
            <Motion.h1 initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="text-3xl md:text-[4.5vw] font-sans font-bold leading-[0.9] tracking-tighter text-white uppercase drop-shadow-2xl">{project.title}</Motion.h1>
          </div>
        </section>

        <div className="space-y-24 md:space-y-48 py-20 md:py-32">
          {displaySections.map((section: any, idx: number) => {
            const isSlider = section.isSlider === true || section.title.includes("品牌重塑") || section.title.includes("Token 2049") || section.title.includes("Rebranding");
            const isKenya = section.title.includes("肯尼亚公益行") || section.title.includes("Kenya Charity");

            const allVideos = [];
            if (section.videoUrl) allVideos.push(section.videoUrl);
            if (section.additionalVideos) allVideos.push(...section.additionalVideos);
            
            return (
              <section key={idx} id={`activity-section-${idx}`} data-index={idx} className="px-6 md:px-24 max-w-7xl mx-auto w-full scroll-mt-32">
                <div className="mb-12 md:mb-16">
                  <span className="text-[9px] md:text-[10px] font-black text-primary font-light opacity-90 tracking-[1em] uppercase mb-4 block">CHAPTER 0{idx + 1}</span>
                  <h2 className="text-xl md:text-[2vw] font-sans font-bold text-white tracking-tighter uppercase mb-6 md:mb-8 leading-tight">{section.title}</h2>
                  <p className="text-[13px] md:text-lg text-zinc-400 leading-relaxed font-light mb-10 md:mb-12 max-w-4xl">{section.description}</p>
                  {section.points && !isKenya && <StrategicText points={section.points} />}
                </div>

                {isKenya ? (
                  <>
                    <KenyaCollageSection images={section.images || []} onPreview={setPreviewImage} />
                    <StrategicHorizontalBlueprint points={section.points || []} />
                    {section.points?.filter((p: string) => p.startsWith('*')).map((p: string, pIdx: number) => (
                      <p key={pIdx} className="text-[11px] text-zinc-500 mt-16 text-center max-w-3xl mx-auto leading-relaxed opacity-60 font-normal">{p.replace(/^\*\s*/, '')}</p>
                    ))}
                  </>
                ) : isSlider ? (
                  <AssetCarousel images={section.images || []} onPreview={setPreviewImage} />
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12">
                    {section.images?.map((img: string, i: number) => (
                      <ActivityImage key={i} src={img} onPreview={() => setPreviewImage(img)} />
                    ))}
                    {allVideos.map((vUrl: string, vIdx: number) => (
                      <div key={vIdx} className="rounded-[12px] overflow-hidden shadow-2xl aspect-video bg-black border border-white/10">
                        <video 
                          src={vUrl} 
                          autoPlay 
                          muted 
                          loop 
                          playsInline 
                          className="w-full h-full object-cover" 
                          poster={section.images && section.images.length > 0 ? section.images[0] : undefined} 
                        />
                      </div>
                    ))}
                  </div>
                )}
              </section>
            );
          })}
        </div>

        <section className="px-6 py-60 bg-zinc-950/50 text-center">
           <div className="max-w-5xl mx-auto px-6">
              <Motion.div initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }}>
                <h3 className={`font-sans font-bold text-white mb-16 tracking-tight text-center mx-auto leading-relaxed ${isEn ? 'text-[clamp(1.25rem,5vw,2rem)]' : 'text-[clamp(1.5rem,6vw,2.5rem)]'}`}>
                  {isEn ? (
                    <>Defining <span className="text-primary font-light opacity-90">brand sovereignty</span> <br/><span className="text-primary font-light opacity-90">through immersive spatial narratives.</span></>
                  ) : (
                    <>用极致空间叙事，<br/><span className="text-primary font-light opacity-90">定义品牌主权</span>。</>
                  )}
                </h3>
                <button onClick={onClose} className="px-14 py-6 rounded-full bg-white text-black font-black uppercase text-[12px] tracking-[0.4em] hover:bg-[#E5E5E5] hover:text-black transition-all shadow-4xl duration-500">BACK</button>
              </Motion.div>
           </div>
        </section>
      </div>

      <style>{`
        .no-scrollbar::-webkit-scrollbar { display: none; }
        .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
      `}</style>
    </Motion.div>
  );
};

export default ActivityLayout;