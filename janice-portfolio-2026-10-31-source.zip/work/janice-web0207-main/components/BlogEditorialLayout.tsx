import React, { useRef, useState, useEffect } from 'react';
import { motion as m, useScroll, useTransform, AnimatePresence, useSpring } from 'framer-motion';
import { X, ChevronLeft, ArrowDown, MousePointer2 } from 'lucide-react';
import { BlogPost, Language } from '../types';

// Cast motion to any to bypass environment-specific type definition issues
const motion = m as any;

// Subtle industrial grain for tactile feel
const GrainOverlay = () => (
  <div className="fixed inset-0 pointer-events-none z-[2000] opacity-[0.02] mix-blend-overlay">
    <svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
      <filter id="noiseFilter">
        <feTurbulence type="fractalNoise" baseFrequency="0.65" numOctaves="3" stitchTiles="stitch" />
      </filter>
      <rect width="100%" height="100%" filter="url(#noiseFilter)" />
    </svg>
  </div>
);

// 优化后的图片组件：去掉背景、边框，确保图片始终清晰
const DecodingImage: React.FC<{ src: string; className?: string; alt?: string; parallax?: boolean }> = ({ src, className = "", alt = "", parallax = false }) => {
  const containerRef = useRef(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start end", "end start"]
  });

  // 取消透明度渐变动画，确保图片从出现起就是 100% 清晰的
  const scale = useTransform(scrollYProgress, [0, 0.4], [1, 1]);
  const opacity = 1; // 始终保持全清透明度
  const y = parallax ? useTransform(scrollYProgress, [0, 1], [-20, 20]) : 0;

  const isVideo = src.toLowerCase().endsWith('.mp4');

  return (
    <motion.div 
      ref={containerRef}
      style={{ opacity, scale }}
      className={`relative overflow-hidden group/decode bg-transparent ${className}`}
    >
      {isVideo ? (
        <motion.video
          src={src}
          autoPlay
          muted
          loop
          playsInline
          style={{ y }}
          className="w-full h-full object-cover transition-all duration-1000"
        />
      ) : (
        <motion.img
          src={src}
          alt={alt}
          style={{ y }}
          className="w-full h-full object-cover transition-all duration-1000"
        />
      )}
      {/* 去掉扫光装饰，保持纯净 */}
    </motion.div>
  );
};

interface BlogEditorialLayoutProps {
  post: BlogPost;
  onClose: () => void;
  language?: Language;
}

const BlogEditorialLayout: React.FC<BlogEditorialLayoutProps> = ({ post, onClose, language = 'EN' }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ container: containerRef });
  
  const springProgress = useSpring(scrollYProgress, { stiffness: 100, damping: 30 });
  
  const navBgOpacity = useTransform(scrollYProgress, [0, 0.05], [0, 0.98]);
  const headerScale = useTransform(scrollYProgress, [0, 0.3], [1, 0.98]);

  const isEn = language === 'EN';

  const formatText = (text: string) => {
    const segments = text.split(/(犀利洞察：)/g);
    
    return segments.map((segment, i) => {
      if (segment === '犀利洞察：') {
        return (
          <span key={i} className="flex items-center gap-4 text-primary font-black tracking-[0.4em] uppercase my-8 text-[11px] border-l border-primary/20 pl-6">
            <MousePointer2 className="w-3.5 h-3.5" />
            {segment}
          </span>
        );
      }
      
      const boldParts = segment.split(/(\*\*.*?\*\*)/g);
      return boldParts.map((part, j) => {
        if (part.startsWith('**') && part.endsWith('**')) {
          return (
            <strong key={`${i}-${j}`} className="font-bold text-white transition-colors">
              {part.slice(2, -2)}
            </strong>
          );
        }
        return part;
      });
    });
  };

  const titleParts = post.title.split(/[：:]/);
  const titlePrefix = titleParts[0];
  const titleSuffix = titleParts.slice(1).join(':');

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[3000] bg-[#050505] overflow-y-auto no-scrollbar selection:bg-primary/40 isolate"
      ref={containerRef}
    >
      <GrainOverlay />
      
      <motion.div 
        style={{ scaleX: springProgress }}
        className="fixed top-0 left-0 right-0 h-[2px] bg-primary z-[3200] origin-left pointer-events-none"
      />

      <motion.nav 
        style={{ 
          backgroundColor: `rgba(10, 10, 10, ${navBgOpacity.get()})`, 
          borderBottomColor: `rgba(255, 255, 255, ${navBgOpacity.get() * 0.05})`,
          backdropFilter: 'blur(50px)'
        }}
        className="fixed top-0 left-0 right-0 h-16 md:h-20 z-[3100] border-b border-transparent flex items-center px-6 md:px-12 transition-all duration-700 isolate"
      >
        <div className="w-full max-w-[1440px] mx-auto flex justify-between items-center pointer-events-auto">
          <button 
            onClick={onClose} 
            className="flex items-center justify-center min-w-[44px] gap-3 px-5 py-2 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 text-white font-black uppercase text-[9px] md:text-[11px] tracking-[0.2em] transition-all group shrink-0 relative z-20 isolate"
          >
            <ChevronLeft className="w-3.5 h-3.5 group-hover:-translate-x-1 transition-transform" />
            <span>BACK</span>
          </button>
          
          <div className="flex-1 flex items-center justify-end gap-10 min-w-0">
            <span className={`hidden lg:block text-[9px] font-black text-white/20 uppercase ${isEn ? 'tracking-[0.15em]' : 'tracking-[1em]'} max-w-md truncate`}>{post.title}</span>
            <button 
              onClick={onClose} 
              className="w-10 h-10 rounded-full border border-white/10 flex items-center justify-center hover:bg-white/5 transition-colors shrink-0"
            >
              <X className="w-4 h-4 text-white/40" />
            </button>
          </div>
        </div>
      </motion.nav>

      {/* --- HERO SECTION --- */}
      <section className="min-h-screen relative flex flex-col justify-end items-center px-6 pb-16 md:pb-24 overflow-hidden">
        <motion.div 
          style={{ scale: headerScale }} 
          className="relative z-10 w-full max-w-5xl text-center space-y-6 md:space-y-8"
        >
          {/* Main Title Block - 维持缩小的规格化字号 */}
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
            className={`font-sans font-bold text-white tracking-tight leading-[1.2] uppercase
              ${isEn 
                ? 'text-2xl md:text-4xl' 
                : 'text-3xl md:text-5xl'
              }
            `}
          >
            {titlePrefix}{titleSuffix ? (<><br/><span className="text-primary-gradient drop-shadow-[0_0_20px_rgba(134,87,11,0.3)]">{titleSuffix}</span></>) : ''}
          </motion.h1>

          {/* Minimalist Metadata */}
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
            className="flex justify-center items-center gap-8 md:gap-12 text-[10px] md:text-[11px] font-black text-white/30 uppercase tracking-[0.4em]"
          >
            <span>{post.readTime}</span>
            <span>{post.date}</span>
          </motion.div>
        </motion.div>

        {/* Background Image - 确保 Hero 背景图全清且明亮 */}
        <div className="absolute inset-0 z-0">
          <motion.img 
            style={{ y: useTransform(scrollYProgress, [0, 0.5], [0, 80]) }}
            src={post.imageUrl} 
            className="w-full h-full object-cover scale-100 opacity-100" 
          />
          {/* 极轻微压暗，仅为保证文字阅读，且不产生灰度感 */}
          <div className="absolute inset-x-0 bottom-0 h-[50vh] bg-transparent backdrop-blur-[30px]" style={{ WebkitMaskImage: 'linear-gradient(to top, black 0%, transparent 100%)', maskImage: 'linear-gradient(to top, black 0%, transparent 100%)' }} />
        </div>
      </section>

      {/* --- CONTENT SECTIONS --- */}
      <div className="max-w-[1440px] mx-auto px-6 md:px-24 space-y-40 pb-60">
        <section className="flex justify-center py-20">
          <div className="w-full max-w-4xl border-l border-primary/20 pl-10 md:pl-20">
            <p className="text-lg md:text-[clamp(1.1rem,1.5vw,1.6rem)] text-zinc-300 font-light leading-relaxed tracking-tight text-balance">
              {formatText(post.summary)}
            </p>
          </div>
        </section>

        {post.sections.map((section, idx) => {
          const isSpecial = idx === 1 || section.subtitle.includes('智力溢价') || section.subtitle.includes('Intellectual Premium');
          
          return (
            <section key={idx} className="space-y-20">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
                <div className="lg:col-span-5 lg:sticky lg:top-40 h-fit">
                   <h2 className="text-2xl md:text-[clamp(1.5rem,2.5vw,3rem)] font-sans font-bold text-white uppercase tracking-tighter leading-[1.2] mb-8">
                     {section.subtitle}
                   </h2>
                </div>

                <div className="lg:col-span-7 lg:col-start-6">
                  <div className="text-base md:text-lg text-zinc-400 font-light leading-relaxed whitespace-pre-wrap">
                    {formatText(section.text)}
                  </div>
                </div>
              </div>

              {/* 正文图片：去掉所有边框、阴影和背景，确保完全透明底且清晰 */}
              {section.isGrid && section.images && section.images.length === 2 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-12 md:gap-24 my-24 items-start">
                   <DecodingImage src={section.images[0]} className="aspect-[3/4]" />
                   <motion.div initial={{ y: 0 }} whileInView={{ y: 60 }} transition={{ duration: 1.2, ease: "easeOut" }} className="md:mt-24">
                     <DecodingImage src={section.images[1]} className="aspect-[3/4]" />
                   </motion.div>
                </div>
              ) : section.image && !section.isGrid ? (
                <div className={`w-full flex ${isSpecial ? 'justify-center my-32' : 'justify-end'}`}>
                  <DecodingImage 
                    src={section.image} 
                    className={`${isSpecial ? 'w-full max-w-5xl aspect-[21/9]' : 'w-full lg:w-4/5 aspect-video'}`} 
                    parallax={isSpecial}
                  />
                </div>
              ) : section.isGrid && section.images && section.images.length > 2 ? (
                <div className="grid grid-cols-1 md:grid-cols-12 gap-6 my-20">
                  <div className="md:col-span-8">
                     <DecodingImage src={section.images[0]} className="aspect-video" />
                  </div>
                  <div className="md:col-span-4 flex flex-col gap-6">
                     <DecodingImage src={section.images[1]} className="flex-1 aspect-square md:aspect-auto" />
                     <DecodingImage src={section.images[2]} className="flex-1 aspect-square md:aspect-auto" />
                  </div>
                </div>
              ) : null}
            </section>
          );
        })}
        
        <section className="py-60 border-t border-white/5 text-center relative overflow-hidden">
           <motion.div 
             initial={{ opacity: 0, y: 20 }}
             whileInView={{ opacity: 1, y: 0 }}
             className="max-w-5xl mx-auto px-6"
           >
             <h3 className={`font-sans font-bold text-white mb-16 tracking-tighter leading-[1.2] text-balance
                ${isEn 
                  ? 'text-xl md:text-3xl' 
                  : 'text-2xl md:text-4xl'
                }
             `}>
                {isEn 
                  ? <>In a sea of algorithms,<br/><span className="whitespace-nowrap">carving out a brand's</span> <span className="text-primary-gradient whitespace-nowrap">territory of meaning</span>.</>
                  : <>在算法的海洋里，<br/><span className="whitespace-nowrap">圈出属于品牌的</span><span className="text-primary-gradient whitespace-nowrap">意义领地</span>。</>
                }
             </h3>
             <button 
               onClick={onClose}
               className="px-16 py-6 rounded-full bg-white text-black font-black uppercase text-[11px] tracking-[0.4em] hover:bg-primary hover:text-white transition-all duration-500 shadow-xl"
             >
               BACK
             </button>
           </motion.div>
        </section>
      </div>

      <style>{`
        .no-scrollbar::-webkit-scrollbar { display: none; }
        .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
        .text-balance { text-wrap: balance; }
      `}</style>
    </motion.div>
  );
};

export default BlogEditorialLayout;