import React, { useState, useRef, useEffect } from 'react';
import { motion as m, AnimatePresence } from 'framer-motion';
import { MessageSquare, Send, X, Loader2, Sparkles } from 'lucide-react';
import { ChatMessage } from '../types';
import { chatWithResume } from '../services/geminiService';

// Cast motion to any to bypass environment-specific type definition issues
const motion = m as any;

interface AIChatProps {
  context: string;
  triggerProactive?: boolean;
}

const AIChat: React.FC<AIChatProps> = ({ context, triggerProactive }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isProactiveVisible, setIsProactiveVisible] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setMessages([
      { id: '1', role: 'model', text: languageIsEn() ? "Professional Portfolio Assistant Active. Inquire for strategic details." : "专业作品集助手已激活。您可以询问关于项目背景、策略规划或技术细节的信息。" }
    ]);
  }, [context]);

  useEffect(() => {
    if (triggerProactive && !isOpen && !isProactiveVisible) {
      setIsProactiveVisible(true);
      const timer = setTimeout(() => setIsProactiveVisible(false), 8000);
      return () => clearTimeout(timer);
    }
  }, [triggerProactive]);

  function languageIsEn() { return context.toLowerCase().includes('janice'); }

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isOpen]);

  const handleSend = async () => {
    if (!inputValue.trim() || isLoading) return;

    const userMsg: ChatMessage = { id: Date.now().toString(), role: 'user', text: inputValue };
    setMessages(prev => [...prev, userMsg]);
    setInputValue('');
    setIsLoading(true);

    try {
      const responseText = await chatWithResume(userMsg.text, context);
      const botMsg: ChatMessage = { id: (Date.now() + 1).toString(), role: 'model', text: responseText };
      setMessages(prev => [...prev, botMsg]);
    } catch (err) {
      setMessages(prev => [...prev, { id: Date.now().toString(), role: 'model', text: "Service link error." }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <AnimatePresence>
        {!isOpen && (
          <div className="fixed bottom-8 right-8 z-[1050] flex flex-col items-end gap-4">
            <AnimatePresence>
              {isProactiveVisible && (
                <motion.div
                  initial={{ opacity: 0, x: 20, scale: 0.9 }}
                  animate={{ opacity: 1, x: 0, scale: 1 }}
                  exit={{ opacity: 0, x: 20, scale: 0.9 }}
                  className="bg-zinc-950 border border-primary/40 p-5 rounded-2xl shadow-3xl max-w-[260px] relative mb-2"
                >
                  <div className="flex items-center gap-2 mb-3">
                    <Sparkles className="w-4 h-4 text-primary" />
                    <span className="text-[12px] font-black text-primary uppercase tracking-widest">STRATEGIC AGENT</span>
                  </div>
                  <p className="text-[13px] text-zinc-200 font-medium leading-relaxed">
                    {languageIsEn() ? "Need a deep dive into my AIGC workflow?" : "需要我为您深度拆解这套 AIGC 工作流的落地逻辑吗？"}
                  </p>
                  <div className="absolute bottom-[-6px] right-6 w-3 h-3 bg-zinc-950 border-r border-b border-primary/40 rotate-45" />
                </motion.div>
              )}
            </AnimatePresence>

            <motion.button
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0 }}
              whileHover={{ scale: 1.05 }}
              onClick={() => setIsOpen(true)}
              className="w-16 h-16 rounded-full bg-zinc-900 flex items-center justify-center shadow-2xl border border-white/10 group overflow-hidden"
            >
              <div className="absolute inset-0 bg-primary-gradient opacity-0 group-hover:opacity-10 transition-opacity" />
              <MessageSquare className="text-gray-400 group-hover:text-white w-6 h-6 transition-colors" />
              <div className="absolute top-4 right-4 w-2 h-2 rounded-full bg-primary animate-pulse shadow-[0_0_10px_rgba(134, 87, 11, 0.8)]" />
            </motion.button>
          </div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            className="fixed bottom-8 right-8 z-[1100] w-[90vw] md:w-96 h-[550px] bg-zinc-950 border border-white/10 rounded-3xl shadow-3xl flex flex-col overflow-hidden backdrop-blur-2xl"
          >
            <div className="p-6 border-b border-white/5 bg-white/5 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-2.5 h-2.5 rounded-full bg-primary" />
                <span className="text-[13px] font-black text-zinc-400 uppercase tracking-widest">AI Concierge</span>
              </div>
              <button onClick={() => setIsOpen(false)} className="text-gray-500 hover:text-white transition-colors">
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-6 space-y-6">
              {messages.map((msg) => (
                <div
                  key={msg.id}
                  className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-[85%] p-4.5 rounded-2xl text-[14px] leading-relaxed ${
                      msg.role === 'user'
                        ? 'bg-white text-black font-bold'
                        : 'bg-zinc-900 text-zinc-300 border border-white/5'
                    }`}
                  >
                    {msg.text}
                  </div>
                </div>
              ))}
              {isLoading && (
                <div className="flex justify-start">
                  <div className="bg-zinc-900 p-4.5 rounded-2xl border border-white/5 flex gap-2 items-center">
                     <Loader2 className="w-4 h-4 text-zinc-600 animate-spin" />
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            <div className="p-6 border-t border-white/5 bg-black/40">
              <div className="flex gap-3">
                <input
                  type="text"
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                  placeholder="Ask a question..."
                  className="flex-1 bg-white/5 border border-white/5 rounded-xl px-4 py-3.5 text-[14px] text-white focus:outline-none focus:border-white/20 transition-colors"
                />
                <button
                  onClick={handleSend}
                  disabled={isLoading || !inputValue.trim()}
                  className="bg-white hover:bg-zinc-200 disabled:opacity-20 text-black p-3.5 rounded-xl transition-all"
                >
                  <Send className="w-4 h-4" />
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

export default AIChat;