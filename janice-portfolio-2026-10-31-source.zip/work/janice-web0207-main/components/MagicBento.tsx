import React, { useRef, useEffect } from 'react';
import { gsap } from 'gsap';
import { motion } from 'framer-motion';
import './MagicBento.css';

interface MagicBentoProps {
  items: Array<{ title: string; desc: string; label?: string }>;
  textAutoHide?: boolean;
  enableStars?: boolean;
  enableSpotlight?: boolean;
  enableBorderGlow?: boolean;
  disableAnimations?: boolean;
  spotlightRadius?: number;
  particleCount?: number;
  enableTilt?: boolean;
  glowColor?: string; // Expects "r, g, b"
  clickEffect?: boolean;
  enableMagnetism?: boolean;
}

const DEFAULT_SPOTLIGHT_RADIUS = 150; // Updated to match request (300px diameter)
const DEFAULT_GLOW_COLOR = '255, 255, 255'; 

const updateCardGlowProperties = (card: HTMLElement, mouseX: number, mouseY: number, glow: number, radius: number) => {
  const rect = card.getBoundingClientRect();
  const relativeX = ((mouseX - rect.left) / rect.width) * 100;
  const relativeY = ((mouseY - rect.top) / rect.height) * 100;

  card.style.setProperty('--glow-x', `${relativeX}%`);
  card.style.setProperty('--glow-y', `${relativeY}%`);
  card.style.setProperty('--glow-intensity', glow.toString());
  card.style.setProperty('--glow-radius', `${radius}px`);
};

// 仅保留数据类关键词高亮
const KEYWORDS = [
  '10 倍', '10倍', '35%', '80%', '15%', '2 个月', '2个月', '50,000+', 
  '000980', '600696', '1.2M+', '9年+', '9+ years', '5 人的团队', '20 人的战力', 'ROI', 'GMV'
];

const highlightKeywords = (text: string) => {
  if (!text) return text;
  // 匹配数字、百分比、倍数等数据的正则
  const dataRegex = /(\d+(?:\.\d+)?%|\d+\s*倍|\d+,\d+\+|\d+\.\d+M\+|\d+年\+|\d+\+ years|\d+\s*人)/g;
  
  const parts = text.split(dataRegex);
  return parts.map((part, i) => {
    const isData = dataRegex.test(part) || KEYWORDS.some(k => k.toLowerCase() === part.toLowerCase());
    return isData ? <span key={i} className="text-white font-bold">{part}</span> : part;
  });
};

const renderRichText = (text: string) => {
  if (!text) return text;
  // 移除所有 ** 标记，交由 highlightKeywords 处理数据加粗
  const cleanText = text.replace(/\*\*/g, '');
  return highlightKeywords(cleanText);
};

const MagicBento: React.FC<MagicBentoProps> = ({
  items,
  textAutoHide = true,
  enableStars = false,
  enableSpotlight = true,
  enableBorderGlow = true,
  disableAnimations = false,
  spotlightRadius = DEFAULT_SPOTLIGHT_RADIUS,
  enableTilt = true,
  glowColor = DEFAULT_GLOW_COLOR,
  enableMagnetism = true
}) => {
  const gridRef = useRef<HTMLDivElement>(null);
  const cardRefs = useRef<(HTMLDivElement | null)[]>([]);

  useEffect(() => {
    if (disableAnimations) return;

    cardRefs.current.forEach((card) => {
      if (!card) return;

      const handleMouseEnter = () => {
        // iOS 典型的弹性曲线，带阻尼
        gsap.to(card, {
          scale: 1.05,
          duration: 1.2,
          ease: "elastic.out(1.2, 0.5)",
        });
      };

      const handleMouseLeave = () => {
        gsap.to(card, {
          scale: 1,
          x: 0,
          y: 0,
          rotateX: 0,
          rotateY: 0,
          duration: 1.5,
          ease: "elastic.out(1, 0.4)",
        });
        card.style.setProperty('--glow-intensity', '0');
      };

      const handleMouseMove = (e: MouseEvent) => {
        const rect = card.getBoundingClientRect();
        const centerX = rect.left + rect.width / 2;
        const centerY = rect.top + rect.height / 2;
        const distanceX = e.clientX - centerX;
        const distanceY = e.clientY - centerY;

        updateCardGlowProperties(card, e.clientX, e.clientY, 1, spotlightRadius);

        if (enableTilt) {
          // 极致平滑的倾斜
          const rotateX = (distanceY / (rect.height / 2)) * -5;
          const rotateY = (distanceX / (rect.width / 2)) * 5;
          gsap.to(card, {
            rotateX,
            rotateY,
            duration: 0.8,
            ease: "power2.out"
          });
        }

        if (enableMagnetism) {
          // 磁吸效果增加粘滞感
          gsap.to(card, {
            x: distanceX * 0.05,
            y: distanceY * 0.05,
            duration: 1,
            ease: "power3.out"
          });
        }
      };

      card.addEventListener('mouseenter', handleMouseEnter);
      card.addEventListener('mouseleave', handleMouseLeave);
      card.addEventListener('mousemove', handleMouseMove);

      return () => {
        card.removeEventListener('mouseenter', handleMouseEnter);
        card.removeEventListener('mouseleave', handleMouseLeave);
        card.removeEventListener('mousemove', handleMouseMove);
      };
    });
  }, [disableAnimations, enableTilt, enableMagnetism, spotlightRadius]);

  return (
    <motion.div 
      className="card-grid bento-section" 
      ref={gridRef}
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true }}
      variants={{
        visible: {
          transition: {
            staggerChildren: 0.1
          }
        }
      }}
    >
      {items.map((card, index) => (
        <motion.div
          key={index}
          ref={(el) => { cardRefs.current[index] = el; }}
          className={`magic-bento-card ${textAutoHide ? 'magic-bento-card--text-autohide' : ''}`}
          style={{ '--glow-color': glowColor } as any}
          variants={{
            hidden: { opacity: 0, scale: 0.95 },
            visible: { opacity: 1, scale: 1, transition: { type: "spring", bounce: 0.4, duration: 0.8 } }
          }}
        >
          <div className="magic-bento-card__border-beam" />
          <div className="magic-bento-card__content">
            <h2 className="magic-bento-card__title">{card.title}</h2>
            <p className="magic-bento-card__description">{renderRichText(card.desc)}</p>
          </div>
        </motion.div>
      ))}
    </motion.div>
  );
};

export default MagicBento;