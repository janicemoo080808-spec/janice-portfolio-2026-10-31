import React, { useState, useRef, useEffect } from 'react';
import { motion as m, useScroll, useTransform, AnimatePresence, useSpring } from 'framer-motion';
import { 
  ChevronLeft, Film, ArrowUp, Monitor, Cpu, Layers, Rocket, Globe, Minus
} from 'lucide-react';
import { Project } from '../types';

// Cast motion to any to bypass environment-specific type definition issues
const motion = m as any;

const ICON_MAP: Record<string, any> = {
  Monitor, Cpu, Layers, Rocket, Globe
};

const Clapperboard: React.FC<{ act: string }> = ({ act }) => (
  <motion.div 
    initial={{ x: -20, opacity: 0 }}
    whileInView={{ x: 0, opacity: 1 }}
    viewport={{ once: true }}
    className="relative mb-6"
  >
    <div className="flex mb-1">
      {[1, 2, 3, 4, 5, 6].map((i) => (
        <div key={i} className={`h-2 w-6 ${i % 2 === 0 ? 'bg-primary' : 'bg-zinc-800'} skew-x-[20deg] first:ml-0 -ml-1`} />
      ))}
    </div>
    <div className="bg-white/5 border border-white/10 px-3 py-1 inline-flex items-center gap-2 rounded-sm backdrop-blur-md">
      <span className="text-[10px] font-black text-primary tracking-[0.4em] uppercase">{act}</span>
    </div>
  </motion.div>
);

const AutomotiveLayout: React.FC<{ project: Project; onClose: () => void }> = ({ project, onClose }) => {
  const [activeTabId, setActiveTabId] = useState<string>('section-0');
  const containerRef = useRef<HTMLDivElement>(null);

  const { scrollYProgress } = useScroll({ container: containerRef });
  const springProgress = useSpring(scrollYProgress, { stiffness: 100, damping: 30 });
  const navBgOpacity = useTransform(scrollYProgress, [0, 0.05], [0, 0.98]);

  const displaySections = project.sections.slice(1);
  const isEn = !/[\u4e00-\u9fa5]/.test(project.title);

  useEffect(() => {
    const options = {
      root: containerRef.current,
      rootMargin: '-20% 0px -60% 0px',
      threshold: 0
    };

    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          setActiveTabId(entry.target.id);
        }
      });
    }, options);

    displaySections.forEach((_, i) => {
      const el = document.getElementById(`section-${i}`);
      if (el) observer.observe(el);
    });

    return () => observer.disconnect();
  }, [displaySections]);

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el && containerRef.current) {
      const offset = 160;
      containerRef.current.scrollTo({
        top: el.offsetTop - offset,
        behavior: 'smooth'
      });
    }
  };

  const parseCampaignAct = (point: string) => {
    const lines = point.split('\n');
    const headerLine = lines[0] || "";
    const actMatch = headerLine.match(/(.*幕)/);
    const act = actMatch ? actMatch[1] : "CHAPTER";
    
    const restHeader = headerLine.replace(/.*幕：/, '');
    const [title, themePart] = restHeader.split('｜');
    const theme = themePart?.replace('主题：', '').trim();

    const narrative = lines.slice(1).filter(l => l.trim() && !l.trim().startsWith('•'));
    const bullets = lines.filter(l => l.trim().startsWith('•'));

    return { act, title: title.trim(), theme, narrative, bullets };
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }} 
      animate={{ opacity: 1 }} 
      exit={{ opacity: 0 }} 
      className="fixed inset-0 z-[3000] bg-black overflow-hidden transform-gpu translate-z-0 isolate"
    >
      <motion.div 
        style={{ scaleX: springProgress }}
        className="fixed top-16 md:top-20 left-0 right-0 h-[2px] bg-primary z-[5200] origin-left pointer-events-none"
      />

      <motion.nav 
        style={{ 
          backgroundColor: `rgba(10, 10, 10, ${navBgOpacity.get()})`, 
          borderBottomColor: `rgba(255, 255, 255, ${navBgOpacity.get() * 0.05})`,
          backdropFilter: 'blur(50px)'
        }}
        className="fixed top-16 md:top-20 left-0 right-0 h-16 md:h-20 z-[5100] border-b border-transparent flex items-center px-6 md:px-12 transition-all duration-700 isolate"
      >
        <div className="w-full max-w-[1550px] mx-auto flex items-center pointer-events-auto">
          <button 
            onClick={onClose} 
            className="flex items-center justify-center min-w-[44px] gap-3 px-5 py-2 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 text-white font-black uppercase font-sans text-[10px] tracking-[0.2em] transition-all group shrink-0 relative z-20 isolate"
          >
            <ChevronLeft className="w-5 h-5 md:w-3.5 md:h-3.5 group-hover:-translate-x-1 transition-transform" />
            <span className="hidden lg:block">BACK</span>
          </button>
          
          <div className="w-[1px] h-6 bg-white/10 mx-6 md:mx-8 shrink-0" />
          
          <div className={`flex-1 flex items-center gap-8 md:gap-12 font-sans font-black uppercase text-[10px] tracking-[0.2em] overflow-x-auto no-scrollbar whitespace-nowrap min-w-0`}>
            {displaySections.map((section, idx) => {
              const sid = `section-${idx}`;
              return (
                <button 
                  key={idx} 
                  onClick={() => scrollToSection(sid)} 
                  className={`transition-all hover:text-primary shrink-0 ${activeTabId === sid ? 'text-primary' : 'text-zinc-600'}`}
                >
                  0{idx + 1} · {section.label}
                </button>
              );
            })}
          </div>
        </div>
      </motion.nav>

      <div 
        ref={containerRef}
        className="w-full h-full overflow-y-auto no-scrollbar scroll-smooth scroll-pt-[128px] md:scroll-pt-[160px]"
      >
        <section className="min-h-[60vh] flex flex-col justify-end pb-16 px-6 md:px-24 relative overflow-hidden bg-black">
          <div className="absolute inset-0 z-0">
            <img src={project.imageUrl} className="w-full h-full object-cover opacity-45 scale-105" alt="" />
            <div className="absolute inset-x-0 bottom-0 h-[50vh] bg-transparent backdrop-blur-[30px]" style={{ WebkitMaskImage: 'linear-gradient(to top, black 0%, transparent 100%)', maskImage: 'linear-gradient(to top, black 0%, transparent 100%)' }} />
          </div>
          <div className="relative z-10 max-w-[1550px] mx-auto w-full flex flex-col items-start">
            <motion.h1 
              initial={{ opacity: 0, y: 15 }} 
              animate={{ opacity: 1, y: 0 }} 
              transition={{ delay: 0.1, duration: 1.5, ease: [0.16, 1, 0.3, 1] }} 
              className="text-3xl md:text-[3.2vw] font-sans font-bold leading-[1.1] tracking-tight text-white uppercase drop-shadow-2xl"
            >
              {project.title}
            </motion.h1>
          </div>
        </section>

        <div className="space-y-24 md:space-y-40 py-20 md:py-40">
          {displaySections.map((section, idx) => {
            const sectionId = `section-${idx}`;
            const isCampaign = section.title === "三幕式传播战役规划" || section.title === "Three-Act Campaign Strategy Planning";

            return (
              <section key={idx} id={sectionId} className="px-6 md:px-24 max-w-[1550px] mx-auto w-full group scroll-mt-32">
                <div className="flex flex-col lg:flex-row gap-12 lg:gap-20">
                  <div className="lg:w-1/3 lg:sticky lg:top-40 lg:h-fit">
                    <div className="space-y-8 md:space-y-10">
                      <div>
                        <span className="text-[9px] md:text-[10px] font-black text-primary tracking-[1em] uppercase mb-4 block">CHAPTER 0{idx + 1}</span>
                        <div className="flex items-center gap-4 mb-6">
                          <h2 className="text-xl md:text-[2vw] font-sans font-bold text-white tracking-tighter uppercase leading-tight">{section.title}</h2>
                        </div>
                        <p className="text-[13px] md:text-lg text-zinc-400 font-light leading-relaxed whitespace-pre-line">{section.description}</p>
                      </div>

                      {isCampaign && section.points && (
                        <div className="space-y-16 md:space-y-24 mt-12 md:mt-20">
                          {section.points.map((pt, pIdx) => {
                            const data = parseCampaignAct(pt);
                            return (
                              <motion.div 
                                key={pIdx}
                                initial={{ opacity: 0.3 }}
                                whileInView={{ opacity: 1 }}
                                viewport={{ margin: "-20% 0px -60% 0px" }}
                                className="border-l border-white/10 pl-8 space-y-6"
                              >
                                <Clapperboard act={data.act} />
                                <h3 className="text-lg md:text-xl font-sans font-bold text-white uppercase tracking-tight">{data.title}</h3>
                                <p className="text-[10px] font-black text-primary/80 uppercase tracking-widest bg-primary/5 px-2 py-1 rounded w-fit">Theme: {data.theme}</p>
                                <div className="space-y-4 text-zinc-400 text-[13px] md:text-[15px] align-baseline leading-relaxed">
                                  {data.narrative.map((n, i) => <p key={i}>{n}</p>)}
                                  <div className="space-y-2 pt-4">
                                    {data.bullets.map((b, i) => (
                                      <div key={i} className="flex gap-3">
                                        <Film className="w-3.5 h-3.5 text-primary shrink-0 mt-0.5" />
                                        <span className="text-zinc-500 hover:text-zinc-300 transition-colors">{b.replace('• ', '')}</span>
                                      </div>
                                    ))}
                                  </div>
                                </div>
                              </motion.div>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="lg:w-2/3 space-y-12">
                    {section.images && section.images.length > 0 && (
                      <div className="grid grid-cols-1 gap-12">
                        {section.images.map((img, iIdx) => (
                          <motion.div 
                            key={iIdx}
                            whileHover={{ scale: 1.015 }}
                            className="relative overflow-hidden rounded-xl border border-white/5 transition-all duration-500 aspect-video lg:aspect-auto bg-transparent"
                          >
                            <img src={img} className="w-full h-auto object-cover block" alt="" />
                          </motion.div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </section>
            );
          })}
        </div>

        <section className="px-6 py-40 border-t border-white/5 text-center">
          <h3 className={`font-sans font-bold text-white mb-16 tracking-tight text-center mx-auto leading-relaxed ${isEn ? 'text-[clamp(1.25rem,5vw,2rem)]' : 'text-[clamp(1.5rem,6vw,2.5rem)]'}`}>
            {isEn ? (
              <>Defining <span className="text-primary">industrial aesthetics</span> <br/><span className="text-primary">through digital narrative.</span></>
            ) : (
              <>在数字叙事中，<br/><span className="text-primary">定义工业美学的边界</span>。</>
            )}
          </h3>
          <button 
            onClick={onClose}
            className="px-16 py-6 rounded-full bg-white text-black font-black uppercase text-[12px] tracking-[0.4em] hover:bg-primary hover:text-white transition-all shadow-4xl duration-500"
          >
            BACK TO PORTFOLIO
          </button>
        </section>
      </div>
    </motion.div>
  );
};

export default AutomotiveLayout;