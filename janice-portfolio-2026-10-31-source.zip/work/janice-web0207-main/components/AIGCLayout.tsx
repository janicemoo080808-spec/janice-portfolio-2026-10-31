
import React, { useState, useRef, useEffect } from 'react';
import { motion as m, useScroll, useTransform, AnimatePresence, useSpring } from 'framer-motion';
import { 
  ChevronLeft, ArrowRight, Quote, TrendingUp, Timer, MousePointer2, 
  Cloud, Lock, Cpu, Zap, Binary, ShieldAlert, Activity, Command,
  ArrowDownCircle, Layers, Fingerprint, Code, Layout, Monitor, Rocket, BarChart3, Minus,
  Info, Maximize2, Share2, CornerDownRight, Terminal as TerminalIcon, ShieldCheck,
  Target, Eye, MessageSquare, Wrench, ArrowUp
} from 'lucide-react';
import { Project } from '../types';
import CircularGallery from './CircularGallery';

// Cast motion to any to bypass environment-specific type definition issues
const motion = m as any;

const GrainOverlay = () => (
  <div className="fixed inset-0 pointer-events-none z-[2000] opacity-[0.03] mix-blend-overlay">
    <svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
      <filter id="noiseFilter">
        <feTurbulence type="fractalNoise" baseFrequency="0.65" numOctaves="3" stitchTiles="stitch" />
      </filter>
      <rect width="100%" height="100%" filter="url(#noiseFilter)" />
    </svg>
  </div>
);

const CaseTable: React.FC<{ content: string }> = ({ content }) => {
  const rows = content.split('\n').filter(l => l.includes('|'));
  if (rows.length === 0) return null;

  return (
    <div className="my-6 md:my-10 overflow-x-auto border-t border-white/5 scroll-px-4 no-scrollbar">
      <table className="w-full text-left border-collapse min-w-[650px] md:min-w-full">
        <thead>
          <tr className="border-b border-white/10">
            {rows[0].split('|').map((h, i) => (
              <th key={i} className="py-4 md:py-6 px-4 text-[9px] md:text-[10px] font-black text-zinc-500 uppercase tracking-[0.4em]">
                {h.trim()}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.slice(1).map((row, i) => (
            <tr key={i} className="border-b border-white/5 last:border-0 hover:bg-white/[0.01] transition-colors group">
              {row.split('|').map((cell, j) => (
                <td key={j} className={`py-4 md:py-6 px-4 text-[11px] md:text-[13px] ${j === 0 ? 'text-zinc-500' : j === 2 ? 'text-primary font-bold' : 'text-zinc-300'} font-light`}>
                  {cell.trim()}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

const Terminal: React.FC<{ code: string; title?: string }> = ({ code, title = "AIGC // TERMINAL" }) => (
  <div className="my-10 rounded-[1rem] bg-zinc-950/60 border border-white/5 overflow-hidden font-mono text-[11px] md:text-[13px] leading-relaxed group backdrop-blur-3xl w-full shadow-2xl">
    <div className="flex items-center justify-between px-6 py-3.5 border-b border-white/5 bg-white/[0.02]">
      <div className="flex gap-1.5">
        <div className="w-2 h-2 rounded-full bg-zinc-800" />
        <div className="w-2 h-2 rounded-full bg-zinc-800" />
        <div className="w-2 h-2 rounded-full bg-zinc-800" />
      </div>
      <span className="text-[9px] font-black text-zinc-500 uppercase tracking-[0.4em]">{title}</span>
    </div>
    <div className="p-6 md:p-8 text-zinc-400 whitespace-pre-wrap relative overflow-hidden overflow-x-auto no-scrollbar">
      <div className="absolute top-0 right-0 p-8 opacity-[0.03]">
        <Binary className="w-24 h-24 md:w-32 md:h-32 text-white" />
      </div>
      <div className="relative z-10 min-w-[300px]">{code}</div>
    </div>
  </div>
);

const ImageWithOverlay: React.FC<{ src: string; caption: string; type?: 'image' | 'video'; isTransparent?: boolean; poster?: string }> = ({ src, caption, type = 'image', isTransparent, poster }) => (
  <motion.div 
    initial={{ opacity: 0, y: 20 }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true }}
    className={`relative group w-full overflow-hidden rounded-2xl shadow-xl transition-all duration-700`}
  >
    {type === 'image' ? (
      <img src={src} className="w-full h-auto max-h-[55vh] md:max-h-[70vh] lg:max-h-none object-contain transition-transform duration-1000 group-hover:scale-[1.01]" alt="" decoding="async" referrerPolicy="no-referrer" />
    ) : (
      <video src={src} autoPlay muted loop playsInline referrerPolicy="no-referrer" className="w-full h-auto max-h-[55vh] md:max-h-[70vh] lg:max-h-none object-contain" poster={poster || src.replace('.mp4', '.webp')} />
    )}
    
    {caption && (
      <div className="absolute bottom-0 left-0 right-0 p-4 md:p-6 pt-16 bg-gradient-to-t from-black via-black/40 to-transparent flex items-end">
        <div className="flex items-center gap-4">
          <div className="w-[1px] h-5 md:h-6 bg-primary/60 rounded-full" />
          <div className="space-y-0.5">
            <p className="text-[9px] md:text-[11px] text-zinc-200 font-mono uppercase tracking-[0.2em] leading-[1.8]">{caption}</p>
          </div>
        </div>
      </div>
    )}
  </motion.div>
);

const StrategyRow: React.FC<{ label: string; title: string; children: React.ReactNode; compact?: boolean }> = ({ label, title, children, compact }) => (
  <div className={`grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-20 items-start ${compact ? 'py-10' : 'py-12 md:py-20 border-t border-white/5'}`}>
    <div className="lg:col-span-4 space-y-4">
      <div className="flex items-center gap-3">
        <div className="w-6 h-[1px] bg-primary/40" />
        <span className="text-[9px] font-black text-primary font-light opacity-90 tracking-[0.6em] uppercase">{label}</span>
      </div>
      <h4 className="text-xl md:text-2xl font-sans font-bold text-white tracking-tight uppercase leading-none">{title}</h4>
    </div>
    <div className="lg:col-span-8">
      <div className="text-[13px] md:text-lg text-zinc-400 font-light leading-relaxed">
        {children}
      </div>
    </div>
  </div>
);

const SiliconStrategyViewCN: React.FC = () => {
  return (
    <div className="w-full space-y-16 md:space-y-24">
      <section className="max-w-none space-y-10 md:space-y-16 pt-8 md:pt-16">
        <div className="space-y-6">
          <div className="flex items-center gap-4">
            <span className="text-[10px] font-black text-primary tracking-[0.8em] uppercase">CASE 01</span>
            <div className="h-[1px] flex-1 bg-white/5" />
          </div>
          <h2 className="text-xl md:text-[2vw] font-sans font-bold text-white uppercase tracking-tighter leading-none">
            硅基战略
          </h2>
          <div className="flex items-center gap-4 text-[10px] font-black text-zinc-500 tracking-[0.6em] uppercase">
            <span className="hidden sm:inline">面向品牌决策的混合智能体编排体系</span>
            <span className="sm:hidden">混合智能体决策体系</span>
            <div className="w-1 h-1 rounded-full bg-primary" />
            <span>FUTURE OPS</span>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-20">
          <div className="lg:col-span-8 space-y-8">
            <h3 className="text-xl md:text-[2.2vw] font-sans font-bold text-white leading-[1.1] tracking-tighter uppercase">
              我并不是用 AI 生成内容，<br/>
              <span className="text-primary-gradient">而是在设计一套 system，把信息转化为判断。</span>
            </h3>
            
            <p className="text-[13px] md:text-lg text-zinc-400 font-light leading-relaxed max-w-3xl">
              当多数团队仍依赖人工进行周期性的市场调研与资料整理时，我构建了一套混合智能体架构，用于加速品牌判断、结构化核心资产，并在确保安全与控制权的前提下，建立持续的信息先发优势。
            </p>
          </div>

          <div className="lg:col-span-12 pt-12 border-t border-white/5">
            <div className="flex flex-col md:flex-row md:items-start gap-8 md:gap-16">
              <div className="flex-shrink-0 space-y-2">
                 <div className="flex items-center gap-3">
                   <div className="w-4 h-[1px] bg-primary/40" />
                   <span className="text-[10px] font-black text-primary uppercase tracking-[0.6em]">Problem_Solving</span>
                 </div>
                 <p className="text-[13px] text-zinc-500 font-bold uppercase tracking-widest">核心问题解决：</p>
              </div>
              <div className="flex-1">
                <p className="text-[18px] md:text-[2.2vw] text-white font-bold leading-[1.1] tracking-tighter max-w-none">
                  在该体系中，我通过系统化架构，致力于在信息高度过载的环境中，<br className="hidden xl:block" />
                  <span className="text-primary">如何更快地把噪音转化为可执行的判断。</span>
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="space-y-12 md:space-y-16">
        <div className="space-y-4">
          <span className="text-[10px] font-black text-primary tracking-[0.6em] uppercase">SYSTEM_STRUCTURE</span>
          <h2 className="text-xl md:text-[2vw] font-sans font-bold text-white uppercase tracking-tight">混合智能体架构设计</h2>
          <p className="text-[13px] text-zinc-500 font-light leading-relaxed">该架构将 信息感知 与 资产控制 明确拆分为两个层级，并为其分别设计不同的智能体角色。</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-px bg-white/5 border border-white/5 rounded-[1.5rem] md:rounded-[2rem] overflow-hidden">
          <div className="p-8 md:p-12 bg-zinc-950 space-y-8 group transition-colors hover:bg-white/[0.01]">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-8 h-[1px] bg-primary/40" />
                <span className="text-[9px] font-black text-primary tracking-[0.5em] uppercase">CLOUD_AUDITOR</span>
              </div>
              <Cloud className="w-5 h-5 text-zinc-800 group-hover:text-primary transition-colors" />
            </div>
            
            <div className="space-y-2">
              <h4 className="text-xl font-sans font-bold text-white uppercase tracking-tight">云端审计者 · 信息感知层</h4>
              <p className="text-primary font-bold text-[14px]">Manus（云端智能体）</p>
            </div>

            <div className="grid grid-cols-2 gap-6 text-[13px]">
              <div className="space-y-1">
                <span className="text-[9px] text-zinc-600 font-black uppercase tracking-widest">FUNCTION</span>
                <p className="text-zinc-300 font-bold">全球市场侦察</p>
              </div>
              <div className="space-y-1">
                <span className="text-[9px] text-zinc-600 font-black uppercase tracking-widest">POSITIONING</span>
                <p className="text-zinc-300 font-bold">辅助决策</p>
              </div>
            </div>

            <ul className="space-y-5 md:space-y-6 text-[13px] md:text-lg text-zinc-400 font-light leading-relaxed">
              <li className="flex gap-4"><div className="w-1.5 h-1.5 rounded-full bg-primary mt-2 shrink-0" />自主扫描全球主要竞品的当季品牌活动与视觉系统</li>
              <li className="flex gap-4"><div className="w-1.5 h-1.5 rounded-full bg-primary mt-2 shrink-0" />覆盖公开渠道中的视觉语言、CMF 趋势与叙事模式</li>
              <li className="flex gap-4"><div className="w-1.5 h-1.5 rounded-full bg-primary mt-2 shrink-0" />输出结构化审计结果，为管理层提供判断参考</li>
            </ul>

            <div className="pt-6 border-t border-white/5">
              <div className="mt-4 inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10">
                <div className="w-1 h-1 rounded-full bg-primary animate-pulse" />
                <span className="text-[9px] font-black text-zinc-300 uppercase tracking-widest">STATUS: 审计报告隔夜生成</span>
              </div>
            </div>
          </div>

          <div className="p-8 md:p-12 bg-zinc-950 space-y-8 group transition-colors hover:bg-white/[0.01]">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-8 h-[1px] bg-primary/40" />
                <span className="text-[9px] font-black text-primary tracking-[0.5em] uppercase">LOCAL_ARCHITECT</span>
              </div>
              <Lock className="w-5 h-5 text-zinc-800 group-hover:text-primary transition-colors" />
            </div>

            <div className="space-y-2">
              <h4 className="text-xl font-sans font-bold text-white uppercase tracking-tight">本地架构师 · 资产执行层</h4>
              <p className="text-primary font-bold text-[14px]">Clawdbot（本地智能体）</p>
            </div>

            <div className="grid grid-cols-2 gap-6 text-[13px]">
              <div className="space-y-1">
                <span className="text-[9px] text-zinc-600 font-black uppercase tracking-widest">FUNCTION</span>
                <p className="text-zinc-300 font-bold">资产结构化与执行</p>
              </div>
              <div className="space-y-1">
                <span className="text-[9px] text-zinc-600 font-black uppercase tracking-widest">POSITIONING</span>
                <p className="text-zinc-300 font-bold">系统落地</p>
              </div>
            </div>

            <ul className="space-y-5 md:space-y-6 text-[13px] md:text-lg text-zinc-400 font-light leading-relaxed">
              <li className="flex gap-4"><div className="w-1.5 h-1.5 rounded-full bg-primary mt-2 shrink-0" />在本地安全环境中处理企业核心设计资产</li>
              <li className="flex gap-4"><div className="w-1.5 h-1.5 rounded-full bg-primary mt-2 shrink-0" />基于趋势判断，对内部素材库进行语义级重组</li>
              <li className="flex gap-4"><div className="w-1.5 h-1.5 rounded-full bg-primary mt-2 shrink-0" />构建动态「风格 DNA」结构，支持团队快速调用</li>
            </ul>

            <div className="pt-6 border-t border-white/5">
              <div className="mt-4 inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10">
                <div className="w-1 h-1 rounded-full bg-primary animate-pulse" />
                <span className="text-[9px] font-black text-zinc-300 uppercase tracking-widest">STATUS: 本地安全执行完成</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="space-y-8 py-16 md:py-20 border-t border-white/5">
        <div className="space-y-4">
          <span className="text-[10px] font-black text-primary tracking-[0.6em] uppercase">PERFORMANCE_AUDIT</span>
          <h2 className="text-xl md:text-[2vw] font-sans font-bold text-white uppercase tracking-tight">效能跃迁对比</h2>
        </div>
        <CaseTable content={`维度 | 传统方式 | 混合智能体编排
市场审计周期 | 约 2 周（人工） | 隔夜完成（自主扫描）
信息覆盖率 | 局部抽样 | 广域公开信息
资产整理方式 | 静态分类 | 动态语义结构
战略响应方式 | 被动 | 主动预判
决策准备状态 | 滞后 | 持续在线`} />
      </section>

      <section className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-20 py-20 border-t border-white/5">
        <div className="lg:col-span-5 space-y-8">
           <div className="flex items-center gap-4">
              <span className="text-[10px] font-black text-primary tracking-[0.6em] uppercase">ARCHITECT'S NOTE</span>
              <div className="h-[1px] flex-1 bg-white/5" />
           </div>
           <h3 className="text-xl md:text-[2vw] font-sans font-bold text-white uppercase leading-none tracking-tighter">将噪音转化为信号的速度</h3>
           <p className="text-[13px] md:text-lg text-zinc-400 leading-relaxed font-light">
             未来的核心竞争力，不在于获取更多信息，而在于 <span className="text-white font-bold">多快能将无序信息转化为可判断、可执行的结构</span>。
           </p>
        </div>
        <div className="lg:col-span-7 space-y-12">
           <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {/* Mobile: Merged Box */}
              <div className="md:hidden p-8 rounded-2xl bg-white/[0.02] border border-white/5 space-y-6">
                <div className="space-y-4">
                  <div className="flex items-center gap-3">
                     <div className="w-1.5 h-1.5 rounded-full bg-primary" />
                     <p className="text-[9px] text-zinc-500 uppercase tracking-widest font-black">Manus_Agent</p>
                  </div>
                  <p className="text-[16px] text-white font-bold">用于加速感知</p>
                </div>
                <div className="h-px bg-white/5" />
                <div className="space-y-4">
                  <div className="flex items-center gap-3">
                     <div className="w-1.5 h-1.5 rounded-full bg-primary" />
                     <p className="text-[9px] text-zinc-500 uppercase tracking-widest font-black">Clawdbot_Agent</p>
                  </div>
                  <p className="text-[16px] text-white font-bold">用于放大执行</p>
                </div>
              </div>

              {/* Desktop: Original Boxes */}
              <div className="hidden md:block p-8 rounded-2xl bg-white/[0.02] border border-white/5 space-y-4">
                <div className="flex items-center gap-3">
                   <div className="w-1.5 h-1.5 rounded-full bg-primary" />
                   <p className="text-[9px] text-zinc-500 uppercase tracking-widest font-black">Manus_Agent</p>
                </div>
                <p className="text-[16px] text-white font-bold">用于加速感知</p>
              </div>
              <div className="hidden md:block p-8 rounded-2xl bg-white/[0.02] border border-white/5 space-y-4">
                <div className="flex items-center gap-3">
                   <div className="w-1.5 h-1.5 rounded-full bg-primary" />
                   <p className="text-[9px] text-zinc-500 uppercase tracking-widest font-black">Clawdbot_Agent</p>
                </div>
                <p className="text-[16px] text-white font-bold">用于放大执行</p>
              </div>
           </div>
           
           <div className="space-y-8 pt-12 border-t border-white/5">
              <p className="text-[9px] text-zinc-600 uppercase tracking-[0.5em] font-black">以下能力始终由人类主导</p>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-6">
                 {['品牌方向判断', '审美边界设定', '风险与取舍决策'].map((item, i) => (
                   <div key={i} className="flex items-center gap-4">
                     <ShieldCheck className="w-4 h-4 text-primary/90 opacity-90" />
                     <span className="text-[14px] text-zinc-300 font-bold">{item}</span>
                   </div>
                 ))}
              </div>
              <p className="text-[13px] md:text-lg text-zinc-500 font-light border-l border-primary/20 pl-6 leading-relaxed">
                AI 不替代判断，它只确保判断始终建立在最新信息之上。
              </p>
           </div>
        </div>
      </section>
    </div>
  );
};

const SiliconStrategyViewEN: React.FC = () => {
  return (
    <div className="w-full space-y-16 md:space-y-24">
      <section className="max-w-none space-y-10 md:space-y-16 pt-8 md:pt-16">
        <div className="space-y-6">
          <div className="flex items-center gap-4">
            <span className="text-[10px] font-black text-primary tracking-[0.8em] uppercase">CASE 01</span>
            <div className="h-[1px] flex-1 bg-white/5" />
          </div>
          <h2 className="text-xl md:text-[2vw] font-sans font-bold text-white uppercase tracking-tighter leading-none">
            Silicon Strategy
          </h2>
          <div className="flex items-center gap-4 text-[10px] font-black text-zinc-500 tracking-[0.6em] uppercase">
            <span className="hidden sm:inline">Hybrid Agent Orchestration for Brand Decision Intelligence</span>
            <span className="sm:hidden">Hybrid Agent Decision System</span>
            <div className="w-1 h-1 rounded-full bg-primary" />
            <span>FUTURE OPS</span>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-20">
          <div className="lg:col-span-8 space-y-8">
            <h3 className="text-xl md:text-[2.2vw] font-sans font-bold text-white leading-[1.1] tracking-tighter uppercase">
              I am not merely using AI to generate content;<br/>
              <span className="text-primary-gradient">I am designing a system that transforms information into judgment.</span>
            </h3>
            
            <p className="text-[13px] md:text-lg text-zinc-400 font-light leading-relaxed max-w-3xl">
              While most teams still rely on manual periodic market research and data organization, I have built a hybrid agent architecture to accelerate brand judgment, structure core assets, and establish a continuous information advantage while ensuring security and control.
            </p>
          </div>

          <div className="lg:col-span-12 pt-12 border-t border-white/5">
            <div className="flex flex-col md:flex-row md:items-start gap-8 md:gap-16">
              <div className="flex-shrink-0 space-y-2">
                 <div className="flex items-center gap-3">
                   <div className="w-4 h-[1px] bg-primary/40" />
                   <span className="text-[10px] font-black text-primary uppercase tracking-[0.6em]">Problem_Solving</span>
                 </div>
                 <p className="text-[13px] text-zinc-500 font-bold uppercase tracking-widest">Core Resolution:</p>
              </div>
              <div className="flex-1">
                <p className="text-[18px] md:text-[2.2vw] text-white font-bold leading-[1.1] tracking-tighter max-w-none">
                  In this framework, through systematic architecture, I am dedicated to<br className="hidden xl:block" />
                  <span className="text-primary">how noise can be converted into actionable judgment faster</span> in a highly overloaded environment.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="space-y-12 md:space-y-16">
        <div className="space-y-4">
          <span className="text-[10px] font-black text-primary tracking-[0.6em] uppercase">SYSTEM_STRUCTURE</span>
          <h2 className="text-xl md:text-[2vw] font-sans font-bold text-white uppercase tracking-tight">Hybrid Agent Architecture Design</h2>
          <p className="text-[13px] text-zinc-500 font-light leading-relaxed">This architecture explicitly separates "Information Perception" from "Asset Control" into two distinct layers, designing specialized agent roles for each.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-px bg-white/5 border border-white/5 rounded-[1.5rem] md:rounded-[2rem] overflow-hidden">
          <div className="p-8 md:p-12 bg-zinc-950 space-y-8 group transition-colors hover:bg-white/[0.01]">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-8 h-[1px] bg-primary/40" />
                <span className="text-[9px] font-black text-primary tracking-[0.5em] uppercase">CLOUD_AUDITOR</span>
              </div>
              <Cloud className="w-5 h-5 text-zinc-800 group-hover:text-primary transition-colors" />
            </div>
            
            <div className="space-y-2">
              <h4 className="text-xl font-sans font-bold text-white uppercase tracking-tight">Cloud Auditor · Perception Layer</h4>
              <p className="text-primary font-bold text-[14px]">Manus (Cloud Agent)</p>
            </div>

            <div className="grid grid-cols-2 gap-6 text-[13px]">
              <div className="space-y-1">
                <span className="text-[9px] text-zinc-600 font-black uppercase tracking-widest">FUNCTION</span>
                <p className="text-zinc-300 font-bold">Global Market Recon</p>
              </div>
              <div className="space-y-1">
                <span className="text-[9px] text-zinc-600 font-black uppercase tracking-widest">POSITIONING</span>
                <p className="text-zinc-300 font-bold">Decision Support</p>
              </div>
            </div>

            <ul className="space-y-5 md:space-y-6 text-[13px] md:text-lg text-zinc-400 font-light leading-relaxed">
              <li className="flex gap-4"><div className="w-1.5 h-1.5 rounded-full bg-primary mt-2 shrink-0" />Autonomously scans major competitors' seasonal brand activities and visual systems</li>
              <li className="flex gap-4"><div className="w-1.5 h-1.5 rounded-full bg-primary mt-2 shrink-0" />Covers visual language, CMF trends, and narrative patterns in open-source channels</li>
              <li className="flex gap-4"><div className="w-1.5 h-1.5 rounded-full bg-primary mt-2 shrink-0" />Outputs structured audit results to provide strategic reference for management</li>
            </ul>

            <div className="pt-6 border-t border-white/5">
              <div className="mt-4 inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10">
                <div className="w-1 h-1 rounded-full bg-primary animate-pulse" />
                <span className="text-[9px] font-black text-zinc-300 uppercase tracking-widest">STATUS: AUDIT REPORTS GENERATED OVERNIGHT</span>
              </div>
            </div>
          </div>

          <div className="p-8 md:p-12 bg-zinc-950 space-y-8 group transition-colors hover:bg-white/[0.01]">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-8 h-[1px] bg-primary/40" />
                <span className="text-[9px] font-black text-primary tracking-[0.5em] uppercase">LOCAL_ARCHITECT</span>
              </div>
              <Lock className="w-5 h-5 text-zinc-800 group-hover:text-primary transition-colors" />
            </div>

            <div className="space-y-2">
              <h4 className="text-xl font-sans font-bold text-white uppercase tracking-tight">Local Architect · Execution Layer</h4>
              <p className="text-primary font-bold text-[14px]">Clawdbot (Local Agent)</p>
            </div>

            <div className="grid grid-cols-2 gap-6 text-[13px]">
              <div className="space-y-1">
                <span className="text-[9px] text-zinc-600 font-black uppercase tracking-widest">FUNCTION</span>
                <p className="text-zinc-300 font-bold">Asset Structuring & Exec</p>
              </div>
              <div className="space-y-1">
                <span className="text-[9px] text-zinc-600 font-black uppercase tracking-widest">POSITIONING</span>
                <p className="text-zinc-300 font-bold">System Deployment</p>
              </div>
            </div>

            <ul className="space-y-5 md:space-y-6 text-[13px] md:text-lg text-zinc-400 font-light leading-relaxed">
              <li className="flex gap-4"><div className="w-1.5 h-1.5 rounded-full bg-primary mt-2 shrink-0" />Processes core enterprise design assets within a secure local environment</li>
              <li className="flex gap-4"><div className="w-1.5 h-1.5 rounded-full bg-primary mt-2 shrink-0" />Performs semantic-level reorganization of internal asset libraries based on trend insights</li>
              <li className="flex gap-4"><div className="w-1.5 h-1.5 rounded-full bg-primary mt-2 shrink-0" />Builds dynamic "Style DNA" structures to support rapid team invocation and collaboration</li>
            </ul>

            <div className="pt-6 border-t border-white/5">
              <div className="mt-4 inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10">
                <div className="w-1 h-1 rounded-full bg-primary animate-pulse" />
                <span className="text-[9px] font-black text-zinc-300 uppercase tracking-widest">STATUS: LOCAL SECURE EXECUTION COMPLETE</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="space-y-8 py-16 md:py-20 border-t border-white/5">
        <div className="space-y-4">
          <span className="text-[10px] font-black text-primary tracking-[0.6em] uppercase">PERFORMANCE_AUDIT</span>
          <h2 className="text-xl md:text-[2vw] font-sans font-bold text-white uppercase tracking-tight">Strategic Performance Leap</h2>
        </div>
        <CaseTable content={`Dimension | Traditional Method | Hybrid Agent Orchestration
Market Audit Cycle | Approx. 2 Weeks (Manual) | Overnight (Autonomous Scan)
Information Coverage | Partial Sampling | Global Public Information
Asset Organization | Static Classification | Dynamic Semantic Structure
Strategic Response | Passive | Proactive Prediction
Decision Readiness | Lagging | Continuously Online`} />
      </section>

      <section className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-20 py-20 border-t border-white/5">
        <div className="lg:col-span-5 space-y-8">
           <div className="flex items-center gap-4">
              <span className="text-[10px] font-black text-primary tracking-[0.6em] uppercase">ARCHITECT'S NOTE</span>
              <div className="h-[1px] flex-1 bg-white/5" />
           </div>
           <h3 className="text-xl md:text-[2vw] font-sans font-bold text-white uppercase leading-none tracking-tighter">The Velocity of Converting Noise into Signals</h3>
           <p className="text-[13px] md:text-lg text-zinc-400 leading-relaxed font-light">
             Future core competitiveness lies not in acquiring more information, but in <span className="text-white font-bold">the speed at which you can transform unordered information into structures that are judgeable and executable</span>.
           </p>
        </div>
      </section>
    </div>
  );
};

const AIGCLayout: React.FC<{ project: Project; onClose: () => void }> = ({ project, onClose }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ container: containerRef });
  const springProgress = useSpring(scrollYProgress, { stiffness: 100, damping: 30 });
  const navBgOpacity = useTransform(scrollYProgress, [0, 0.05], [0, 0.98]);

  const isEn = !/[\u4e00-\u9fa5]/.test(project.title);
  const siliconSection = project.sections.find(s => s.title.includes("硅基战略") || s.title.includes("Silicon Strategy"));
  const netflixSection = project.sections.find(s => s.title.includes("Netflix"));
  const astonSection = project.sections.find(s => s.title.includes("Aston Martin"));
  const hipaySection = project.sections.find(s => s.title.includes("HIPAY"));

  return (
    <motion.div 
      initial={{ opacity: 0 }} 
      animate={{ opacity: 1 }} 
      exit={{ opacity: 0 }} 
      className="fixed inset-0 z-[3000] bg-[#050505] overflow-hidden transform-gpu translate-z-0 isolate"
    >
      <GrainOverlay />
      
      <motion.div 
        style={{ scaleX: springProgress }}
        className="fixed top-16 md:top-20 left-0 right-0 h-[2px] bg-primary z-[5200] origin-left pointer-events-none"
      />

      <motion.nav 
        style={{ 
          backgroundColor: `rgba(10, 10, 10, ${navBgOpacity.get()})`, 
          borderBottomColor: `rgba(255, 255, 255, ${navBgOpacity.get() * 0.05})`,
          backdropFilter: 'blur(50px)'
        }}
        className="fixed top-16 md:top-20 left-0 right-0 h-16 md:h-20 z-[5100] border-b border-transparent flex items-center px-6 md:px-12 transition-all duration-700 isolate"
      >
        <div className="w-full max-w-[1550px] mx-auto flex items-center pointer-events-auto justify-between">
          <div className="flex items-center">
            <button 
              onClick={onClose} 
              className="flex items-center justify-center min-w-[44px] gap-3 px-5 py-2 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 text-white font-black uppercase font-sans text-[10px] tracking-[0.2em] transition-all group shrink-0 relative z-20 isolate"
            >
              <ChevronLeft className="w-3.5 h-3.5 md:w-4 md:h-4 group-hover:-translate-x-1 transition-transform" />
              <span className="hidden sm:block">BACK</span>
            </button>
            
            <div className="w-[1px] h-6 bg-white/10 mx-6 md:mx-8 shrink-0" />
            
            <div className="flex items-center font-sans font-black uppercase text-[10px] tracking-[0.2em] text-zinc-600 gap-2">
              <span className="text-white hidden md:inline">PROJECT ARCHIVE</span>
              <span className="opacity-20 hidden md:inline">//</span>
              <span className="truncate max-w-[150px] md:max-w-none">{project.title}</span>
            </div>
          </div>

          <div className="hidden md:flex items-center gap-4 lg:gap-8">
            <button onClick={() => document.getElementById('silicon-strategy')?.scrollIntoView({ behavior: 'smooth' })} className="text-[10px] font-black text-zinc-500 hover:text-primary transition-colors uppercase tracking-[0.2em]">CASE 01</button>
            {netflixSection && <button onClick={() => document.getElementById('netflix')?.scrollIntoView({ behavior: 'smooth' })} className="text-[10px] font-black text-zinc-500 hover:text-primary transition-colors uppercase tracking-[0.2em]">CASE 02</button>}
            {astonSection && <button onClick={() => document.getElementById('aston-martin')?.scrollIntoView({ behavior: 'smooth' })} className="text-[10px] font-black text-zinc-500 hover:text-primary transition-colors uppercase tracking-[0.2em]">CASE 03</button>}
            {hipaySection && <button onClick={() => document.getElementById('hipay')?.scrollIntoView({ behavior: 'smooth' })} className="text-[10px] font-black text-zinc-500 hover:text-primary transition-colors uppercase tracking-[0.2em]">CASE 04</button>}
          </div>
        </div>
      </motion.nav>

      <div 
        ref={containerRef}
        className="w-full h-full overflow-y-auto no-scrollbar scroll-smooth transform-gpu pt-32 md:pt-40 scroll-pt-[128px] md:scroll-pt-[160px]"
      >
        {/* --- INTRO SECTION --- */}
        <section className="min-h-[70vh] flex flex-col justify-end px-6 md:px-24 pb-20 md:pb-32 relative overflow-hidden bg-black">
          <div className="absolute inset-0 z-0">
            <img src={project.imageUrl} className="w-full h-full object-cover opacity-60 scale-105 saturate-[0.8]" alt="" />
            <div className="absolute inset-x-0 bottom-0 h-[50vh] bg-transparent backdrop-blur-[30px]" style={{ WebkitMaskImage: 'linear-gradient(to top, black 0%, transparent 100%)', maskImage: 'linear-gradient(to top, black 0%, transparent 100%)' }} />
          </div>
          <div className="relative z-10 max-w-[1550px] mx-auto w-full flex flex-col items-start gap-8">
            <motion.h1 
              initial={{ opacity: 0, y: 30 }} 
              animate={{ opacity: 1, y: 0 }} 
              transition={{ delay: 0.1, duration: 1 }}
              className="text-4xl md:text-[6vw] font-sans font-bold leading-[0.9] tracking-tighter text-white uppercase drop-shadow-2xl"
            >
              {project.title}
            </motion.h1>
          </div>
        </section>

        <div className="max-w-[1550px] mx-auto px-6 md:px-24 space-y-40 md:space-y-80 pb-60 md:pb-96">
          
          {/* --- CASE 01: SILICON STRATEGY --- */}
          <section id="silicon-strategy">
            {isEn ? <SiliconStrategyViewEN /> : <SiliconStrategyViewCN />}
          </section>

          {/* --- CASE 02: NETFLIX / VERMILION --- */}
          {netflixSection && (
            <section id="netflix" className="space-y-16 md:space-y-24">
              <div className="space-y-6">
                 <div className="flex items-center gap-4">
                   <span className="text-[10px] font-black text-primary font-light opacity-90 tracking-[0.8em] uppercase">CASE 02</span>
                   <div className="h-[1px] flex-1 bg-white/5" />
                 </div>
                 <h2 className="text-xl md:text-[2vw] font-sans font-bold text-white uppercase tracking-tighter leading-none">
                   {netflixSection.title}
                 </h2>
                 <div className="flex items-center gap-4 text-[10px] font-black text-zinc-500 tracking-[0.6em] uppercase">
                   <span>NARRATIVE PRODUCTION</span>
                   <div className="w-1 h-1 rounded-full bg-primary" />
                   <span>VIRTUAL SCENE</span>
                 </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-24 items-start">
                 <div className="lg:col-span-5 space-y-10">
                    <div className="text-[13px] md:text-lg text-zinc-400 font-light leading-relaxed space-y-8">
                       <p className="border-l border-primary/20 pl-8">{netflixSection.description}</p>
                       <div className="grid grid-cols-2 gap-8 pt-8">
                          <div className="space-y-2">
                             <span className="text-[9px] font-black text-zinc-600 uppercase tracking-widest">PRE-PRO CYCLE</span>
                             <p className="text-white font-bold text-xl tracking-tight">48 HOURS <span className="text-zinc-600 text-xs font-normal">vs 3 MONTHS</span></p>
                          </div>
                          <div className="space-y-2">
                             <span className="text-[9px] font-black text-zinc-600 uppercase tracking-widest">SCENE COST</span>
                             <p className="text-primary font-bold text-xl tracking-tight">ZERO $</p>
                          </div>
                       </div>
                    </div>
                    
                    <Terminal title="AIGC // DIRECTING_LOG" code={netflixSection.points?.[0] || ""} />
                 </div>

                 <div className="lg:col-span-7 space-y-12">
                    <div className="flex flex-col gap-12">
                       {netflixSection.images.map((img, i) => (
                         <ImageWithOverlay 
                           key={i}
                           src={img} 
                           caption={isEn ? "STEP 01: Constrained organic sketches, defining brand curves" : "STEP 01: 有约束的有机线稿, 定义品牌英伦曲线"} 
                         />
                       ))}
                    </div>

                    <ImageWithOverlay 
                      src={netflixSection.videoUrl || ""} 
                      type="video"
                      caption={isEn ? "Actor performance driven by AI choreography" : "AI 调度下的演员表现力细节"}
                      poster={netflixSection.images?.[0]}
                    />
                 </div>
              </div>
            </section>
          )}

          {/* --- CASE 03: ASTON MARTIN --- */}
          {astonSection && (
            <section id="aston-martin" className="space-y-20">
              <div className="space-y-6">
                 <div className="flex items-center gap-4">
                   <span className="text-[10px] font-black text-primary font-light opacity-90 tracking-[0.8em] uppercase">CASE 03</span>
                   <div className="h-[1px] flex-1 bg-white/5" />
                 </div>
                 <h2 className="text-xl md:text-[2vw] font-sans font-bold text-white uppercase tracking-tighter leading-none">
                   {astonSection.title}
                 </h2>
              </div>

              <StrategyRow label="CHALLENGE" title={isEn ? "ULTRA-LUXURY PRECISION" : "顶级超跑的精度要求"}>
                {astonSection.description}
              </StrategyRow>

              <div className="space-y-32 md:space-y-48">
                 <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-24 items-center">
                    <div className="lg:col-span-6">
                       <ImageWithOverlay 
                         src="https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/luxury/astonmartin-silverwings-sketch-01.webp"
                         caption=""
                       />
                    </div>
                    <div className="lg:col-span-6 space-y-8">
                       <div className="p-8 rounded-2xl bg-white/[0.02] border border-white/5 space-y-6">
                          <div className="flex items-center gap-4">
                             <TerminalIcon className="w-5 h-5 text-primary/90 opacity-90" />
                             <span className="text-[10px] font-black text-zinc-400 uppercase tracking-[0.4em]">SYSTEM_LOG</span>
                          </div>
                          <p className="text-[13px] md:text-lg text-zinc-300 font-light leading-relaxed">
                            {isEn ? "The extreme speed of this workflow allowed me to achieve 'real-time collaborative creation' with the client on-site. We finalized the design direction within 1 hour." : "这种工作流的极速特性让我在提案现场实现了与客户的‘实时协同创作’。我们在 1 小时内就敲定了最终的设计方向。"}
                          </p>
                       </div>
                    </div>
                 </div>

                 <div className="space-y-12">
                   <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12">
                      <ImageWithOverlay 
                        src="https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/luxury/astonmartin-silverwings-cmf-01.webp" 
                        caption={isEn ? "STEP 02: CMF Exploration - Comparing Gentility vs. Intensity" : "STEP 02: CMF 探索 - 绅士与力量感的对比"} 
                      />
                      <ImageWithOverlay 
                        src="https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/luxury/astonmartin-silverwings-hero-01.webp" 
                        caption={isEn ? "STEP 03: Final Hero - Photorealistic Validation" : "STEP 03: 最终主视觉 - 实景化验证"} 
                      />
                   </div>
                   <div className="grid grid-cols-1 md:grid-cols-12 gap-8 md:gap-12">
                      <div className="md:col-span-7 space-y-12">
                        <ImageWithOverlay 
                          src="https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/luxury/astonmartin-silverwings-spatial-01.webp" 
                          caption={isEn ? "Spatial Context: Architecture as Light Controller" : "空间语境：建筑作为光影控制器"} 
                        />
                        <ImageWithOverlay 
                          src="https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/video/luxury/astonmartin-silverwings-material-01.mp4" 
                          type="video"
                          caption={isEn ? "Material & Light Fidelity Check" : "材质与光影精度校验"} 
                        />
                      </div>
                      <div className="md:col-span-5">
                         <div className="h-full rounded-2xl bg-zinc-950 border border-white/5 p-10 flex flex-col justify-center space-y-8">
                            <div className="space-y-2">
                               <span className="text-[9px] font-black text-primary font-light opacity-90 tracking-[0.5em] uppercase">EFFICIENCY_LOG</span>
                               <h4 className="text-xl font-bold text-white uppercase">{isEn ? "Strategic Performance Leap" : "决策效能跃迁"}</h4>
                            </div>
                            <div className="space-y-6">
                               <div className="flex justify-between border-b border-white/5 pb-4">
                                  <span className="text-[11px] text-zinc-500 uppercase">Iteration Speed</span>
                                  <span className="text-primary font-bold">30 versions / hr</span>
                               </div>
                               <div className="flex justify-between border-b border-white/5 pb-4">
                                  <span className="text-[11px] text-zinc-500 uppercase">Decision Cycle</span>
                                  <span className="text-primary font-bold">1 Hour (Sync)</span>
                               </div>
                               <div className="flex justify-between">
                                  <span className="text-[11px] text-zinc-500 uppercase">Cost Saving</span>
                                  <span className="text-primary font-bold">80% Visualization</span>
                               </div>
                            </div>
                         </div>
                      </div>
                   </div>
                 </div>
              </div>
            </section>
          )}

          {/* --- CASE 04: HIPAY --- */}
          {hipaySection && (
            <section id="hipay" className="space-y-16 md:space-y-24">
               <div className="space-y-6">
                 <div className="flex items-center gap-4">
                   <span className="text-[10px] font-black text-primary font-light opacity-90 tracking-[0.8em] uppercase">CASE 04</span>
                   <div className="h-[1px] flex-1 bg-white/5" />
                 </div>
                 <h2 className="text-xl md:text-[2vw] font-sans font-bold text-white uppercase tracking-tighter leading-none">
                   {hipaySection.title}
                 </h2>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-24">
                 <div className="lg:col-span-4 space-y-12">
                    <div className="space-y-6">
                       <h3 className="text-2xl font-bold text-white uppercase tracking-tight">{isEn ? "Decision Boundaries" : "决策边界的探索"}</h3>
                       <p className="text-[13px] md:text-lg text-zinc-400 font-light leading-relaxed">
                         {hipaySection.description}
                       </p>
                    </div>
                    
                    <div className="space-y-8">
                       <div className="flex items-center gap-4">
                          <Command className="w-5 h-5 text-primary/90 opacity-90" />
                          <span className="text-[10px] font-black text-zinc-400 uppercase tracking-[0.4em]">ARCHITECTURE_STEP</span>
                       </div>
                       <div className="space-y-6">
                          <div className="p-6 rounded-xl bg-white/[0.02] border border-white/5 space-y-3">
                             <span className="text-[9px] font-black text-zinc-600 uppercase">Logic Formation</span>
                             <p className="text-[14px] text-zinc-300 font-medium">{isEn ? "Letting payment logic precede interface formation, confirming which complex processes should be absorbed by the system." : "让支付逻辑先于界面成形，确认哪些复杂流程应由系统消化。"}</p>
                          </div>
                          <div className="p-6 rounded-xl bg-white/[0.02] border border-white/5 space-y-3">
                             <span className="text-[9px] font-black text-zinc-600 uppercase">Aesthetic Consensus</span>
                             <p className="text-[14px] text-zinc-300 font-medium">{isEn ? "Establishing a consensus mechanism between design and engineering to reduce understanding deviations in high-risk systems." : "建立设计到工程之间的共识机制，减少高风险系统中的理解偏差。"}</p>
                          </div>
                       </div>
                    </div>
                 </div>

                 <div className="lg:col-span-8 space-y-12">
                    <ImageWithOverlay 
                      src="https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/web3/hipay-payment-logic-01.webp" 
                      caption="" 
                    />
                    <ImageWithOverlay 
                      src="https://janice-images-1395762740.cos.ap-shanghai.myqcloud.com/assets/img/web3/hipay-payment-ui-01.webp" 
                      caption="" 
                    />
                 </div>
              </div>
            </section>
          )}

          {/* --- THE LEADER'S TOOLKIT --- */}
          <section className="py-20 md:py-40 bg-zinc-950/40 rounded-[3rem] border border-white/5 p-10 md:p-24 overflow-hidden relative">
            <div className="absolute top-0 right-0 w-96 h-96 bg-primary/10 blur-[150px] rounded-full -translate-y-1/2 translate-x-1/2" />
            
            <div className="relative z-10 space-y-20">
               <div className="space-y-6">
                  <span className="text-[10px] font-black text-primary font-light opacity-90 tracking-[0.8em] uppercase">SUMMARY // THE TOOLKIT</span>
                  <h2 className="text-3xl md:text-[4vw] font-sans font-bold text-white uppercase tracking-tighter leading-none">
                    Beyond visuals, <br/>
                    <span className="text-primary-gradient">I build assets that belong to the enterprise.</span>
                  </h2>
               </div>

               <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
                  <div className="space-y-6 group">
                     <div className="w-16 h-16 rounded-2xl bg-white/5 flex items-center justify-center border border-white/10 group-hover:bg-primary/20 group-hover:border-primary/40 transition-all duration-500">
                        <Database className="w-8 h-8 text-primary/90 opacity-90" />
                     </div>
                     <div className="space-y-4">
                        <h4 className="text-xl font-bold text-white uppercase">Private Model Library</h4>
                        <p className="text-[13px] md:text-[15px] text-zinc-500 leading-relaxed font-light">{isEn ? "3 brand-exclusive LoRA models, solidifying brand aesthetic DNA into callable digital code." : "3 个品牌专属 LoRA 模型，将品牌美学 DNA 固化为可调用的数字代码。"}</p>
                     </div>
                  </div>
                  <div className="space-y-6 group">
                     <div className="w-16 h-16 rounded-2xl bg-white/5 flex items-center justify-center border border-white/10 group-hover:bg-primary/20 group-hover:border-primary/40 transition-all duration-500">
                        <Book className="w-8 h-8 text-primary/90 opacity-90" />
                     </div>
                     <div className="space-y-4">
                        <h4 className="text-xl font-bold text-white uppercase">Prompt Dictionary</h4>
                        <p className="text-[13px] md:text-[15px] text-zinc-500 leading-relaxed font-light">{isEn ? "200+ standardized prompt libraries, enabling junior teams to deliver high-precision visual assets with zero threshold." : "200+ 标准化提示词库，让初级团队能够无门槛交付高准度视觉资产。"}</p>
                     </div>
                  </div>
                  <div className="space-y-6 group">
                     <div className="w-16 h-16 rounded-2xl bg-white/5 flex items-center justify-center border border-white/10 group-hover:bg-primary/20 group-hover:border-primary/40 transition-all duration-500">
                        <Workflow className="w-8 h-8 text-primary/90 opacity-90" />
                     </div>
                     <div className="space-y-4">
                        <h4 className="text-xl font-bold text-white uppercase">Workflow S.O.P.</h4>
                        <p className="text-[13px] md:text-[15px] text-zinc-500 leading-relaxed font-light">{isEn ? "4 sets of AIGC collaboration whitepapers, defining granularity and quality acceptance standards in human-machine collaboration." : "4 套 AIGC 协作白皮书，定义人机协作中的颗粒度与质量验收标准。"}</p>
                     </div>
                  </div>
               </div>
            </div>
          </section>

          <section className="px-6 py-40 border-t border-white/5 text-center">
            <h3 className={`font-sans font-bold text-white mb-16 tracking-tight text-center mx-auto leading-relaxed ${isEn ? 'text-[clamp(1.25rem,5vw,2rem)]' : 'text-[clamp(1.5rem,6vw,2.5rem)]'}`}>
              {isEn ? (
                <>Scaling <span className="text-primary">creative intelligence</span> <br/><span className="text-primary">through architectural system design.</span></>
              ) : (
                <>通过系统化架构设计，<br/><span className="text-primary">实现创意智能的指数级扩容</span>。</>
              )}
            </h3>
            <button 
              onClick={onClose}
              className="px-16 py-6 rounded-full bg-white text-black font-black uppercase text-[12px] tracking-[0.4em] hover:bg-primary hover:text-white transition-all shadow-4xl duration-500"
            >
              BACK TO PORTFOLIO
            </button>
          </section>
        </div>
      </div>

      <style>{`
        .no-scrollbar::-webkit-scrollbar { display: none; }
        .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
        .text-primary-gradient {
          background-image: linear-gradient(to right, #C5A059, #C5A059);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
        }
          background: linear-gradient(to right, #86570B, #c48a28);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
        }
      `}</style>
    </motion.div>
  );
};

// Internal icons helper for Toolkit section
const Database = ({ className }: { className?: string }) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <ellipse cx="12" cy="5" rx="9" ry="3"></ellipse>
    <path d="M3 5V19A9 3 0 0 0 21 19V5"></path>
    <path d="M3 12A9 3 0 0 0 21 12"></path>
  </svg>
);

const Book = ({ className }: { className?: string }) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"></path>
    <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"></path>
  </svg>
);

const Workflow = ({ className }: { className?: string }) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <rect x="3" y="3" width="7" height="7"></rect>
    <rect x="14" y="3" width="7" height="7"></rect>
    <rect x="14" y="14" width="7" height="7"></rect>
    <rect x="3" y="14" width="7" height="7"></rect>
    <path d="M10 6.5h4"></path>
    <path d="M10 17.5h4"></path>
    <path d="M6.5 10v4"></path>
    <path d="M17.5 10v4"></path>
  </svg>
);

export default AIGCLayout;
