import React, { useState, useRef, useEffect } from 'react';
import { motion as m, AnimatePresence, useScroll, useTransform, useSpring } from 'framer-motion';
import { 
  ChevronLeft, ArrowUp, ChevronDown
} from 'lucide-react';
import { Project } from '../types';

// Cast motion to any to bypass environment-specific type definition issues
const motion = m as any;

const FullscreenSection: React.FC<{ 
  section: any; 
  index: number; 
  total: number;
  projectCover: string;
  isEn: boolean;
  scrollToSection: (id: string) => void;
}> = ({ section, index, total, projectCover, isEn, scrollToSection }) => {
  const containerRef = useRef(null);
  const isSlider = section.isSlider === true;
  const isPlaceholder = section.isPlaceholder === true;
  
  // State for active image in slider sections
  const initialImage = (section.images && section.images.length > 0) ? section.images[0] : projectCover;
  const [activeImage, setActiveImage] = useState(initialImage);

  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start end", "end start"]
  });

  // Parallax effects for desktop
  const y = useTransform(scrollYProgress, [0, 1], ["-2%", "2%"]);
  const imgScale = useTransform(scrollYProgress, [0, 0.5, 1], [1.02, 1, 1.02]);

  return (
    <div 
      ref={containerRef}
      id={`web3-section-${index}`}
      data-index={index}
      className="relative h-auto lg:h-[100dvh] w-full lg:snap-start overflow-hidden bg-black flex flex-col items-stretch"
    >
      {/* --- DESKTOP VIEW (Cinematic Background) --- */}
      <div className="hidden lg:block absolute inset-0 z-0">
        {isPlaceholder ? (
          <div className="absolute inset-0 grid place-items-center bg-[radial-gradient(circle_at_50%_40%,rgba(197,160,89,0.16),transparent_42%),linear-gradient(135deg,#050505,#111)]">
            <div className="border border-dashed border-white/20 px-10 py-8 text-center">
              <p className="text-[10px] font-black tracking-[0.45em] text-primary uppercase">{section.placeholderLabel}</p>
            </div>
          </div>
        ) : (
          <AnimatePresence mode="wait">
            <motion.div 
              key={activeImage}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 1.2, ease: "easeInOut" }}
              style={{ y, scale: imgScale }}
              className="absolute inset-0 flex items-center justify-center overflow-hidden"
            >
               <img 
                  src={activeImage} 
                  loading={index < 2 ? "eager" : "lazy"}
                  className="w-full h-full object-cover object-center brightness-[0.8] saturate-[1.05]" 
                  alt={section.title} 
               />
            </motion.div>
          </AnimatePresence>
        )}
        {/* Scrim for desktop readability */}
        <div className="absolute inset-x-0 bottom-0 h-[50vh] z-10 bg-transparent backdrop-blur-[30px] pointer-events-none" style={{ WebkitMaskImage: 'linear-gradient(to top, black 0%, transparent 100%)', maskImage: 'linear-gradient(to top, black 0%, transparent 100%)' }} />
      </div>

      {/* --- MOBILE VIEW (Unified Narrative Unit) --- */}
      <div className="lg:hidden flex flex-col justify-start items-center h-auto w-full px-6 pt-12 pb-20 border-b border-white/5 z-0">
        {/* Media Area */}
        {isPlaceholder ? (
          <div className="w-full aspect-[4/3] mb-6 grid place-items-center border border-dashed border-white/20 bg-zinc-950 px-6 text-center">
            <span className="text-[10px] font-black tracking-[0.25em] text-primary uppercase">{section.placeholderLabel}</span>
          </div>
        ) : !isSlider ? (
          <div className="relative w-full flex justify-center mb-6">
             <AnimatePresence mode="wait">
               <motion.img 
                  key={`main-${activeImage}`}
                  initial={{ opacity: 0, scale: 0.98 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 1.02 }}
                  transition={{ duration: 0.8 }}
                  src={activeImage} 
                  className="relative z-10 max-h-[55vh] w-auto object-contain" 
                  alt={section.title} 
               />
             </AnimatePresence>
          </div>
        ) : (
          <div className="w-full mb-6 space-y-4">
            <div className="flex gap-3 overflow-x-auto no-scrollbar snap-x -mx-6 px-6">
              {section.images.map((img: string, i: number) => (
                <div 
                  key={i} 
                  className="flex-shrink-0 w-[85vw] snap-center rounded-xl overflow-hidden aspect-[4/3]"
                >
                  <img 
                    src={img} 
                    className="w-full h-full object-cover" 
                    alt="" 
                  />
                </div>
              ))}
            </div>
            <div className="flex justify-center gap-1">
              {section.images.map((_: any, i: number) => (
                <div key={i} className="w-1 h-1 rounded-full bg-primary/40" />
              ))}
            </div>
          </div>
        )}

        {/* Content Area */}
        <div className="w-full flex flex-col">
          {/* Section Indicator */}
          {index > 0 && (
            <div className="flex items-center gap-3 mb-3">
              <span className="text-[9px] font-black text-primary tracking-[0.4em] uppercase">
                STAGE 0{index}
              </span>
              <div className="h-[1px] flex-1 bg-primary/10" />
            </div>
          )}

          <div className="space-y-1">
            <h2 className="text-lg font-sans font-bold text-white uppercase tracking-tight leading-tight">
              {section.title}
            </h2>
            <p className="text-[12px] text-zinc-400 font-light leading-relaxed tracking-wide">
              {section.description}
            </p>
          </div>
        </div>
      </div>

      {/* --- SHARED OVERLAYS (Mainly for Desktop position) --- */}
      <div className="hidden lg:flex relative z-20 w-full max-w-[1550px] mx-auto px-24 pb-24 flex-col justify-end h-full">
        <div className="w-[95%] space-y-6">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 1 }}
            className="space-y-4"
          >
            {index > 0 && (
              <div className="flex items-center gap-4">
                <span className="text-[10px] font-black text-primary tracking-[0.6em] uppercase">
                  STAGE 0{index}
                </span>
                <div className="h-[1px] w-12 bg-primary/40" />
              </div>
            )}

            {isSlider && (
              <div className="pb-2 flex gap-4 overflow-x-auto no-scrollbar">
                {section.images.map((img: string, i: number) => (
                  <button 
                    key={i} 
                    onClick={() => setActiveImage(img)}
                    className={`flex-shrink-0 rounded-lg overflow-hidden border-2 transition-all duration-500 transform-gpu ${activeImage === img ? 'border-primary scale-105 shadow-[0_0_25px_rgba(134,87,11,0.6)]' : 'border-white/10 opacity-50 hover:opacity-100'}`}
                  >
                    <img src={img} className="h-40 w-auto shadow-2xl" alt="" />
                  </button>
                ))}
              </div>
            )}

            <div className="space-y-2">
              <h2 className="text-[2vw] font-sans font-bold text-white uppercase tracking-tight leading-tight drop-shadow-2xl">
                {section.title}
              </h2>
              <p className="text-lg text-zinc-300 font-light leading-[1.6] max-w-[1400px] tracking-wide opacity-90">
                {section.description}
              </p>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Shared Navigation Indicators (Side) */}
      <div className="absolute right-6 md:right-12 top-1/2 -translate-y-1/2 z-30 hidden sm:flex flex-col gap-10">
        {Array.from({ length: total }).map((_, i) => (
          <button
            key={i}
            onClick={() => scrollToSection(`web3-section-${i}`)}
            className={`w-[1px] transition-all duration-1000 rounded-full ${index === i ? 'h-12 bg-primary shadow-[0_0_20px_rgba(134,87,11,1)]' : 'h-3 bg-white/10'}`}
          />
        ))}
      </div>
    </div>
  );
};

const Web3Layout: React.FC<{ project: Project; onClose: () => void }> = ({ project, onClose }) => {
  const [activeTab, setActiveTab] = useState<number>(0);
  const containerRef = useRef<HTMLDivElement>(null);

  const { scrollYProgress } = useScroll({ container: containerRef });
  const springProgress = useSpring(scrollYProgress, { stiffness: 100, damping: 30 });
  const navBgOpacity = useTransform(scrollYProgress, [0, 0.05], [0, 0.98]);

  const isEn = !/[\u4e00-\u9fa5]/.test(project.title);
  const cryditIndex = project.sections.findIndex(section => section.title.includes('Crydit'));

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el && containerRef.current) {
      containerRef.current.scrollTo({
        top: el.offsetTop - 160,
        behavior: 'smooth'
      });
    }
  };

  useEffect(() => {
    const options = {
      root: containerRef.current,
      rootMargin: '-30% 0px -30% 0px',
      threshold: 0.1
    };

    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          const index = parseInt(entry.target.getAttribute('data-index') || '0');
          setActiveTab(index);
        }
      });
    }, options);

    project.sections.forEach((_, i) => {
      const el = document.getElementById(`web3-section-${i}`);
      if (el) observer.observe(el);
    });

    return () => observer.disconnect();
  }, [project.sections]);

  return (
    <motion.div 
      initial={{ opacity: 0 }} 
      animate={{ opacity: 1 }} 
      exit={{ opacity: 0 }} 
      className="fixed inset-0 z-[3000] bg-black overflow-hidden transform-gpu translate-z-0 isolate"
    >
      <motion.div 
        style={{ scaleX: springProgress }}
        className="fixed top-16 md:top-20 left-0 right-0 h-[2px] bg-primary z-[5200] origin-left pointer-events-none"
      />

      <motion.nav 
        style={{ 
          backgroundColor: `rgba(10, 10, 10, ${navBgOpacity.get()})`, 
          borderBottomColor: `rgba(255, 255, 255, ${navBgOpacity.get() * 0.05})`,
          backdropFilter: 'blur(50px)'
        }}
        className="fixed top-16 md:top-20 left-0 right-0 h-16 md:h-20 z-[5100] border-b border-transparent flex items-center px-6 md:px-12 transition-all duration-700 isolate"
      >
        <div className="w-full max-w-[1550px] mx-auto flex items-center pointer-events-auto">
          <button 
            onClick={onClose} 
            className="flex items-center justify-center min-w-[40px] md:min-w-[44px] gap-2 md:gap-3 px-3 md:px-5 py-2 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 text-white font-black uppercase font-sans text-[10px] tracking-[0.2em] transition-all group shrink-0 relative z-20 isolate"
          >
            <ChevronLeft className="w-3.5 h-3.5 md:w-4 md:h-4 group-hover:-translate-x-1 transition-transform" />
            <span className="hidden sm:block">BACK</span>
          </button>
          
          <div className="w-[1px] h-4 md:h-6 bg-white/10 mx-4 md:mx-8 shrink-0" />

          <div className="hidden xl:flex items-center gap-2 shrink-0">
            <button onClick={() => scrollToSection('web3-section-0')} className="px-3 py-2 text-[9px] font-black tracking-[0.18em] uppercase text-primary border border-primary/30 rounded-full hover:bg-primary/10">01 / MEXC</button>
            {cryditIndex >= 0 && <button onClick={() => scrollToSection(`web3-section-${cryditIndex}`)} className="px-3 py-2 text-[9px] font-black tracking-[0.18em] uppercase text-zinc-400 border border-white/10 rounded-full hover:text-white hover:bg-white/5">02 / Crydit</button>}
          </div>

          <div className="w-[1px] h-4 md:h-6 bg-white/10 mx-4 md:mx-8 shrink-0 hidden xl:block" />
          
          <div className={`flex-1 flex items-center gap-6 md:gap-12 font-sans font-black uppercase text-[10px] tracking-[0.2em] overflow-x-auto no-scrollbar whitespace-nowrap min-w-0`}>
            {project.sections.slice(1).map((section, idx) => {
              const actualIdx = idx + 1;
              return (
                <button 
                  key={actualIdx} 
                  onClick={() => scrollToSection(`web3-section-${actualIdx}`)} 
                  className={`transition-all hover:text-primary shrink-0 ${activeTab === actualIdx ? 'text-primary' : 'text-zinc-600'}`}
                >
                  0{actualIdx} · {section.label}
                </button>
              );
            })}
          </div>
        </div>
      </motion.nav>

      <div 
        ref={containerRef}
        className="w-full h-full overflow-y-auto lg:snap-y lg:snap-mandatory no-scrollbar scroll-smooth transform-gpu scroll-pt-[128px] md:scroll-pt-[160px]"
      >
        {project.sections.map((section, idx) => (
          <FullscreenSection 
            key={idx} 
            section={section} 
            index={idx} 
            total={project.sections.length}
            projectCover={project.imageUrl}
            isEn={isEn}
            scrollToSection={scrollToSection}
          />
        ))}

        <section className="h-[100dvh] w-full lg:snap-start bg-[#050505] flex flex-col justify-center items-center px-6 relative overflow-hidden border-t border-white/5">
           <div className="absolute inset-0 opacity-20">
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-primary/30 via-transparent to-transparent" />
           </div>
           
           <div className="max-w-5xl mx-auto relative z-10 text-center space-y-12 md:space-y-20">
              <motion.div initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }}>
                <h3 className={`font-display font-bold text-white mb-16 md:mb-28 tracking-tight text-balance max-w-6xl mx-auto text-center leading-relaxed ${isEn ? 'text-[clamp(1.25rem,5vw,2rem)]' : 'text-[clamp(1.5rem,6vw,2.5rem)]'}`}>
                  {isEn ? (
                    <>Architecting the <span className="text-primary">Financial Frontier</span> <br className="hidden md:block" />with strategic precision.</>
                  ) : (
                    <>用设计构建 <span className="text-primary whitespace-nowrap">Web3 世界的</span><br/><span className="text-primary whitespace-nowrap">金融基石。</span></>
                  )}
                </h3>
                <div className="flex flex-col md:flex-row items-center justify-center gap-6 md:gap-10">
                  <button onClick={onClose} className="w-full md:w-auto px-12 md:px-20 py-5 md:py-7 rounded-full bg-white text-black font-black uppercase text-[10px] md:text-[13px] tracking-[0.3em] md:tracking-[0.4em] hover:bg-primary hover:text-white transition-all shadow-4xl duration-500">EXIT ARCHIVE</button>
                  <button 
                    onClick={() => scrollToSection(`web3-section-0`)}
                    className="w-full md:w-auto px-8 md:px-12 py-5 md:py-7 rounded-full border border-white/20 text-white font-black uppercase text-[9px] md:text-[10px] tracking-[0.2em] md:tracking-[0.3em] hover:bg-white/5 transition-all flex items-center justify-center gap-4"
                  >
                    <ArrowUp className="w-4 h-4" /> RESTART JOURNEY
                  </button>
                </div>
              </motion.div>
           </div>
        </section>
      </div>

      <style>{`
        .no-scrollbar::-webkit-scrollbar { display: none; }
        .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
        .text-balance { text-wrap: balance; }
      `}</style>
    </motion.div>
  );
};

export default Web3Layout;
