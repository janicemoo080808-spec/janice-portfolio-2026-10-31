import React from 'react';
import { motion as m, AnimatePresence } from 'framer-motion';
import { Project, Language } from '../types';

// Cast motion to any to bypass environment-specific type definition issues
const motion = m as any;

interface PortfolioAccordionCardProps {
  project: Project;
  isHovered: boolean;
  isAnyHovered: boolean;
  onHover: () => void;
  onLeave: () => void;
  onClick: () => void;
  isMobileLayout?: boolean;
  language?: Language;
}

const PortfolioAccordionCard: React.FC<PortfolioAccordionCardProps> = ({ 
  project, 
  isHovered, 
  isAnyHovered, 
  onHover, 
  onLeave, 
  onClick,
  isMobileLayout = false,
  language = 'EN'
}) => {
  
  const getCustomMeta = (project: Project) => {
    // Derived from category for cross-language robustness
    const isEn = language === 'EN';

    switch (project.category) {
      case 'BRAND_ECOSYSTEM': 
        return { 
          shortLabel: isEn ? 'Web3 Ecosystem' : 'Web3 金融生态', 
          subtitle: isEn ? 'Strategic Architecture / Visual / UI' : '品牌体系 / 视觉语言 / 产品界面' 
        };
      case 'LUXURY_DESIGN': 
        return { 
          shortLabel: isEn ? 'Luxury Aesthetics' : '奢侈品美学与调性', 
          subtitle: isEn ? 'Aesthetic Paradigm / Visuals / Tone' : '视觉形象 / 大片风格 / 品牌气质' 
        };
      case 'AUTOMOTIVE_DESIGN': 
        return { 
          shortLabel: isEn ? 'Smart Mobility' : '智能出行品牌', 
          subtitle: isEn ? 'Industrial Aesthetics / UI/UX / Systems' : '品牌设计 / UI/UX / 体验系统' 
        };
      case 'AI_CREATIVE': 
        return { 
          shortLabel: isEn ? 'AIGC Strategy' : 'AIGC 战略与全域制作', 
          subtitle: isEn ? 'Hybrid Agents / Strategy / Workflow' : 'AI 视觉 / 内容生产 / 创意策略' 
        };
      case 'ACTIVITY_VISUALS': 
        return { 
          shortLabel: isEn ? 'Brand Events' : '品牌活动与空间', 
          subtitle: isEn ? 'Spatial Narrative / Campaign / CX' : '活动视觉 / 空间设计 / 体验呈现' 
        };
      default: 
        return { 
          shortLabel: 'PORTFOLIO', 
          subtitle: project.tags.join(' / ') 
        };
    }
  };

  const meta = getCustomMeta(project);
  const isMobile = typeof window !== 'undefined' && window.innerWidth < 1024;
  const isEn = language === 'EN';

  return (
    <motion.div
      onMouseEnter={onHover}
      onMouseLeave={onLeave}
      onClick={onClick}
      whileTap={{ scale: 0.96 }}
      layout
      transition={{ duration: 0.7, ease: [0.23, 1, 0.32, 1] }}
      className={`relative cursor-pointer overflow-hidden border border-white/5 shadow-2xl transition-all duration-700 will-change-[flex,transform,height] transform-gpu
        ${isMobileLayout 
          ? `w-full rounded-[20px] ${isHovered ? 'h-[280px] md:h-[350px] ring-2 ring-primary/40' : 'h-[140px] md:h-[180px] opacity-100'}` 
          : `h-[500px] md:min-w-[65px] rounded-[12px] ${isHovered ? 'flex-[25] -translate-y-3 z-20' : 'flex-1 z-0'} ${isAnyHovered && !isHovered ? 'opacity-40 grayscale-[0.8]' : 'opacity-100 grayscale-0'}`
        }
      `}
    >
      <div className="absolute inset-0 z-0 bg-zinc-900">
        <motion.img 
          src={project.imageUrl} 
          className="w-[101%] h-full object-cover transition-transform duration-1000 left-[-0.5%]" 
          alt={project.title} 
          animate={{ 
            scale: (isHovered || isMobileLayout) ? 1.1 : 1.02, 
            filter: (isHovered || isMobileLayout) ? 'brightness(1)' : 'brightness(0.9)' 
          }}
          loading="lazy"
        />
        {/* 修复：仅在底部文字区域保留遮罩，保持封面全清 */}
        <div className={`absolute inset-x-0 bottom-0 h-1/2 bg-black/10 backdrop-blur-[25px] transition-opacity duration-700 pointer-events-none
          ${isMobileLayout 
            ? 'opacity-100' 
            : 'opacity-0 group-hover:opacity-100'}`} 
            style={{ WebkitMaskImage: 'linear-gradient(to top, black 15%, transparent 85%)', maskImage: 'linear-gradient(to top, black 15%, transparent 85%)' }}
        />
      </div>

      <div className="absolute inset-0 z-10 flex flex-col justify-end p-5 md:p-10 pointer-events-none overflow-hidden">
        <AnimatePresence mode="wait">
          {(isHovered || (!isMobileLayout && isMobile)) ? (
            <motion.div
              key="expanded"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
              className="space-y-2 md:space-y-4 max-w-[600px]"
            >
              <div className="space-y-1.5">
                <h3 className={`font-display font-bold text-white uppercase tracking-tight leading-[1.1] 
                  ${isMobileLayout ? 'text-lg md:text-xl' : 'text-xl md:text-[32px]'}`}>
                  {project.title}
                </h3>
                
                <p className={`text-zinc-300 font-normal tracking-[0.1em] md:tracking-[0.2em] uppercase 
                  ${isMobileLayout ? 'text-[10px]' : 'text-[9px] md:text-[15px]'}`}>
                  {meta.subtitle}
                </p>
              </div>

              <div className="pt-2 pointer-events-auto">
                <button className={`rounded-full border border-white/40 font-black uppercase tracking-[0.3em] text-white hover:bg-white hover:text-black hover:border-white transition-all shadow-xl
                  ${isMobileLayout ? 'px-4 py-2 text-[9px]' : 'px-5 md:px-8 py-2 md:py-3 text-[10px] md:text-[12px]'}
                `}>
                  {isEn ? 'VIEW CASE' : '查看案例'}
                </button>
              </div>
            </motion.div>
          ) : (
            <motion.div 
              key="collapsed"
              initial={{ opacity: 0 }} 
              animate={{ opacity: 1 }} 
              exit={{ opacity: 0 }}
              className={`absolute inset-0 flex items-end ${isMobileLayout ? 'justify-start p-6' : 'justify-center pb-[12%]'}`}
            >
               <h3 className={`font-display font-black text-white uppercase tracking-[0.15em] drop-shadow-[0_8px_24px_rgba(0,0,0,1)] whitespace-nowrap
                 ${isMobileLayout 
                   ? 'text-sm md:text-base' 
                   : 'text-[12px] md:text-[14px] [writing-mode:vertical-lr] md:[writing-mode:horizontal-tb] rotate-180 md:rotate-0'
                 }
               `}>
                 {meta.shortLabel}
               </h3>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
};

export default PortfolioAccordionCard;